#================================================================
# DebugFactory Builder make file
# 
# Author   : Panasonic Corporation
# 
# FileName :57G_Sample.mak
#================================================================
 
#================================================================
#       According to DebugFactory Builder rules 
#
# Editing can be performed from IDE for the following macro definitions with 
# DebugFactory Builder.  
# Do not edit the make file directly. 
# The edited data will be discarded by the IDE setting. 
#PROJECT    : target 
#SOURCEFILE : source file 
#TOOLDIR    : tool storage folder 
#CC         : compiler name
#ASM        : assembler name
#LINK       : linker name 
#CINC       : include file path (for compiler) 
#AINC       : include file path (for assembler) 
#LIBPATH    : library file path 
#LIBFILES   : library name 
#CFLAGS     : compiler options 
#CFLAGS     : compiler options for assembler file output 
#AFLAGS     : assembler options 
#LFLAGS     : linker library options 
#OBJECTOUTPUTDIR : object file (*.rf) output folder 
#
       
#================================================================
 
#================================================================
# Target setting
#================================================================
PROJECT	= 57G_Sample.ex
 
#================================================================
# User macro definition
#================================================================
#========================DFUSRDEFMACRO_S==============================
#========================DFUSRDEFMACRO_E==============================
 
#================================================================
# Source file setting
#================================================================
SOURCEFILE	= ..\ASM\ST101ES.ASM \
		..\SRC\Initial_57G.c \
		..\SRC\interrupt.c \
		..\SRC\main.c \
 
#================================================================
# Intermediate file setting
#================================================================
OBJFILES	= .\ST101ES.rf \
		.\Initial_57G.rf \
		.\interrupt.rf \
		.\main.rf \
 
#================================================================
# Tool setting
#================================================================
CC	= CC101E.EXE
ASM	= AS101E.EXE
LINK	= LD101E.EXE
 
#================================================================
# C source include file path setting
#================================================================
CINC	= -I..\Header \
		-IC:\PanaX\CC101E\INCLUDE
 
#================================================================
# Assembler include path setting
#================================================================
AINC	= 
 
#================================================================
# Library path setting
#================================================================
LIBPATH	= -LC:\PanaX\CC101E\LIB
 
#================================================================
# Library setting
#================================================================
LIBFILES	= -lpanax_ex_mon101e.l \
		-lCC101E.LIB
 
#================================================================
# Compiler option setting
#================================================================
CFLAGS	=-e  -g -fchar-bfield -fc9x-comment -finteg-prom -fenable-asm -c -D__USE_MONITOR_EXLIB -W5615 $(CINC)
 
#================================================================
# Local option setting
#================================================================
 
#================================================================
# Assembler option setting
#================================================================
AFLAGS	= -e  -g -l -Xl -D__USE_MONITOR_EXLIB
CAFLAGS	= -e -g -l -Xl -D__USE_MONITOR_EXLIB -Ot -ZC -Zv12
 
#================================================================
# Linker option setting
#================================================================
LFLAGS	= -e  -m -g -OVRAM
 
#================================================================
# Object file (*.RF) output folder setting
#================================================================
OBJECTOUTPUTDIR	= .\\
 
#================================================================
# Target (EX)
#================================================================
$(PROJECT): $(OBJFILES)
 
#================================================================
# Pre-link user-defined processing
#================================================================
#========================DFUSRBDEF_S==============================
#========================DFUSRBDEF_E==============================
 
#================================================================
# Target (EX)
#================================================================
	$(LINK) @&&|
		-o.\$(PROJECT)
		$(LFLAGS)
		$(LIBPATH)
		-T@CODE=4000
		-T@DATA=0
		$(OBJECTOUTPUTDIR)ST101ES.rf
		$(OBJECTOUTPUTDIR)Initial_57G.rf
		$(OBJECTOUTPUTDIR)interrupt.rf
		$(OBJECTOUTPUTDIR)main.rf
		$(LIBFILES)
|
 
#================================================================
# Post-make user-defined processing
#================================================================
#========================DFUSRADEF_S==============================
#========================DFUSRADEF_E==============================
 
#================================================================
# Execution command
#================================================================
$(OBJECTOUTPUTDIR)ST101ES.rf: ..\ASM\ST101ES.ASM
	$(ASM) $(AFLAGS) -o $(OBJECTOUTPUTDIR)$(@F) ..\ASM\ST101ES.ASM
$(OBJECTOUTPUTDIR)Initial_57G.rf: ..\SRC\Initial_57G.c
	$(CC) $(CFLAGS) -o $(OBJECTOUTPUTDIR)Initial_57G.rf ..\SRC\Initial_57G.c
$(OBJECTOUTPUTDIR)interrupt.rf: ..\SRC\interrupt.c
	$(CC) $(CFLAGS) -o $(OBJECTOUTPUTDIR)interrupt.rf ..\SRC\interrupt.c
$(OBJECTOUTPUTDIR)main.rf: ..\SRC\main.c
	$(CC) $(CFLAGS) -o $(OBJECTOUTPUTDIR)main.rf ..\SRC\main.c
