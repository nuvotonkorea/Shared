
/********************************
          macro define
*********************************/

#define DI()	asm("	and 0xbf,PSW\n");			/*prohibit Interrupt*/
#define EI()	asm("	or 0x40,PSW\n");			/*permit Interrupt*/

#define	FALSE	0x00
#define	TURE	0x01

