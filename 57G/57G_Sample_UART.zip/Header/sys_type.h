/****************************************************************
	File Name   : sys_type.h
	Description : This file is a variable declaration file.
	Remark      : 
	Date        : 08/08/22
	Copynight   : Panasonic Semiconductor Systems & Technology
****************************************************************/
typedef unsigned char UCHAR;
typedef unsigned short USHORT;
typedef unsigned long  ULONG;
typedef signed char CHAR;
typedef signed short SHORT;
typedef signed long LONG;


#define	O_B7	0x80
#define	O_B6	0x40
#define	O_B5	0x20
#define	O_B4	0x10
#define	O_B3	0x08
#define	O_B2	0x04
#define	O_B1	0x02
#define	O_B0	0x01

#define	I_B7	0x00
#define	I_B6	0x00
#define	I_B5	0x00
#define	I_B4	0x00
#define	I_B3	0x00
#define	I_B2	0x00
#define	I_B1	0x00
#define	I_B0	0x00

#define	PUO_B7	0x80
#define	PUO_B6	0x40
#define	PUO_B5	0x20
#define	PUO_B4	0x10
#define	PUO_B3	0x08
#define	PUO_B2	0x04
#define	PUO_B1	0x02
#define	PUO_B0	0x01

#define	PUX_B7	0x00
#define	PUX_B6	0x00
#define	PUX_B5	0x00
#define	PUX_B4	0x00
#define	PUX_B3	0x00
#define	PUX_B2	0x00
#define	PUX_B1	0x00
#define	PUX_B0	0x00


