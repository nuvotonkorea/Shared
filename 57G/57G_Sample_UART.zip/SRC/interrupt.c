


#pragma _interrupt INT_INT0
void INT_INT0(void)
{
	;
}

#pragma _interrupt INT_TXD
void INT_TXD(void)
{
	;
}

#pragma _interrupt INT_RXD
void INT_RXD(void)
{
	;
}



