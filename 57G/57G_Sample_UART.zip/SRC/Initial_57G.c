
#include "..\header\sys_type.h"				/*The definition file for SYSTEM*/
#include "..\header\srMN101EF57G.h"
#include "..\header\macro.h"


void pPort_Init(void)
{

	/*---------------------------------------------------
	PORT 0 DEFINE
	-----------------------------------------------------
	Bit	Function	Dir PUD	Init Value		Description
	-----------------------------------------------------
	P07 GPIO		O	X	0			NC
	P06 GPIO		O	X	0			NC
	P05 GPIO		O	X	0			NC
	P04 GPIO		O	X	0			TH_LOW
	P03 GPIO		O	X	0			SCL_EEPROM
	P02 GPIO		O	X	0			SDA_EEPROM
	P01 GPIO		O	X	0			NC
	P00 GPIO		O	X	0			NC
	---------------------------------------------------*/
	P0DIR = 0xff;	/* All Output */
	P0PLUD = 0x00;	/* No Used Pull Up Function */
	P0OMD1 = 0x1C;	/*B4 = TM2IOB,B3 = TM8IOB,B2 = TM7IOB*/
	P0OMD2 = 0x00;	/**/
	P0ODC = 0x00;	/* All Push-Pull Output */
	P0LED = 0x00;	/* No Use LED Port */
	P0OUT = 0x00;	/* Init Value : 0 */

	/*---------------------------------------------------
	PORT 2 DEFINE
	-----------------------------------------------------
	Bit Function	Dir PUD Init Value		Description
	-----------------------------------------------------
	P27 GPIO		I	X	0			dummy
	P26 GPIO		I	X	0			dummy
	P25 GPIO		I	X	0			dummy
	P24 GPIO		O	X	0			STEP���� B���
	P23 IRQ3		I	X	0			I-FAN LOCK����
	P22 IRQ2		I	X	0			C-FAN LOCK����
	P21 IRQ1		I	X	0			F-FAN LOCK����
	P20 IRQ0		I	X	0			R-FAN LOCK����
	---------------------------------------------------*/
	P2DIR = 0x10;	/*B4 = Out, other In */
	P2PLU = 0x00;	/* No Used Pull Up Function */
	P2OUT = 0x00;	/* Init Value : 0 */

	/*---------------------------------------------------
	PORT 3 DEFINE
	-----------------------------------------------------
	Bit Function	Dir PUD Init Value		Description
	-----------------------------------------------------
	P37 GPIO		I	X	0			dummy
	P36 GPIO		I	X	0			dummy
	P35 GPIO		O	X	0			3 Way Valve A_BAR
	P34 GPIO		O	X	0			3 Way Valve B
	P33 GPIO		O	X	0			3 Way Valve A
	P32 GPIO		I	X	0			dummy
	P31 GPIO		I	X	0			dummy
	P30 GPIO		I	X	0			dummy
	---------------------------------------------------*/
	P3DIR = 0x38;	/*  */
	P3PLU = 0x00;	/* No Used Pull Up Function */
	P3IMD = 0x00;	/* No Use Analog Input */
	P3ODC = 0x00;	/* Push Pull Output */
	P3OUT = 0x00;	/* Init Value : 0 */


	/*---------------------------------------------------
	PORT 4 DEFINE
	-----------------------------------------------------
	Bit Function	Dir PUD Init Value		Description
	-----------------------------------------------------
	P47 GPIO		I	X	0			��Ʈ�� SW
	P46 GPIO		O	X	0			P LED(����)
	P45 GPIO		O	X	0			P LED(��ä)
	P44 GPIO		O	X	0			P LED(����)
	P43 GPIO		O	X	0			3 Way Valve B_BAR
	P42 GPIO		I	X	0			dummy
	P41 GPIO		I	X	0			dummy
	P40 GPIO		I	X	0			dummy
	---------------------------------------------------*/
	P4DIR = 0x78;	/*	*/
	P4PLUD = 0x00;	/* No Used Pull Up Function */
	P4ODC = 0x00;	/* Push Pull Output */
	P4OUT = 0x00;	/* Init Value : 0 */

	/*---------------------------------------------------
	PORT 5 DEFINE
	-----------------------------------------------------
	Bit Function	Dir PUD Init Value		Description
	-----------------------------------------------------
	P57 GPIO		O	X	0			P���� A
	P56 GPIO		O	X	0			P���� B
	P55 GPIO		O	X	0			P���� ST/SP
	P54 GPIO		O	X	0			Blast chiler Power
	P53 GPIO		O	X	0			Blast chiler Motor
	P52 GPIO		O	X	0			R���� Heater
	P51 GPIO		O	X	0			F���� Heater
	P50 GPIO		O	X	0			R-Door Heater
	---------------------------------------------------*/
	P5DIR = 0xff;	/* All Output */
	P5PLUD = 0x00;	/* No Used Pull Up Function */
	P5OMD = 0x00;	/* All GPIO */
	P5ODC = 0x00;	/* All Push-Pull Output */
	P5OUT = 0x00;	/* Init Value : 0 */

	/*---------------------------------------------------
	PORT 6 DEFINE
	-----------------------------------------------------
	Bit Function	Dir PUD Init Value		Description
	-----------------------------------------------------
	P67 GPIO		I	X	0			dummy
	P66 RXD2A	I	X	0			Flash RXD
	P65 TXD2A	O	X	0			Flash TXD
	P64 TM4IOB	O	X	0			R-FAN ���
	P63 GPIO		O	X	0			NC
	P62 GPIO		O	X	0			Home Bar Heater
	P61 GPIO		I	X	0			dummy
	P60 GPIO		I	X	0			dummy
	---------------------------------------------------*/
	P6DIR = 0x3c;	/*  */
	P6PLU = 0x00;	/* No Used Pull Up Function */
	P6OMD = 0x10;	/* B4:Timer Out */
	P6ODC = 0x00;	/* All Push-Pull Output */
	P6OUT = 0x00;	/* Init Value : 0 */
						
	/*---------------------------------------------------
	PORT 7 DEFINE
	-----------------------------------------------------
	Bit Function	Dir PUD Init Value		Description
	-----------------------------------------------------
	P77 GPIO		O	X	0			Beta Duct Heater
	P76 GPIO		O	X	0			������ Box fan
	P75 GPIO		I	X	0			R-Door SW
	P74 GPIO		O	X	0			LCD��� �۽�(TX)
	P73 GPIO		I	X	0			LCD��� ����(RX)
	P72 GPIO		O	X	0			NC
	P71 GPIO		O	X	0			NC
	P70 GPIO		O	X	0			NC
	---------------------------------------------------*/
	P7DIR = 0xd7;	/*	*/
	P7PLUD = 0x00;	/* No Used Pull Up Function */
	P7ODC = 0x00;	/* All Push-Pull Output */
	P7OUT = 0x00;	/* Init Value : 0 */
						
	/*---------------------------------------------------
	PORT 8 DEFINE
	-----------------------------------------------------
	Bit Function	Dir PUD Init Value		Description
	-----------------------------------------------------
	P87 GPIO		O	X	0			STEP���� A���
	P86 GPIO		O	X	0			STEP���� S/O���
	P85 GPIO		O	X	0			NC
	P84 GPIO		O	X	0			Linear Comp���
	P83 GPIO		O	X	0			Damper HTR
	P82 GPIO		O	X	0			NC
	P81 GPIO		O	X	0			NC
	P80 GPIO		O	X	0			NC
	---------------------------------------------------*/
	P8DIR = 0xff;	/*	*/
	P8PLU = 0x00;	/* No Used Pull Up Function */
	P8OMD = 0x00;	/* All GPIO */
	P8SYO = 0x00;	/* IO Port */
	P8SEV = 0x00;	/* don't care */
	P8OUT = 0x00;	/* Init Value : 0 */
					
	/*---------------------------------------------------
	PORT 9 DEFINE
	-----------------------------------------------------
	Bit Function	Dir PUD Init Value		Description
	-----------------------------------------------------
	P97 GPIO		I	X	0			dummy
	P96 GPIO		I	X	0			dummy
	P95 GPIO		I	X	0			dummy
	P94 GPIO		I	X	0			F/L-DOOR SW
	P93 GPIO		I	X	0			F/U-DOOR SW
	P92 GPIO		I	X	0			TEST SW
	P91 GPIO		O	X	0			NC
	P90 GPIO		O	X	0			NC
	---------------------------------------------------*/
	P9DIR = 0x03;	/*	*/
	P9PLU = 0x00;	/* No Used Pull Up Function */
	P9IMD = 0x00;	/* All GPIO */
	P9OUT = 0x00;	/* Init Value : 0 */

	/*---------------------------------------------------
	PORT A DEFINE
	-----------------------------------------------------
	Bit Function	Dir PUD Init Value		Description
	-----------------------------------------------------
	PA7 GPIO 	O	X	0			NC
	PA6 GPIO 	O	X	0			NC
	PA5 GPIO 	O	X	0			NC
	PA4 AN4 		I	X	0			F ���󼾼�
	PA3 AN3 		I	X	0			�õ�����
	PA2 AN2 		I	X	0			R ���󼾼�
	PA1 AN1 		I	X	0			���弾��
	PA0 TM0IOA	O	X	0			I-FAN���
	---------------------------------------------------*/
	PADIR = 0xe1;	/*	*/
	PAPLU = 0x00;	/* No Used Pull Up Function */
	PAIMD = 0x1e;	/* Analog Input setting */
	PAOMD1 = 0x00;	/* All GPIO */
	PACNT = 0x00;	/* IO Port */
	SWCNT = 0x00;	/* default input level */
	PAOUT = 0x00;	/* Init Value : 0 */
				
	/*---------------------------------------------------
	PORT B DEFINE
	-----------------------------------------------------
	Bit Function	Dir PUD Init Value		Description
	-----------------------------------------------------
	PB7 GPIO	I	X	0			dummy
	PB6 GPIO	I	X	0			dummy
	PB5 GPIO	I	X	0			dummy
	PB4 GPIO	I	X	0			dummy
	PB3 AN11	I	X	0			�ܱ⼾��
	PB2 AN10	I	X	0			��Ʈ�� ����
	PB1 AN9 		I	X	0			������ ����
	PB0 AN8 		I	X	0			���� ����
	---------------------------------------------------*/
	PBDIR = 0x00;	/*	*/
	PBPLU = 0x00;	/* No Used Pull Up Function */
	PBIMD = 0x0f;	/* Analog Input setting */
	PBOUT = 0x00;	/* Init Value : 0 */


}

/*---------------------------------------------------
Timer 1 : General Timer
   1ms
   fpll_div : 8MHz
   Clock : fpll_div/32
   BC : 250 - 1
   Period : (1/(fpll_div/32)) * (250) = 1ms
----------------------------------------------------*/
void pTimer1_Setting(void)
{
	TM1OC = 250 - 1;
	TM1MD = 0x01;		/* Not use cascade function */
						/* Timer1 STOP */
						/* Clock : prescaler output */
	CK1MD = 0x08;		/* Clock Source : fpll_div/32*/
	
	TM1MD |= 0x08;		/* Timer1 START */
	TM1ICR = 0x82;		/* Interrupt Level : 2 */
						/* Timer 1 Interrupt Enable */
}

/*---------------------------------------------------
Timer A : UART
   9600bps
   fpll_div : 8MHz
   Clock : fpll_div/32
   BC : 26 - 1
   Period : (1/(fpll_div/32)) * (26) = 9615.38bps
----------------------------------------------------*/
void pTimerA_Setting(void)
{
	TMAOC = 26 - 1;
	TMAMD1 = 0x05;		/* Clock Source : fpll_div/32 */
						/* TimerA STOP */
	TMAMD2 = 0x40;		/* Prescaler Enable */
	TMAMD1 |= 0x08;		/* TimerA START */
}

/*---------------------------------------------------
Time Base Timer : General Timer
   1.024ms
   fpll_div : 8MHz
   Clock : fpll_div/2^13
   BC : -
   Period : (1/(fpll_div/32)) * (250) = 1ms
----------------------------------------------------*/
void pTBT_Setting(void)
{
	TM6BEN = 0x00;			/* TBT STOP */
	TMCKSEL1 = 0x00;		/* TBT Clock Range : 2^13 */
	TM6MD = 0x48;			/* Interrupt : TBT Clock * 1/2^13 */
							/* TBT Clock : fpll_div */
	TBCLR = 0x00;			/* Clear Timer */
	TM6BEN = 0x02;			/* TBT START */
	TBICR = 0x82;			/* Interrupt Level : 2 */
							/* TBT Interrupt Enable */
}

/*---------------------------------------------------
Timer 0 : PWM OUT
   15.625KHz
   fs : 16MHz
   Clock : fs/4
   BC : 
   Period : (fs/4)*256 = 15.625KHz
----------------------------------------------------*/
void pTimer0_Setting(void)
{
	CK0MD = 0x03;		/* Clock Source : fs/4 */
	TM0OC = 0x80;		/* Duty : 50% */
	TM0MD = 0x11;		/* PWM */
						/* Clock : prescaler */
	TM0ICR = 0xc0;		/* Interrupt Disable */
	TM0MD |= 0x08;		/* PWM START */
}

/*---------------------------------------------------
Timer 2 : PWM OUT
   15.625KHz
   fs : 16MHz
   Clock : fs/4
   BC : 
   Period : (fs/4)*256 = 15.625KHz
----------------------------------------------------*/
void pTimer2_Setting(void)
{
	CK2MD = 0x03;		/* Clock Source : fs/4 */
	TM2OC = 0x80;		/* Duty : 50% */
	TM2MD = 0x11;		/* PWM */
						/* Clock : prescaler */
	TM2ICR = 0xc0;		/* Interrupt Disable */
	TM2MD |= 0x08;		/* PWM START */
}

/*---------------------------------------------------
Timer 4 : PWM OUT
   15.625KHz
   fs : 16MHz
   Clock : fs/4
   BC : 
   Period : (fs/4)*256 = 15.625KHz
----------------------------------------------------*/
void pTimer4_Setting(void)
{
	CK4MD = 0x03;		/* Clock Source : fs/4 */
	TM4OC = 0x80;		/* Duty : 50% */
	TM4MD = 0x11;		/* PWM */
						/* Clock : prescaler */
	TM4ICR = 0xc0;		/* Interrupt Disable */
	TM4MD |= 0x08;		/* PWM START */
}

/*---------------------------------------------------
Timer 8 : PWM OUT
   15.625KHz
   fpll_div : 8MHz
   Clock : fpll_div/2
   BC : 
   Period : (fClock)*OC2 = 15.625KHz
----------------------------------------------------*/
void pTimer8_Setting(void)
{
	TM8MD1 = 0x04;		/* Timer STOP */
						/* Count clock : Clock Source/2 */
						/* Clock Source : fpll_div */
	TM8MD2 = 0x70;		/* Duty : OC2 */
						/* Clear : Match OC1 */
						/* OUTPUT PWM */
	TM8MD3 = 0x00;		/* PWM STOP : Level Low */
						/* Output level polarity : Normal  */
	TM8MD4 = 0x00;		/* timer8 output */
	TM8PR1H = 0x00;		/* Max Count : 256 */
	TM8PR1L = 0xff;
	TM8PR2H = 0x00;		/* Duty : 128 */
	TM8PR2L = 0x7f;
	TMCKSEL2 = 0x00;	/*  */	
	TMINSEL2 = 0x00;	/*  */

	TM8MD1 |= 0x10;		/* Timer START */
}


/*---------------------------------------------------
Timer 7 : PWM OUT
   15.625KHz
   fpll_div : 8MHz
   Clock : fpll_div/2
   BC : 
   Period :
----------------------------------------------------*/
void pTimer7_Setting(void)
{
	TM7MD1 = 0x04;		/* Timer STOP */
						/* Count clock : Clock Source/2 */
						/* Clock Source : fpll_div */
	TM7MD2 = 0x70;		/* Duty : OC2 */
						/* Clear : Match OC1 */
						/* OUTPUT PWM */
	TM7MD3 = 0x00;		/* PWM STOP : Level Low */
						/* Output level polarity : Normal  */
	TM7MD4 = 0x00;		/* timer7 output */
	TM7PR1H = 0x00;		/* Max Count : 256 */
	TM7PR1L = 0xff;
	TM7PR2H = 0x00;		/* Duty : 128 */
	TM7PR2L = 0x7f;

	TM7MD1 |= 0x10;		/* Timer START */
}


void pExtInt_Setting(void)
{
	IRQ0ICR = 0x42;		/* Falling Edge */
						/* Interrupt Enable */
	IRQ1ICR = 0x42; 	/* Falling Edge */
						/* Interrupt Enable */
	IRQ2ICR = 0x42; 	/* Falling Edge */
						/* Interrupt Enable */
	IRQ3ICR = 0x42; 	/* Falling Edge */
						/* Interrupt Enable */
}


void pUART2_Setting(void)
{
	SC2MD0 = 0x0f;		/* MSB first */
						/* START Condition On */
						/* Sync serial : 8 */
	SC2MD1 = 0x31;		/* Serial In : RxD */
						/* SBT : Port */
						/* Serial Input Control : Serial Data */
						/* SBO function : Serial Data Out */
						/* Transfer clock division : Not Div */
						/* Clock master : don't care	*/
						/* clock division : don't care */
						/* Function : UART */
	SC2MD2 = 0x08;		/* 8bits + 1 stop */
						/* add bit : don't care */
						/* parity : disable */
						/*  */
	SC2MD3 = 0x0e;		/* After send level : Fixed High */
						/* Prescaler : Enable */
						/* Clock : Timer A */

	SC2RICR = 0x02;		/* RxD : Interrupt Enable */
	SC2TICR = 0x02;		/* TxD : Interrupt Enable */
}

void pAD_Setting(void)
{
	ANCTR0 = 0x58;		/* Tad x 6*/
						/* Tad = fs/4 */
						/* Ladder Res On */
	ANCTR1 = 0x00;		/* AD Start Chn */
	ANCTR2 = 0x00;		/* AD Stop */
						/* AD Start : ANST Set to 1  */

}

void pMCU_Init(void)
{
	pPort_Init();

	pTimer1_Setting();		/* 1ms Timer */
	pTBT_Setting();			/* 1.024ms Timer */

	pTimer0_Setting();		/* PWM Output : 15.625KHz */
	pTimer2_Setting();		/* PWM Output : 15.625KHz */
	pTimer4_Setting();		/* PWM Output : 15.625KHz */
	pTimer8_Setting();		/* PWM Output : 15.625KHz */
	pTimerA_Setting();		/* UART Timer */

	pTimer7_Setting();		/* Buzzer Output */

	pExtInt_Setting();

	pUART2_Setting();
	pAD_Setting();
	
}



