
#include "..\header\sys_type.h"				/*The definition file for SYSTEM*/
#include "..\header\srMN101EF57G.h"
#include "..\header\macro.h"

#define	_MAIN
#include "..\header\ram.h"


#pragma _section B=RAM
	volatile char gSectionA_Var[20];
#pragma _section B

extern void BSS_CLEAR();
extern void BSS_RAM_CLEAR();


/**********************************************/
/*                                                                            */
/* GLOBAL VARIABLE DEFINE                                     */
/*                                                                            */
/**********************************************/
volatile UCHAR gVar0;
volatile UCHAR gVar1;



void main(void)
{
	unsigned char i;

	for(i=0;i!=20;i++){
		gSectionA_Var[i] = i;
	}
	
	BSS_RAM_CLEAR();
	
	DI();											/*prohibit Interrupt*/
	pMCU_Init();
	EI();											/*permit Interrupt*/

	while(1)
	{
		++gVar2;
		;
	}
}


