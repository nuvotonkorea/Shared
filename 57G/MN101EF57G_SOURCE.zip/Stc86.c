                                      
/******************************************************************************
**
**  COPYRIGHT (C) 
**
**  THIS WORK CONTAINS TRADE SECRET AND PROPRIETARY INFORMATION WHICH IS
**  THE PROPERTY OF CUCKOO
**
**  PROJECT NAME:   
**
**  FILENAME:       .c
**
**  PURPOSE:        
**
**  FUNCTIONS:      
**
**  AUTHOR:
**
**  VERSION:        1.0
**
**  LAST MODIFIED:  
******************************************************************************/
/*****************************************************************************
Note:
2015-04-10 : 
*******************************************************************************/
#include    "typedef.h"
#include    "main.h"
#include    "global_func.h"
#include    <stdlib.h>

#define ROOT
#include    "srMN101EF57G.h"
#include    "DustSensor.h"
//#include    "GasSensor_FIS.h"
#include    "wifi.h"



//#define DI()    asm("   AND 0x0F,PSW ")
//#define EI()    asm("   OR  0x70,PSW ")

/*==============
=========================================================
  [ User definition part ]
    This part is necessary.
  =======================================================================*/
/* This part is necessary. */
#define _BaseSP     0x0C3F      /* Stack area initial address */
#define _BaseIntTbl 0xFFC8


/* When you need the RAM clear, this part is necessary. */
#define RAM_TOP     0x0040      /* Start address of RAM */
#define RAM_SIZE    0x0BFF  /* Size of RAM */

/* This part is necessary. */
//extern void   main(void);         /* Prototype of main function */
        

void port_initial(void);
void init_sysclk(void);
void init_data(void);
void _clearVariable(void);



void Timer0_Setting(void);
void Timer1_Setting(void);
void Timer7_Setting(void);
void Timer4_PWM_Setting(void);
void Timer8_PWM_Setting(void);
void IRQ_Setting(void);
void AD_Setting(void);
/*=======================================================================
  [ Dummy section definition ]
    When using variables with initial value, this part is necessary.
  =======================================================================*/
extern  char     _TDataAddr[];   /* for t_data initialize, defined in link command file  */
extern  char     _TDataOrg[];    /* for t_data initialize, defined in link command file  */
extern  char     _TDataSize;         /* for t_data initialize, defined in link command file  */
extern  char    _NDataAddr[];            /* for n_data initialize, defined in link command file  */
extern  char    _NDataOrg[];             /* for n_data initialize, defined in link command file  */
extern  int     _NDataSize;              /* for n_data initialize, defined in link command file  */

//del void  Int_dummy(void){__asm("NOP");}
extern void  Ext_int3_bldc_pg(void);
extern void  Ext_int4(void);
extern void  Inttca0_10msec(void);
extern void  Inttc00_1msec(void);
extern void  Inttc01_2msec(void);

extern void  IntrUartTxD1(void);
extern void  IntrUartRxD1(void);
//extern void __interrupt Inttc02_160usec(void);

extern void UART_Init(void);

#pragma section const CHECK_SUM 0xFFA0

const unsigned char FLASH_CHECKSUM[] =
{
    0x90,0x75,0xac,0x00
};



/*----------------------------------------------------------------------
/*      : display buffer clear
/***********************************************************************/
/*=======================================================================
  [ Startup ]
    This part is necessary.
  =======================================================================*/
void    startup(void)
{
      DI();                 /* [NECESSARY] Disable interrupt */
     //del WDCTR = 0x07;          //0000 0111
     //del WDCDR = 0xB1;
     PRTKEY = 0xaa;
     WD2CLR = 0x55;         /* WDT clear */
     PRTKEY = 0xff;


     port_initial();

     init_sysclk();
     
     STAND_BY_POWER = ON;   //CODELESS
     if(REED_SWITCH_FLOAT && OPTION2_PORT)
     {
         gVoicePlayWaterLackSkipCnt3 = 1;
     }

     PRTKEY = 0xaa;
     WD2CLR = 0x55;         /* WDT clear */
     PRTKEY = 0xff;
     EI();
     INIT = 1;		// Reset ��� CODELESS

     init_data();
     UART_Init();
     at_cmd_step = 0;//1;

    for(;;) main();

}

void init_sysclk(void)
{
    PRTKEY = 0xaa;
    WD2CLR = 0x55;          /* WDT clear */
    PRTKEY = 0xff;
    
    Timer0_Setting();       /* 0.5ms Timer */
    Timer1_Setting();       /* 1ms Timer */
    Timer7_Setting();       /* 10ms Timer */
    
        
    Timer4_PWM_Setting();       /* PWM Setting */
    Timer8_PWM_Setting();       /* PWM Setting */
    
    IRQ_Setting();          /* IRQ0, IRQ3 setting */
    AD_Setting();           
}


//void InitBldc(void)
//{
//    TC023EN = SET;
//    T03MOD = 0x9B;          // 8usec(PPG)
//    T03REG = ppg_data;       // duty
//    T03PWM = ppg_data/2;     // cycle
//    T03RUN = SET;
//    EF24    = SET;
//}
//
//
//void Bldc_Run(void)
//{
//     InitBldc();
//     BldcOnOffPort = 1;
//}

void init_data(void)
{
    VOLUME_ON = 1;
   
    dsp_addr = POWER_OFF_DISP;

#ifdef TEST_HELP_MODE_JIG // HELP MODE �ڵ�����
    HELP_MODE_SET = SET;
    dsp_addr = HELP_MODE_DSP;
#endif    

    AUTO_ROM_CHK = 1;
    gPowerOnSec = 2;
    gUserSvcModeADJ = USRLANG_ADJ;
    
    VOICE_FLAG1 = 0;
    INIT = 1;
    _EEPROM_READ = 1;

    // BLDC Clear
    //BLDC_VCC_ENABLE = SET;

    fCPI_SEL_MANU_AIRCLEAN       = CLR;
    fCPI_SEL_MANU_BABY           = SET;
    fCLEAN_LAMP_ON_MANU_AIRCLEAN = CLR;
    fCLEAN_LAMP_ON_BABY          = CLR;
    REPEAT_ON = CLR;            // �ݺ����� Flag Clear
    FAST_MODE_ON = CLR;         
    SET_ERROR_FLAG = 0;
    AGING_MODE = CLR;

    //iot_run_status = IOT_STATUS_RUN_MQTT;//IOT_STATUS_RUN_HTTP;   // IoT //IOT_STATUS_RUN_MEF;//
    iot_run_status = IOT_STATUS_INIT_SVC;

    Display_HU_5Min_Cnt = 300;
    TIME_5MIN_FLAG = CLR;
    
    Humi5MinCnt = 300;
    Humi1HourCnt = 3600;

    _clearVariable();

    // TEST ONLY 
    //DUST_SHARP_SENSOR_ENABLE  = 1;
    //GAS_SENSOR_ENABLE         = 1;  
    //DUST_SHARP_SENSOR_ENABLE  = 1;
    //DUST_SENSOR_ENABLE        = 1;

    // TO_DO_LIST:
    //DUST_Init();
    //DUST_EnableSensor(1);
    
    //InitGasSensor();
    
}

// init global variable
void _clearVariable(void)
{
    g1SecCnt              = 0;
    gDisplaySecCnt        = 0;
    gDustDisplaySecCnt    = 0;
    gDustDisplayButtonCnt = 0;   // �̼���ǥ�� clear
    gDisplayOffTimeCnt    = 0;
    gBabyCleanLampOffCnt  = 0;
    gFoscOutCnt           = 0;
    help_delay_time       = 0;
    gBldc_change_delay_time = 0;
    gFoscKeyInOffDelayCnt = 0; // Fosc �Է½� ��ư �Է� ���� ���� (�����Ϸ�)
    voicePlayTestAddr      = 0;
    gLoadStopErrCnt        = 0;
    gVoicePlaySkipCnt      = 0;
    Timer_Data             = 0;
    
    //Gas_Fan_Value_old  = 0xFF; // new Gas_Fan_Value �ʱ� �� 0 �� ������ ���� 
    Gas_Fan_Value  = Gas_Fan_Value_S = 1;
    Dust_Fan_Value = Dust_Fan_Value_S = 1;
    Humi_Fan_Value = Humi_Fan_Value_S = 1;
    
    gPM10_SumData        = 0;
    gPM10_UnitData       = 0;
    gPM10_UnitDataOld    = 0;
    gPM2_5_Concentration = 0;
    gPM2_5_AvgData       = 0;

}

// *******************************************

void port_initial(void)
{
    /*---------------------------------------
    PORT 0 DEFINE
    -------------------------------------
    Bit Function                Dir
    --------------------------------------
    P07 DUST SENSOR ON/OFF(�ſ���)  O   
    P06 ���͵��� ����               I   
    P05 ���� ����                   I   
    P04 ���� ����                   I   
    P03 BLDC(TM8IOB)                0   
    P02 DUST SENSOR P10 (�ſ���)    I   
    P01 OCD_CLK                     O   
    P00 OCD_DATA                    O   
    -----------------------------------*/
    P0DIR = 0x8B;   // 1000 1011    //in/out ����
    P0PLUD = 0x00;  // 0000 0000    //Ǯ��Ǯ�ٿ��
    P0OMD1 = 0x08;  // 0000 1000    /* 1: TM8IOB */
    P0OMD2 = 0x00;  // 0000 0000
    P0ODC = 0x00;   /* All Push-Pull Output */ //���µ巹�� ����
    P0OUT = 0x00;   /* Init Value : 0 */



/*---------------------------------------
    PORT 2 DEFINE
    -------------------------------------
    Bit Function                Dir
    --------------------------------------
    P27 NC                          I   
    P26 NC                          I   
    P25 NC                          I   
    P24 NC                          O   
    
    P23 �������� ���2              O
    P22 �������� ���1              O
    P21 BLDC RPM ����(IRQ1)         I   
    P20 DUST SENSOR P2.5 (�ſ���)   I   
    -----------------------------------*/
    P2DIR = 0x1C;   //0001 1100/*B4 = Out, other In */
    P2PLU = 0x00;   /* No Used Pull Up Function */


/*---------------------------------------
    PORT 3 DEFINE
    -------------------------------------
    Bit Function                Dir
    --------------------------------------
    P37 NC                      I   
    P36 NC                      I   
    P35 VOICE SCLK              O   
    P34 VOICE SSB               O   
    
    P33 CDS SENSOR(AN15)        I   
    P32 NC                      I   
    P31 NC                      I
    P30 NC                      I
    -----------------------------------*/
    P3DIR = 0x30;   //0011 0000
    P3PLU = 0x00;   /* No Used Pull Up Function */
    P3IMD = 0x08;   //0000 1000 /* Input */
    P3ODC = 0x00;   /* Push Pull Output */
    P3OUT = 0x00;   /* Init Value : 0 */



/*---------------------------------------
    PORT 4 DEFINE
    -------------------------------------
    Bit Function                Dir
    --------------------------------------
    P47 OPTION_1                I   
    P46 OPTION_2                I   
    P45 VOICE RESET             O
    P44 VOICE MISO (DATA IN)    I
    
    P43 VOICE MOSI (DATA OUT)   O  
    P42 NC                      I   
    P41 NC                      I   
    P40 NC                      I   
    -----------------------------------*/
    P4DIR = 0x28;   //0010 1000
    P4PLUD = 0x00;  /* No Used Pull Up Function */
    P4ODC = 0x00;   /* Push Pull Output */
    P4OUT = 0x00;   /* Init Value : 0 */


/*---------------------------------------
    PORT 5 DEFINE
    -------------------------------------
    Bit Function                Dir
    --------------------------------------
    P57 EEPROM_DATA             O   
    P56 EEPROM_CLK              O   
    P55 CPI ON/OFF              O   
    P54 NC                      I   
    
    P53 BUZZER ON/OFF           O   
    P52 WIFI MODULE RESET       O   
    P51 MCU_UART(RX)		    I   
    P50 MCU_UART(TX)   			O   
    -----------------------------------*/
    P5DIR = 0xED;   // 1111 1101
    P5PLUD = 0x01;  /* No Used Pull Up Function */
    P5OMD = 0x00;   
    P5ODC = 0x00;   /* All Push-Pull Output */
    P5OUT = 0x00;   /* Init Value : 0 */


/*---------------------------------------
    PORT 6 DEFINE
    -------------------------------------
    P67 RED                     O   
    P66 DISPLAY DATA            O   
    P65 DISPLAY CLK             O   
    P64 BUZZER(TIMER4)          O
    
    P63 DISPLAY STB             O   
    P62 WIFI ON/OFF             O   
    P61 NC                      I   
    P60 NC                      I   
    -----------------------------------*/
    P6DIR = 0xFC;   //1111 1100
    P6PLU = 0x00;   /* No Used Pull Up Function */
    P6OMD = 0x10;   /* B4:TM4IOB*/
    P6ODC = 0x00;   /* All Push-Pull Output */
    P6OUT = 0x00;   /* Init Value : 0 */


/*---------------------------------------
    PORT 7 DEFINE
    -------------------------------------
    Bit Function                Dir
    --------------------------------------
    P77 �ͺ����� ��ư           " I "
    P76 �������� ��ư           " I "  
    P75 ���༳�� ��ư           " I "
    P74 �ٶ����� ��ư           " I "   
    
    P73 �������� ��ư           " I "
    P72 �������� ��ư           " I "   
    P71 BLUE                      O   
    P70 GREEN                     O   
    -----------------------------------*/
    P7DIR = 0x03;    //0000 0011
    P7PLUD = 0x00;  /* No Used Pull Up Function */
    P7ODC = 0x00;   /* All Push-Pull Output */
    P7OUT = 0x00;   /* Init Value : 0 */


/*---------------------------------------
    PORT 8 DEFINE
    -------------------------------------
    Bit Function                Dir
    --------------------------------------
    P87 NC                      I   
    P86 NC                      I   
    P85 NC                      I   
    P84 NC                      I
    
    P83 NC                      I 
    P82 NC                      I   
    P81 SMOG ON/OFF             O
    P80 ����û�� ��ư           I  
    -----------------------------------*/
    //P8DIR = 0x7C;   
	P8DIR = 0x02;    //0000 0010//test
    P8PLU = 0x00;   /* No Used Pull Up Function */
    P8OMD = 0x00;   /* All GPIO */
    P8OUT = 0x00;   /* Init Value : 0 */



/*---------------------------------------
    PORT 9 DEFINE
    -------------------------------------
    Bit Function                Dir
    --------------------------------------
    P97 NC                      I
    P96 NC                      I
    P95 NC                      I
    P94 ��������(AN12)          I
    
    P93 �µ�����(AN13)          I
    P92 SMOG AD(AN14)           I
    P91 NC                      I
    P90 NC                      I   
    -----------------------------------*/
    P9IMD = 0x1C;   // AN14(P2) analog input selection 
	P9DIR = 0x00;   
    P9PLU = 0x00;   // No Used Pull Up Function 
    P9OUT = 0x00;   // Init Value : 0


/*---------------------------------------
    PORT A DEFINE
    -------------------------------------
    Bit Function                Dir
    --------------------------------------
    PA7 NC                      I   
    PA6 NC                      I   
    PA5 NC                      I   
    PA4 NC                      I   
    
    PA3 NC                      O
    PA2 NC                      I
    PA1 NC                      O
    PA0 NC                      I
    -----------------------------------*/
    PADIR = 0x00;   
    PAPLU = 0x00;   // No Used Pull Up Function
    PAIMD = 0x00;   // AN0, AN2 Analog Input setting
    PAOMD1 = 0x00;  // All GPIO
    PAOUT = 0x00;   // Init Value : 0


/*---------------------------------------
    PORT B DEFINE
    -------------------------------------
    Bit Function                Dir
    --------------------------------------
    PB7 NC                      I   
    PB6 NC                      I   
    PB5 NC                      I   
    PB4 NC                      I
    
    PB3 Battery GAUGING(AN11)    I   
    PB2 Battery STAT2            I   
    PB1 Battery STAT1            I   
    PB0 ST_BY_8V                 O   
    -----------------------------------*/
    PBDIR = 0x01;   //0000 0001
    PBPLU = 0x01;   /* No Used Pull Up Function */
    PBIMD = 0x08;   /* Analog Input setting */
    PBOUT = 0x00;   /* Init Value : 0 */
    //LCCTR5 = 0x00;


}


                        

/*---------------------------------------------------
 IRQ0(P20), IRQ3(P23)
----------------------------------------------------*/
void IRQ_Setting(void)
{
    /* Set the external interrupt */
    //IRQCNT  = 0x0A;     /* IRQ1(P21), IRQ3(P23) External interrupt input*/
    IRQCNT  = 0x02;     /* IRQ1(P21), External interrupt input*/
    IRQ1ICR = 0x02;     /* Falling Edge */
                        /* Interrupt Enable */
    //IRQ3ICR = 0x42;     /* Falling Edge */
    //                    /* Interrupt Enable */

}

/*---------------------------------------------------
Timer 0 : General Timer
   fpll_div : 8MHz
   Period : (1/(fpll_div/32)) * 125 = 0.5ms
----------------------------------------------------*/
void Timer0_Setting(void)
{
    TM0OC = 125 - 1;
    TM0MD = 0x01;       /* Not use cascade function */
                        /* Timer1 STOP */
                        /* Clock : prescaler output */
    CK0MD = 0x04;       /* Clock Source : 0100: fpll-div/32*/
    
    TM0MD |= 0x08;      /* Timer1 START */
    TM0ICR = 0x82;      /* Interrupt Level : 2 */
                        /* Timer 1 Interrupt Enable */
}

/*---------------------------------------------------
Timer 1 : General Timer
   fpll_div : 8MHz
   Period : (1/(fpll_div/64)) * 250 = 2ms
----------------------------------------------------*/
void Timer1_Setting(void)
{
    TM1OC = 250 - 1;
    TM1MD = 0x01;       /* Not use cascade function */
                        /* Timer1 STOP */
                        /* Clock : prescaler output */
    CK1MD = 0x04;       /* Clock Source : fpll_div/64*/
    
    TM1MD |= 0x08;      /* Timer1 START */
    TM1ICR = 0x82;      /* Interrupt Level : 2 */
                        /* Timer 1 Interrupt Enable */
}

/*---------------------------------------------------
    Timer 7 : timer 7
    Period : (fpll_div/16)*5000 = 10msec
----------------------------------------------------*/
void Timer7_Setting(void)
{

    TM7MD1 = 0x0c;      //1100: 1/16 of clock
    TM7MD2 = 0x78;       //0x78
    TM7MD3 = 0x00;      /* PWM STOP : Level Low */
                        /* Output level polarity : Normal  */
    TM7MD4 = 0x00;      /* timer7 output */
    TM7PR1 = 5000;
    //TM7PR2 = 250;
    TM7MD1 |= 0x10;     /* Timer START */
    TM7ICR = 0x82;      /* Interrupt Level : 2 */
                        /* Timer 7 Interrupt Enable */
    
}
/*---------------------------------------------------
Timer 4 : PWM OUT
   Period : (fs/4)*256 = 15.625KHz
----------------------------------------------------*/
void Timer4_PWM_Setting(void)
{
    CK4MD = 0x03;       /* Clock Source : fs/4 */
    TM4OC = 0x80;       /* Duty : 50% */
    TM4MD = 0x11;       /* PWM */
                        /* Clock : prescaler */
    TM4ICR = 0xc0;      /* Interrupt Disable */
    TM4MD |= 0x08;      /* PWM START */
}

/*---------------------------------------------------
Timer 8 : PWM OUT => BLDC VSP ����
   125ns
   fpll_div : 8MHz
   Clock : fpll_div
   BC : 
   Period :
----------------------------------------------------*/
void Timer8_PWM_Setting(void)
{
    TM8MD1 = 0x00;      // 8Mhz
    TM8MD2 = 0x78;      //0x78
    //TM8MD3 = 0x04;      // PWM STOP : Level High
    TM8MD3 = 0x00;      // PWM STOP : Level High
                        // Output level polarity : Normal
    TM8MD4 = 0x00;      // timer7 output
    
    TM8PR1 = FANPERIODDUTY-1;
}



/*---------------------------------------------------
A/D
    Port: AN setting : Convertion time = 40us
----------------------------------------------------*/
void AD_Setting(void)
{
    //ANCTR0 = 0x;  // TO_DO_LIST: TEST ONLY
    //ANCTR0 = 0x28;      /*  0x4c Tad x 18 = 1us x 18 = 18us */
                        /* Tad = fs/16 = 8MHz/16 = 1Mhz = 1us */
                        /* Ladder Res On */
	ANCTR0 = 0x28; 					
    ANCTR1 = 0x00;      /* AD Start Chn */
    ANCTR2 = 0x00;      /* AD Stop */
                        /* AD Start : ANST Set to 1  */
}
