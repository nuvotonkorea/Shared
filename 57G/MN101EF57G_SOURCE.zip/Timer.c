/******************************************************************************
**
**  COPYRIGHT (C) 
**
**  THIS WORK CONTAINS TRADE SECRET AND PROPRIETARY INFORMATION WHICH IS
**  THE PROPERTY OF CUCKOO
**
**  PROJECT NAME:  
**
**  FILENAME:       .c
**
**  PURPOSE:        
**
**  FUNCTIONS:      
**
**  AUTHOR:
**
**  VERSION:        1.0
**
**  LAST MODIFIED:  
******************************************************************************/
/*****************************************************************************
Note:
2015-04-10 : 
*******************************************************************************/
#include	"typedef.h"
#include	"srMN101EF57G.h"
#include	"main.h"
#include    "global_func.h"
#include	<stdlib.h>
#define		ROOT
#include	"DustSensor.h"
#include    "cmn_type.h"
#include    "uart.h"
#include    "wifi.h"

void Load_on_off(void);
void Option_Check(void);
void ReadModelOption(void);
void Freequency_check(void);
void Ext_time_100mS(void);
void Hz_check(void);
void ProcessTimeCnt(void);
void ProcessTimeChk(void);
void ReservationTimerCnt(void);
void CheckFilterWorkTime(void);
void CheckTurboRunTime(void);
void CheckInit3MinCnt(void);
void CheckInit5MinCnt(void);    //����ǥ��

void Humi5MinCheck(void);
void Humi1HourCheck(void);
extern Check_BldcRpm(void);
extern void DisplayScan(void);
//extern void DisplayScan_TK18A(void);   //AJH 160629
extern const unsigned int	gAirLevelVoiceAddrTbl[];

extern BIT8_t	sUARTFlag;
#define	f100msCheck sUARTFlag.b1 // 100ms ���� set �ʿ�
#define f10msCheck sUARTFlag.b2  
#define f1msCheck sUARTFlag.b3  

//extern const unsigned int	Timer_Data_TBL[];

// 10 msec Timer: OK
#pragma _interrupt Inttca0_10msec
void  Inttca0_10msec()
{
    unsigned char fast_data;
    unsigned char i;
    unsigned int sec_cnt,display_cnt;
    
	
    //P8OUT0 ^= SET; // debug only
    if(_EEPROM_READ) return;

    KEY_TIME = 1;
    
    // Main ������ ������ 
	//if(AUTO_ROM_CHK) 
	//    Flashrom_check();
    
    if(FAST_MODE_ON)
    {
         sec_cnt = 1;      // 0.01 sec count
         display_cnt = 50;  //   5 sec count
    }
    else 
    {
        sec_cnt = 100;      //  1 sec count
        display_cnt = 10;   // 10 sec count
    }
    
    Ext_time_100mS();
		
	dsp_1S_cnt++;
	if(dsp_1S_cnt >= sec_cnt)      // 1sec setting
	{
		dsp_1S_cnt = 0;
		
        TOGGL_1SEC = ~TOGGL_1SEC;
        TIME_FLAG = 0xFF;
		PStop_1sec_check = 1;   //codeless

		//AJH 160609 ������� ǥ�� ī���� 
		if(Humidisplay_timer < 10 && POWER_ON)
		{
		    Humidisplay_timer++;
		}
		else
		{
		    Humidisplay_timer = 0;
		}
		//AJH 160609
		if(error_count) error_count--;
		if(help_delay_time) help_delay_time--;
		if(gBldc_change_delay_time) gBldc_change_delay_time--;
		if(g1SecCnt) g1SecCnt--;
		if(gDisplaySecCnt) gDisplaySecCnt--;
		if(gDisplayOffTimeCnt) gDisplayOffTimeCnt--;
		if(gPowerOnSec) gPowerOnSec--;
	    if(HumiWaterLackToggleCnt) HumiWaterLackToggleCnt--;    //��������û���� �������� ���� count
		//if(CleanMaintain_Timer) CleanMaintain_Timer--;  //��������
        //if(DustCleanMaintain_Timer) DustCleanMaintain_Timer--;
        //if(CleanMaintain_RoomTimer) CleanMaintain_RoomTimer--;  //ROOM
        //if((MenuMode == MENU_AIRCLEAN_ROOM) && CleanMaintain_LowLevel_Cnt) CleanMaintain_LowLevel_Cnt--;    //AJH 160812 ROOM CARE
        if(Dust_level_fast_up_cnt) Dust_level_fast_up_cnt--;
        if(gHelpModeEnterCnt) 
        {
            if(gHelpModeEnterCnt == 1)
            {
                if(gHelpModeEnterStep) gHelpModeEnterStep = 0;
            }
            
            gHelpModeEnterCnt--;
        }
        if(gMonitorModeEnterCnt)
        {
            if(gMonitorModeEnterCnt == 1)
            {
                if(gMonitorModeEnterStep) gMonitorModeEnterStep = 0;
            }

            gMonitorModeEnterCnt--;
        }
        if(gSelfCheckEnterCnt) gSelfCheckEnterCnt--;
        if(gFilterResetDisplayCnt) gFilterResetDisplayCnt--;
        if(gDustDisplayButtonCnt) gDustDisplayButtonCnt--;
        if(gFilterWorktimeCnt) gFilterWorktimeCnt--;
        if(gFoscDisplayOffDelayCnt) gFoscDisplayOffDelayCnt--;
        if(gFoscKeyInOffDelayCnt) gFoscKeyInOffDelayCnt--; // Fosc �Է½� ��ư �Է� ���� ���� (�����Ϸ�)
        if(gBabyCleanLampOffCnt) gBabyCleanLampOffCnt--;
        if(gLedDimmingChkCnt && gUsrLedDimming) 
        {
            if(!HELP_MODE_SET && !MONITORING_MODE && !fUSER_SVC_MODE_SET) gLedDimmingChkCnt--;
        }
        
            
		if(++gDustDisplaySecCnt >= display_cnt) gDustDisplaySecCnt = 0;
		
		if(uiPacking_mode_flag_count) uiPacking_mode_flag_count--;	//codeless	

		
		// ������ Check sum �� �������: ���� ���, Aging �ÿ��� checksum �˻��� (������� ��������)
		//if(AUTO_ROM_CHK && POWER_ON == SET && !FAST_MODE_ON)
		//{
		//    // �ڰ����� ��� ���� ����:  1�ð��� 1ȸ+ ���� �ΰ� 1�ð�+���� ��尡 �ƴҽ�
    	//	// ���� ���� �ڰ����ܱ�� SKIP
    	//	if(++gAutoRomCheckCnt >= 3600)
    	//	{
    	//	    gAutoRomCheckCnt = 0;
   		//        AUTO_ROM_CHK = 0;
    	//	}
    	//}
    	//else
    	//{
    	//    gAutoRomCheckCnt = 0;
    	//}

		//Bldc_RpmRevision(); //PP:100ms timer �� �����
        //Bldc_ErrorCheck();
		DustSensorAvg();
		ProcessTimeCnt();
		//ReservationTimerCnt();
        CheckFilterWorkTime();
        //Gas3HrCheck();
        WaterLack5MinCheck();
        //CheckTurboRunTime();
        CheckInit3MinCnt();
        CheckInit5MinCnt(); //����ǥ��
        if(POWER_ON)
        {
            Humi5MinCheck();
            Humi1HourCheck();
        }
        
        if(CleanMaintain_Timer) CleanMaintain_Timer--;  //�������� �����ð�
        if(HumiMaintain_Timer) HumiMaintain_Timer--;  //�ڵ����� �����ð�
        if(DustCleanMaintain_Timer) DustCleanMaintain_Timer--;  //�������� �����ð�
        if(CleanMaintain_RoomTimer) CleanMaintain_RoomTimer--;  //���ɾ� �����ð�
        if((MenuMode == MENU_AIRCLEAN_ROOM) && CleanMaintain_LowLevel_Cnt) CleanMaintain_LowLevel_Cnt--;    //AJH 160812 ROOM CARE
        ReservationTimerCnt();
        CheckTurboRunTime();
        /*
        if(FOSC_OUT)
        {
            if(CleanMaintain_Timer) CleanMaintain_Timer--;  //�������� �����ð�
            if(HumiMaintain_Timer) HumiMaintain_Timer--;  //�ڵ����� �����ð�
            if(DustCleanMaintain_Timer) DustCleanMaintain_Timer--;  //�������� �����ð�
            if(CleanMaintain_RoomTimer) CleanMaintain_RoomTimer--;  //���ɾ� �����ð�
            if((MenuMode == MENU_AIRCLEAN_ROOM) && CleanMaintain_LowLevel_Cnt) CleanMaintain_LowLevel_Cnt--;    //AJH 160812 ROOM CARE
            ReservationTimerCnt();
            CheckTurboRunTime();
        }
        */
	}
		
	Option_Check();
	Load_on_off();
	Bldc_control();
	f10msCheck = SET;  // 10mse ���� set
}

//0.5 msec Timer: OK
#pragma _interrupt Inttc00_1msec
void  Inttc00_1msec(void)
{
    //AJH 160320 �������� �߰�����(START)
    //P8OUT0 ^= SET; // debug only
    ToggleCtrlReg++;
    if(t_0bit == SET)
    {
        HU_PWM1_PORT = 1;
        HU_PWM2_PORT = 0;
        
        //HU_PWM1_PORT = 0;
        //HU_PWM2_PORT = 0;
        Cds_ad();
        Th_ADC_Svc();
    }
    else
    {
        HU_PWM1_PORT = 0;
        HU_PWM2_PORT = 1;
        
        //HU_PWM1_PORT = 0;
        //HU_PWM2_PORT = 0;
        Humi_05ms = SET;
        Hu_ADC_Svc();
        Battery_voltage_ad();   //codeless
    }

    time_cnt_1mS++;
    if(time_cnt_1mS >= 2)
    {
        time_cnt_1mS = 0;
        DUST_ReadSensorStatus();
        
        f1msCheck = SET;
    }
    //AJH 160320 �������� �߰�����(END)
    //DUST_ReadSensorStatus();
    
    // TEST ONLY
    //MoodBrightnessControl();
}

//2 msec Timer: OK
#pragma _interrupt Inttc01_2msec
void  Inttc01_2msec(void)
{

     if(_EEPROM_READ) return;
     Hz_check();
     Check_BldcRpm();

     time_cnt_10mS++;
     if(time_cnt_10mS >= 5)
     {
          time_cnt_10mS = 0;
          EEPROM_WRITE_TIME = 1;
          //if(voice_safety_time) voice_safety_time--;
          if(voice_10ms_timer) voice_10ms_timer--;
          //if(voice_drv_timer) voice_drv_timer--;
          AD_10mS = 1;
          
          
          continue_time++;
          if(continue_time > 100)
          {
               continue_time = 0;
               //if(water_out_time) water_out_time--;
          }
     }
}

/*
//0.520sec Timer:
void __interrupt inttbt_IDLE(void)
{
	unsigned char i = 0;
//	STANDBY_VPP= ~STANDBY_VPP;
	//if(		ucSleep_mode_flag == 1)
	//{
		//if(TURBO_KEY_IN||ION_GEN_KEY_IN||TIMER_KEY_IN||WCAP_KEY_IN||MODE_KEY_IN||POWER_KEY_IN||CLEAN_LAMP_KEY_IN)
		//	ucSleep_mode_flag = 0;

	//}
	if(ucSleep_mode_flag == 1)
	{
	
		if(HELP_MODE_SET)	// 2017_0117_adh
		{
			XEN = ON;
			SYSCK = OFF;
			ucSleep_mode_flag = 0;
			STAND_BY_POWER  = ON;
			return;
		}

		for(i = 0 ; i < 39; i++)	// �ѹ� ���ͷ�Ʈ �߻� �� Ƚ���� �÷� Sleep mode���� ���� �������ü� �ֵ��� ����
		{
			//CE_40210 = SET;
			if(  TURBO_KEY_IN||ION_GEN_KEY_IN||TIMER_KEY_IN||WCAP_KEY_IN||MODE_KEY_IN||POWER_KEY_IN||CLEAN_LAMP_KEY_IN
				 ||Battery_STAT1||Battery_STAT2 )
			//   ||     ((Battery_STAT1==0) && (Battery_STAT2==1))   ||   ((Battery_STAT1==1) && (Battery_STAT2==0))    )
			{
					XEN = ON;
					SYSCK = OFF;
					ucSleep_mode_flag = 0;
					STAND_BY_POWER  = ON;
					break;
			}
			//CE_40210 = CLR;
		}
	}
}
*/



// External Interrupt (Fosc)
#pragma _interrupt Ext_int4
void  Ext_int4(void)
{
    unsigned char fast_data;    //AJH 160604

    FOSC_OUT = 0;
    FOSC_DSP_OFF = 0;
    fosc_count = 0;
    
	if(gFoscKeyInOffDelayCnt)	gFoscKeyInOffDelayCnt = 0;  // ���� �Ҿ����� ��ư�Է��� �ȵǴ°� ���� (�����Ϸ�)

    Freequency_check();
    //AJH 160604 FOSC 1SEC COUNTER

	if(FAST_MODE_ON)
	{
	    fast_data = 6;
	    if(freequency_data == 5) fast_data = 5;
	}
	else
	{
	    fast_data = 60;
	    if(freequency_data == 5) fast_data = 50;
	}

	time_1S_cnt++;
	if(time_1S_cnt >= fast_data)      // 1sec setting
	{
	    time_1S_cnt = 0;
	    
	   // if(!FOSC_OUT)
	   // {
       //     if(CleanMaintain_Timer) CleanMaintain_Timer--;  //�������� �����ð�
       //     if(HumiMaintain_Timer) HumiMaintain_Timer--;  //�������� �����ð�
       //     if(HumiMaintain_Init_Timer && (MenuMode == MENU_AIRCLEAN_HUMI)) HumiMaintain_Init_Timer--;
       //     if(RoomMaintain_Init_Timer && (MenuMode == MENU_AIRCLEAN_ROOM)) RoomMaintain_Init_Timer--;
       //     if(DustCleanMaintain_Timer) DustCleanMaintain_Timer--;
       //     if(CleanMaintain_RoomTimer) CleanMaintain_RoomTimer--;  //ROOM
       //     if((MenuMode == MENU_AIRCLEAN_ROOM) && CleanMaintain_LowLevel_Cnt) CleanMaintain_LowLevel_Cnt--;    //AJH 160812 ROOM CARE
       //     ReservationTimerCnt();
       //     CheckTurboRunTime();
	   // }
	}
    //AJH 160604 FOSC 1SEC COUNTER
}


// 10m timer sub func
void Ext_time_100mS(void)
{
     unsigned char hz_data;

     //hz_data = 6;
     //if(freequency_data == 5) hz_data = 5;
     // TO_DO_LIST: Fosc ���ܿ� ���� ���� : Fosc -> 10msec timer
    if(FAST_MODE_ON) hz_data = 1; // ���� ��忡���� 10�� ������
    else hz_data = 10; 
     
     dsp_100mS_cnt++;
     if(dsp_100mS_cnt >= hz_data)
     {
     	dsp_100mS_cnt = 0;
     	if(delay_2sec) delay_2sec--;
     	if(help_delay_count) help_delay_count--;
     	if(voice_drv_timer) voice_drv_timer--;
     	if(touch_lock_display_time) touch_lock_display_time--;
     	if(reserve_display_time) reserve_display_time--;
        if(gBtnLedOffCnt) gBtnLedOffCnt--;
     	if(gBtnWCapLedOnOffCnt) gBtnWCapLedOnOffCnt--;

		if(at_cmd_wait_timer > 0)       at_cmd_wait_timer--;            //iot000
        if(iot_reset_timer > 0)         iot_reset_timer--;              //iot000
        //if(send_post_timer > 0)         send_post_timer--;              //iot000
        if(gUartSendFlag>0)             gUartSendFlag--;

     	TOGGL_100 = 1;
     	DSP_TIME = 1;			// ���÷���
     	DSP_TGL = ~DSP_TGL;
		AD_100mS = 1;
		DISPLAY_100mS = 1;

        // TO_DO_LIST: ������
     	//if(cold_level_cnt) cold_level_cnt--;
     	//if(delay_heater_onf_time) delay_heater_onf_time--;
     	//if(delay_comp_onf_time) delay_comp_onf_time--;
     	//if(pump_delay_time) pump_delay_time--;
     	//if(salkyun_over_delay_time) salkyun_over_delay_time--;     	
     	//DUTY_100mS = 1;				// ���ͱ���

        //DisplayScan();
        ProcessTimeChk();
        Bldc_RpmRevision();     // PP ���� ����
        CheckBldcDelayStop();
        
		TIME_01S_FLAG = 0xFF;
		
     	if(DSP_TGL)
     	{
     		AUTO_200mS = 1;               // 200mS
     	}
     	dsp_500mS_cnt++;
     	if(dsp_500mS_cnt >= 5)
     	{
     		dsp_500mS_cnt = 0;

     		TOGGL_500 = ~TOGGL_500;
     		TIME_05S_FLAG = 0xFF;
     	}

        f100msCheck = SET;  // 100mse ���� set

     }          
}

// 10m timer sub func
void Option_Check(void)
{
     unsigned char option_count;
     
     tempf8 = 0;
     if(OPTION1_PORT) tempf8 = tempf8 | 0x01;
     else tempf8 = tempf8 & 0xFE;
     
     if(OPTION2_PORT) tempf8 = tempf8 | 0x02;
     else tempf8 = tempf8 & 0xFD;
     
     //if(OPTION3_PORT) tempf8 = tempf8 | 0x04;
     //else tempf8 = tempf8 & 0xFB;

     if(tempf8 == save_tempf8)
     {
          //option_count = 30;  
          //if(freequency_data == 5) option_count = 25;
          // TO_DO_LIST: Fosc -> 10msec timer
          option_count = 50; // 0.5sec

          option_check_count++;
          if(option_check_count >= option_count)
          {
               option_check_count = 0;
               //ReadModelOption();
               if(OPTION2_PORT) CH_MODEL_FLAG = SET;
               else CH_MODEL_FLAG = CLR; 
          }
     }
     else
     {
          save_tempf8 = tempf8;
          option_check_count = 0;
     }
     
#ifdef TEST_CH_MODEL_OPT
     CH_MODEL_FLAG = SET;
#endif

}

void ReadModelOption(void)
{
    if(OPTION1_PORT && OPTION2_PORT) 
        model_option = MODEL_OPTION_KOR;  // OPTION1, OPTION 2 �̻� (HIGH)
    else if(OPTION1_PORT && !OPTION2_PORT) 
        model_option = MODEL_OPTION_MALAY; // OPTION 2 ���� (LOW)
    else 
        model_option = MODEL_OPTION_CHN;   // OPTION 1 ���� (LOW)
}


// *************************************

void Freequency_check()
{
	external_count++;
	if(external_count >= 100)		                    // (50hz = 20mS, 60hz = 16.67mS) * 100 --> (50hz = 2000mS, 60hz = 1667mS)
	{                                                      // 
		if(hz_count < 2166/2 && hz_count > 1501/2)
		{
			if(hz_count > 1834/2) freequency_data = 5;
			else freequency_data = 6;
		}
		external_count = 0;
		hz_count = 0;
	}
}

// ********************************************************************************
void Load_on_off(void)
{
	switch(load_on_step)
	{
        // CPI
        case 0:
            if(fCCPI_ON) 
            {
//                ION_GEN_PWR  = SET;
                ION_GEN_CTRL = SET;
                //UV_LED_ON = SET;            //AJH UV LED TEST
            }
            else
            {
//                ION_GEN_PWR  = CLR;
                ION_GEN_CTRL = CLR;
                //UV_LED_ON = CLR;           //AJH UV LED TEST
            }
            load_on_step = 1;
        break;
        
        // DUST
        case 1:
            load_on_step = 0;
        break;
        
        // GAS SENSOR
        case 2:
            load_on_step = 0;
        break;
        
        default:
            load_on_step = 0;
          break;
     }
}

// 2msec 
void Hz_check(void)
{

	//if(FOSC_OUT) return;

	ext_count++;
	if(external_count) hz_count++;
	/*codeless
	fosc_count++;

	if(fosc_count >= 50)     // ����mode ����
	{
		fosc_count = 0;
	
		
		// Fosc �Է½� ��ư �Է� ���� ���� (�����Ϸ�)
		gFoscKeyInOffDelayCnt = 6;  // Fosc ���� �� 1�� �� 5�ʰ� �� KEY �Է� ����

        gFoscDisplayOffDelayCnt = 1;
		FOSC_DSP_OFF = 1;   // 2�� �� DISPLAY OFF ��Ŵ
        FOSC_OUT = 1;

		if(HELP_MODE_SET == SET)
		    eeprom_addr_w[HELP_MODE_ADDR] = 1;	// help mode���� �Ŀ��ڵ� Ż�Ž�
		else
		    eeprom_addr_w[HELP_MODE_ADDR] = 0;
		
		if(POWER_ON == SET) 
		{
		    if(AGING_MODE == SET)
		        eeprom_addr_w[USR_POWER_ON_ADDR] = POWER_STATUS_AGING_MODE;
		    else
		        eeprom_addr_w[USR_POWER_ON_ADDR] = POWER_STATUS_NORMAL_MODE;
		}
        else 
            eeprom_addr_w[USR_POWER_ON_ADDR] = POWER_STATUS_INIT_MODE;

        VoiceOutOne(VOICE_STOP_CODE,5); // ���� ���� // stop code

    	// �������� �ƴ� ��쿡�� ���� ���� ��Ŵ. + ���� �߻��߿��� ���� ���� ��Ŵ
    	
		//if(f_Working_MT == CLR)
		if(POWER_ON == CLR)
        {  
            // 5V ���� ����
            GAS_SENSOR_ENABLE        = SET; // Gas ���� Enable 
            DUST_SENSOR_ENABLE       = SET; // ���� ���� Enable
        }
	}
	*/
}

//====================================================
//      TIME BASE CLEAR ROUTINE 
//====================================================
void TimeBaseCLR10mS(void)
{
    T10mS = 0;
    return;
}

void TimeBaseCLR100mS(void)
{
    //BlkFlg = CLR;
    f100ms = CLR;
    T100mS = 0;
    TimeBaseCLR10mS();
    return;         
}

void TimeBaseCLR1min(void)
{
    f1min = CLR;
    T60Sec = 0;
    TimeBaseCLR100mS();
    return;
}

void TimeBaseCLR24H(void)
{
    T24Hour = 0;
    T60Min = 0;
    TimeBaseCLR1min();
    return;
}

//====================================================
//  FUNC. Flow  : (1s routine)
//
//  Description : Process Time Count  Routine [1sec]
//====================================================
void ProcessTimeCnt(void)
{
    if(PrTm60S > 0)
    {
        (PrTm60S)--;
    }
    else
    {
        if(PrTm60M > 0)
        {
            (PrTm60M)--;
            PrTm60S = 59;
        }       
    }
    return;
}                                                     

//====================================================
//  FUNC. Flow  : (100ms routine)
//
//  Description : Process Time Check Routine [100ms]
//====================================================
void ProcessTimeChk(void)
{
    if(PrTm60S == 0 && PrTm60M == 0)
    {
        fPROCESS_TIME_OVER = SET;         // set Process Time Over Flag
        return;
    }
    
    fPROCESS_TIME_OVER = CLR;             // clr Process Time Over
    return;
}

//====================================================
//   Timer Count  Routine [1sec]
//   ���� �ð� Timer count routine
//====================================================
void ReservationTimerCnt(void)  
{
	if(Timer_Step != 0 || AGING_MODE == SET)
	{
		if(Timer_Data) 	// �������� ����?
		{
			Timer_Data--;
			if(!Timer_Data)
			{
				if(POWER_ON == SET)
				{
					Power_Off_Exe();
				}
				else
				{
					Power_On_Exe();
				}
				
				// �ݺ����� ���۽� ����
				if(REPEAT_ON == SET && MenuMode == MENU_AIRCLEAN_REPEAT)
                {
                     Timer_Data = Timer_Data_TBL[Timer_Step];
                }
			}
			else 
			{
			    // 3���� ������ ������
				//if(Timer_Data == 0x0003)	// 3����?
				//{
				//	//key_buzzer_com();
				//	VoiceOutOne(0xCC, 0);
				//}
			}
		}
	}
}

void CheckFilterWorkTime(void)
{
    /*
    if(eeprom_addr_r[USR_FILTER_SWITCH_ADDR]
    */
    if(POWER_ON == SET)
	{
		// Increment [ 0 - 59 Sec ]
		//
		(T60Sec)++;
		if(T60Sec < 60) return;

		T60Sec = 0;
	    
	    
		// Increment [ 0 - 59 Min ]
		f1min = SET;				// set 1Min flag
		(T60Min)++;				    // inc 1Min count
		if(T60Min < 60) return;

		T60Min = 0;
		T24Hour++;
		
		TDivide = T24Hour / 256;

		gFilterWorktimeLow = (T24Hour - (256 * TDivide));
		gFilterWorktimeHigh = TDivide;
		
		eeprom_addr_w[USR_FILTER_WORKL_ADDR] = gFilterWorktimeLow;
		eeprom_addr_w[USR_FILTER_WORKH_ADDR] = gFilterWorktimeHigh;
		
		if((gFilterWorktimeHigh >= 34) && (gFilterWorktimeLow >= 56))		//365�� ��� : 24*365�� = 8760 = 0x2238
		{
			fFILTER_SWITCH_ALARM = 1;       // ���� ��ü ǥ�� flag
		}
		
		if((gFilterWorktimeHigh >= 34) && (gFilterWorktimeLow >= 80))		//366�� ��� : 24*366�� = 8784 = 0x2250
		{
		    fFILTER_SWITCH_ALARM = 0;       // ���� ��ü ǥ�� flag �ʱ�ȭ
			gFilterWorktimeHigh  = gFilterWorktimeLow = 0;       // ���� ��ü ǥ�� flag
			T24Hour = 0;
		}
	}
    return;
}

// 1sec call
void CheckTurboRunTime(void)
{
    if(MenuMode == MENU_AIRCLEAN_TURBO)
    {
        if(gTurboRunTimeSecCnt) 
        {
            // ���� ����(6000) �� �ƴϸ� �ð����
            if(gTurboRunTimeSecCnt != 6000) gTurboRunTimeSecCnt--;
        }
        else
        {
            MenuMode = MenuMode_S;  
            if(glOneM2MConnectOK) fChgIotMenuMode = 1;
            TURBO_ON = 0;
            
            //if(FOSC_OUT != SET)// || (gFoscDisplayOffDelayCnt != 0))
	        //{   // ���� Ż�� �������� ��� ���� �ȳ� ���� => �ͺ����� �� ���� Ż�Ž� ���� �ȳ� ���� ����
                VoiceOutOneSvc(0x3C,0, BEEP_ADDR_BUTTON); //�ͺ� ����û���� �����մϴ�.
            //}
            
            if(MenuMode == MENU_AIRCLEAN_MANU)
            { // ���� ����û���� ��� ���� FAN �ӵ� �� ����, û���� �ɼ� ���� ����
                gSelMotorStep = eeprom_addr_r[USR_MOTOR_STEP_ADDR];
                fCPI_ON = fCPI_SEL_MANU_AIRCLEAN;
            }
            else if((MenuMode == MENU_AIRCLEAN_BABY) || (MenuMode == MENU_AIRCLEAN_BED_TIME))
            {
                gDisplayOffTimeCnt = ENERGY_EYE_DISPLAY_TIME;  // 5�ʰ� DISPLAYǥ��
            }
            else if(MenuMode == MENU_AIRCLEAN_REPEAT)
            {
                REPEAT_ON = SET;
                
                if(Timer_Data) 
                {
                    Timer_Data_Tmp = Timer_Data;
                    Timer_Step_Tmp = Timer_Step;
                }
                else
                {
                    Timer_Data_Tmp = Timer_Step_Tmp = 0;
                }
                
                 if(Timer_Step == 0) Timer_Step = 1;                              // 1�ð� 
                 Timer_Data = Timer_Data_TBL[Timer_Step];
            }
            else if(MenuMode == MENU_AIRCLEAN_ROOM)
            {
                if(Dust_Fan_Value_S >= 4 && Dust_Fan_Value_S < 6)
	            {
	                CleanMaintain_RoomTimer = RoomTimer_Value2;
	            }
	            else if(Dust_Fan_Value_S == 6)
	            {
	                CleanMaintain_RoomTimer = RoomTimer_Value;
	            }
	            else
	            {
	                CleanMaintain_RoomTimer = 60;
	            }
            }
        }
    }
}

// 1sec call: ���� �ΰ� �� 3�� ����ȭ ���� check Count
void CheckInit3MinCnt(void)
{
    unsigned int cleanVoiceAddr;
    
    if(POWER_ON==CLR) return;
    
    if(gAirCleanInit3Min_Cnt) 
    {
        gAirCleanInit3Min_Cnt--;
        fGAS_SENSOR_INIT_3MIN = CLR;
    }
    else
    {
        fGAS_SENSOR_INIT_3MIN = SET;

        if(fAIR_LEVEL_VOICE_ALARM == CLR)
        {
            //���� ���� �� �ƹ� ��ư �Է� ���� ���� ����ȭ �� ���  ���� ���� �ȳ�
            fAIR_LEVEL_VOICE_ALARM = SET;
            
            // �����߰� : ������� => 2�� PILOT ǰ��ȸ
            // ���� ���� �ڵ�,Ȳ�� ������ ��� 
            //if( ((MenuMode==MENU_AIRCLEAN_AUTO)||(MenuMode==MENU_AIRCLEAN_YELLOW_DUST)) && fCLEAN_LAMP_ON)
            //{
            //    cleanVoiceAddr = gAirLevelVoiceAddrTbl[gTotalAirLevel];
            //    //"�ǳ� ȯ���� ���� �մϴ�./�ǳ� ȯ���� ��ȣ �մϴ�./�ǳ� ȯ���� ���� �����Դϴ�.�ǳ� ȯ���� �ſ� ���� �����Դϴ�."
            //    VoiceOutOneSvc(cleanVoiceAddr,0,NONE_BEEP);   
            //}
        }
    }
}
// ����ǥ�� 5MIN COUNT
void CheckInit5MinCnt(void)    //����ǥ��
{
    if(Display_HU_5Min_Cnt)
    {
        Display_HU_5Min_Cnt--;
    }
    else
    {
        Display_HU_5Min_Cnt = 300;
        TIME_5MIN_FLAG ++;
    }
}

void Humi5MinCheck(void)
{
    if(Humi5MinCnt)
    {
        Humi5MinCnt--;
    }
    else
    {
        HUMI_5MIN = SET;
        Humi5MinCnt = 300;
    }
}

void Humi1HourCheck(void)
{
    if(Humi1HourCnt)
    {
        Humi1HourCnt--;
    }
    else
    {
        HUMI_1HOUR = SET;
    }
}

//=====================================================
// REF TO_DO_LIST: ���� ������ 
//=====================================================
//void Dsp_data_out();
//void Display_transfer();
//void MoodDisp_data_out(void);
//void MoodDisplay_transfer(void);

// 160 usec Timer: OK
//void __interrupt Inttc02_160usec()
//{
//     if(_EEPROM_READ) return;
//     Display_transfer();
//     //MoodDisplay_transfer();
//}

// FOSC ���
//void __interrupt Ext_int1()
//{
//    unsigned char fast_data;
//
//    if(_EEPROM_READ) return;
//
//	if(ext_count > 6)
//	{ 
//	     KEY_TIME = 1;
//	     FOSC_IN = 1;
//	     
//		if(AUTO_ROM_CHK) Flashrom_check();
//	     
//		Freequency_check();
//        Ext_time_100mS();
//
//		fast_data = 60;
//		if(freequency_data == 5) fast_data = 50;
//		
//		dsp_1S_cnt++;
//		if(dsp_1S_cnt >= fast_data)      // 1sec setting
//		{
//			dsp_1S_cnt = 0;
//			
//            TOGGL_1SEC = ~TOGGL_1SEC;
//            TIME_FLAG = 0xFF;
//			
//			if(error_count) error_count--;
//			if(continue_delay_time && !WATER_RUN_AUTO) continue_delay_time--;
//			if(water_out_max_time) water_out_max_time--;
//			if(yeyak_time) yeyak_time--;
//			
//			if(help_delay_time) help_delay_time--;
//			if(hot_in_valve_delay_time) hot_in_valve_delay_time--;
//			if(salgyun_kit_off_time) salgyun_kit_off_time--;
//			
//		}
//		
//		Option_Check();
//		Load_on_off();
//		Switch_check();
//		Buzzer_control();
//		
//		FOSC_OUT = 0;
//		FOSC_DSP_OFF = 0;
//		fosc_count = 0;
//	}
//	ext_count = 0;
//}

// 160us Timer
//void Display_transfer()
//{
//     if(DSP_INIT_EEPROM) return;
//     if(dsp_update_flag) return;
//     if(!display_flag)
//     {
//          switch (display_dtep)
//          {
//               // command 1
//               case 0:
//                    DISPLAY_MODULE_CS = 0;
//                    display_dtep = 1;
//                    write_data = COMMAND_GRID_SEG;          
//                    data_out_count = 0;
//                    clock_flag = 0;
//               break;
//
//               case 1:
//                    if(!clock_flag) data_out_count++;
//                    
//                    if(data_out_count <= 8) Dsp_data_out();
//                    else
//                    {
//                         data_out_count = 0;
//                         DISPLAY_MODULE_CS = 1;
//                         display_dtep = 2;
//                    }
//               break;
//               
//               // command 2
//               case 2:
//					if(FOSC_OUT) write_data = COMMAND_OFF;
//					else
//					{
//						if(JELJEON_SET && LIGHT_SENSING) write_data = COMMAND_ON_YAK;
//						else write_data = COMMAND_ON_KANG;
//					}
//                    DISPLAY_MODULE_CS = 0;
//                    data_out_count = 0;
//                    clock_flag = 0;
//                    display_dtep = 3;
//               break;
//
//               case 3:
//                    if(!clock_flag) data_out_count++;
//                    if(data_out_count <= 8) Dsp_data_out();
//                    else
//                    {
//                         data_out_count = 0;
//                         DISPLAY_MODULE_CS = 1;
//                         display_dtep = 0;
//                         display_flag = 1;
//                    }
//               break;
//          }
//     }
//     else
//     {
//          switch (display_dtep)
//          {
//               // command 2
//               case 0:
//                    DISPLAY_MODULE_CS = 0;
//                    write_data = COMMAND_AUTO_ADDRESS;          
//                    data_out_count = 0;
//                    clock_flag = 0;
//                    display_dtep = 1;
//               break;
//
//               case 1:
//                    if(!clock_flag) data_out_count++;
//                    if(data_out_count <= 8) Dsp_data_out();
//                    else
//                    {
//                         data_out_count = 0;
//                         DISPLAY_MODULE_CS = 1;
//                         display_dtep = 2;
//                    }
//               break;
//
//               
//               // command 3
//               case 2:
//                    DISPLAY_MODULE_CS = 0;
//                    write_data = COMMAND_ADDRESS;          
//                    data_out_count = 0;
//                    clock_flag = 0;
//                    display_dtep = 3;
//               break;
//               
//               case 3:
//                    if(!clock_flag) data_out_count++;
//                    if(data_out_count <= 8) Dsp_data_out();
//                    else
//                    {
//                         data_out_count = 0;
//                         clock_flag = 0;
//                         display_dtep = 4;
//                         address_count = 0;
//                         write_data = led_buffer[address_count];
//                    }
//               break;
//               
//               case 4:
//
//                    if(!clock_flag) data_out_count++;
//                    if(data_out_count <= 8)
//                    {
//                         
//                         Dsp_data_out();
//                    }
//                    else
//                    {
//                         data_out_count = 0;
//                         
//                         address_count++;
//                         if(address_count > 9)
//                         {
//                              display_dtep = 0;
//                              DISPLAY_MODULE_CS = 1;
//                              address_count = 0;
//                              display_flag = 0;
//                              dsp_update_flag = 1;
//                         }
//                         else
//                         {
//                              write_data = led_buffer[address_count];
//                         }
//                    }
//               break;
//               
//          }
//     }
//     
//}
//
//
//void Dsp_data_out()
//{
//     unsigned char imsi_data;     
//     if(!clock_flag)
//     {
//          imsi_data = write_data & 0x01;
//          if(imsi_data)
//          {
//               DISPLAY_MODULE_DATA = 1;
//          }
//          else
//          {
//               DISPLAY_MODULE_DATA = 0;
//          }
//          clock_flag = 1;
//     }
//     else
//     {
//          if(clock_flag == 1)
//          {
//               DISPLAY_MODULE_CLOCK = 0;
//               clock_flag = 2;
//          }
//          else
//          {
//               if(clock_flag == 2)
//               {
//                    DISPLAY_MODULE_CLOCK = 1;
//                    clock_flag = 0;
//                    write_data >>= 1;
//               }
//          }
//     }
//}
//
//void MoodDisplay_transfer(void)
//{
//     if(DSP_INIT_EEPROM) return;
//     if(dsp_update_flag) return;
//     if(!mood_display_flag)
//     {
//          switch (mood_display_step)
//          {
//               // command 1
//               case 0:
//                    MOOD_MODULE_CS = 0;
//                    mood_display_step = 1;
//                    mood_write_data = COMMAND_GRID_SEG_DECO;          
//                    mood_data_out_count = 0;
//                    mood_clock_flag = 0;
//               break;
//
//               case 1:
//                    if(!mood_clock_flag) mood_data_out_count++;
//                    
//                    if(mood_data_out_count <= 8) MoodDisp_data_out();
//                    else
//                    {
//                         mood_data_out_count = 0;
//                         MOOD_MODULE_CS = 1;
//                         mood_display_step = 2;
//                    }
//               break;
//               
//               // command 2
//               case 2:
//					if(FOSC_OUT) mood_write_data = COMMAND_OFF;
//					else
//					{
//						if(JELJEON_SET && LIGHT_SENSING) mood_write_data = COMMAND_ON_YAK;
//						else mood_write_data = COMMAND_ON_KANG;
//					}
//                    MOOD_MODULE_CS = 0;
//                    mood_data_out_count = 0;
//                    mood_clock_flag = 0;
//                    mood_display_step = 3;
//               break;
//
//               case 3:
//                    if(!mood_clock_flag) mood_data_out_count++;
//                    if(mood_data_out_count <= 8) MoodDisp_data_out();
//                    else
//                    {
//                         mood_data_out_count = 0;
//                         MOOD_MODULE_CS = 1;
//                         mood_display_step = 0;
//                         mood_display_flag = 1;
//                    }
//               break;
//          }
//     }
//     else
//     {
//          switch (mood_display_step)
//          {
//               // command 2
//               case 0:
//                    MOOD_MODULE_CS = 0;
//                    mood_write_data = COMMAND_AUTO_ADDRESS;          
//                    mood_data_out_count = 0;
//                    mood_clock_flag = 0;
//                    mood_display_step = 1;
//               break;
//
//               case 1:
//                    if(!mood_clock_flag) mood_data_out_count++;
//                    if(mood_data_out_count <= 8) MoodDisp_data_out();
//                    else
//                    {
//                         mood_data_out_count = 0;
//                         MOOD_MODULE_CS = 1;
//                         mood_display_step = 2;
//                    }
//               break;
//
//               
//               // command 3
//               case 2:
//                    MOOD_MODULE_CS = 0;
//                    mood_write_data = COMMAND_ADDRESS;          
//                    mood_data_out_count = 0;
//                    mood_clock_flag = 0;
//                    mood_display_step = 3;
//               break;
//               
//               case 3:
//                    if(!mood_clock_flag) mood_data_out_count++;
//                    if(mood_data_out_count <= 8) MoodDisp_data_out();
//                    else
//                    {
//                         mood_data_out_count = 0;
//                         mood_clock_flag = 0;
//                         mood_display_step = 4;
//                         address_count = 0;
//                         mood_write_data = mood_led_buffer[address_count];
//                    }
//               break;
//               
//               case 4:
//
//                    if(!mood_clock_flag) mood_data_out_count++;
//                    if(mood_data_out_count <= 8)
//                    {
//                         
//                         MoodDisp_data_out();
//                    }
//                    else
//                    {
//                         mood_data_out_count = 0;
//                         
//                         address_count++;
//                         if(address_count > 9)
//                         {
//                              mood_display_step = 0;
//                              MOOD_MODULE_CS = 1;
//                              address_count = 0;
//                              mood_display_flag = 0;
//                              dsp_update_flag = 1;
//                         }
//                         else
//                         {
//                              mood_write_data = mood_led_buffer[address_count];
//                         }
//                    }
//               break;
//               
//          }
//     }
//     
//}
//
//
//void MoodDisp_data_out(void)
//{
//     unsigned char imsi_data;     
//     if(!mood_clock_flag)
//     {
//          imsi_data = mood_write_data & 0x01;
//          if(imsi_data)
//          {
//               MOOD_MODULE_DATA = 1;
//          }
//          else
//          {
//               MOOD_MODULE_DATA = 0;
//          }
//          mood_clock_flag = 1;
//     }
//     else
//     {
//          if(mood_clock_flag == 1)
//          {
//               MOOD_MODULE_CLOCK = 0;
//               mood_clock_flag = 2;
//          }
//          else
//          {
//               if(mood_clock_flag == 2)
//               {
//                    MOOD_MODULE_CLOCK = 1;
//                    mood_clock_flag = 0;
//                    mood_write_data >>= 1;
//               }
//          }
//     }
//}
//--------------------------------------------------------
