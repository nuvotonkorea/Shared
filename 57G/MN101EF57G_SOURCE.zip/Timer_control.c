/******************************************************************************
**
**  COPYRIGHT (C) 
**
**  THIS WORK CONTAINS TRADE SECRET AND PROPRIETARY INFORMATION WHICH IS
**  THE PROPERTY OF CUCKOO
**
**  PROJECT NAME:   
**
**  FILENAME:       .c
**
**  PURPOSE:        
**
**  FUNCTIONS:      
**
**  AUTHOR:
**
**  VERSION:        1.0
**
**  LAST MODIFIED: 
******************************************************************************/
/*****************************************************************************
Note:
2015-04-10 : 
*******************************************************************************/
#include	"typedef.h"
#include	"srMN101EF57G.h"
#include	"main.h"
#include    "global_func.h"
//#include    "GasSensor_FIS.h"
#include    "DustSensor.h"
#include    "wifi.h"
#include	<stdlib.h>
#define		ROOT

void CheckAirLevel(void);
void CheckAirLevelRoom(void);   //AJH 160813 ROOM CARE
void CheckAirLevelHumi(void);   //�ڵ�����
void CheckBattery(void);
void Power_stop_Mode(void);


void CheckDustSensorHumi(void); //�ڵ�����
void HumiCKsen1(void);
void HumiCKsen2(void);
void HumiCKsen3(void);
void HumiCKsen4(void);
void HumiCKsen5(void);
void HumiCKsen6(void);
void WaterLack5MinCheck(void);

void CheckDustSensor(void);
void DustCKsen1(void);
void DustCKsen2(void);
void DustCKsen3(void);
void DustCKsen4(void);
void DustCKsen5(void);
void DustCKsen6(void);
#ifndef TEST_CODE_SIZE_OPTIMIZE
void CheckDustSensorRoom(void);    //AJH 160813 ROOM CARE
void DustCKsenRoom1(void);
void DustCKsenRoom2(void);
void DustCKsenRoom3(void);
void DustCKsenRoom4(void);
void DustCKsenRoom5(void);
void DustCKsenRoom6(void);
#endif
void CheckDustLevelChangeFast(void);

void CheckIotSensorStat(void);
void EnergyEye_control(void);
void _cal_mood_in_out_data(void);  // �������� �Ǵ� ���ذ� (mood_in_data, mood_out_data) ���
void PACKING_MODE(void);			//CODELESS
void Sleep_mode_init_data(void);	//CODELESS



// �������� û���� �Ǵ� ����(30�� �� LOW Pulse �ð�: 1msec)
const unsigned int DustLevelGoodTbl[3]   = {INSENSITIVE_DUST_PULSE_TIME_GOOD,  // �а�
                                            DEFAULT_DUST_PULSE_TIME_GOOD,      // �⺻
                                            SENSITIVE_DUST_PULSE_TIME_GOOD};   // �ΰ� 
const unsigned int DustLevelGoodNormalTbl[3]   = {INSENSITIVE_DUST_PULSE_TIME_GOOD_NORMAL,  // �а�
                                            DEFAULT_DUST_PULSE_TIME_GOOD_NORMAL,      // �⺻
                                            SENSITIVE_DUST_PULSE_TIME_GOOD_NORMAL};   // �ΰ� 
const unsigned int DustLevelNormalTbl[3] = {INSENSITIVE_DUST_PULSE_TIME_NORMAL,
                                            DEFAULT_DUST_PULSE_TIME_NORMAL,
                                            SENSITIVE_DUST_PULSE_TIME_NORMAL};
const unsigned int DustLevelNormalPoorTbl[3] = {INSENSITIVE_DUST_PULSE_TIME_NORMAL_POOR,
                                            DEFAULT_DUST_PULSE_TIME_NORMAL_POOR,
                                            SENSITIVE_DUST_PULSE_TIME_NORMAL_POOR};
const unsigned int DustLevelPoorTbl[3]   = {INSENSITIVE_DUST_PULSE_TIME_POOR,
                                            DEFAULT_DUST_PULSE_TIME_POOR,
                                            SENSITIVE_DUST_PULSE_TIME_POOR};

const unsigned int Dust_PM2_5_GoodTbl[3]   = {INSENSITIVE_DUST_PM2_5_GOOD,  // �а�
                                            DEFAULT_DUST_PM2_5_GOOD,        // �⺻
                                            SENSITIVE_DUST_PM2_5_GOOD};     // �ΰ� 
const unsigned int Dust_PM2_5_GoodNormalTbl[3] = {INSENSITIVE_DUST_PM2_5_GOOD_NORMAL,  // �а�
                                                    DEFAULT_DUST_PM2_5_GOOD_NORMAL,        // �⺻
                                                    SENSITIVE_DUST_PM2_5_GOOD_NORMAL};     // �ΰ� 
const unsigned int Dust_PM2_5_NormalTbl[3] = {INSENSITIVE_DUST_PM2_5_NORMAL,
                                            DEFAULT_DUST_PM2_5_NORMAL,
                                            SENSITIVE_DUST_PM2_5_NORMAL};
const unsigned int Dust_PM2_5_NormalPoorTbl[3] = {INSENSITIVE_DUST_PM2_5_NORMAL_POOR,
                                            DEFAULT_DUST_PM2_5_NORMAL_POOR,
                                            SENSITIVE_DUST_PM2_5_NORMAL_POOR};
const unsigned int Dust_PM2_5_PoorTbl[3]   = {INSENSITIVE_DUST_PM2_5_POOR,
                                            DEFAULT_DUST_PM2_5_POOR,
                                            SENSITIVE_DUST_PM2_5_POOR};
                                            
const unsigned int CDS0_4_BAT1_LEVEL_SETTbl[12] = {244,244,227,217,225,214,229,220,228,218,232,224};
const unsigned int CDS0_4_BAT2_LEVEL_SETTbl[12] = {236,236,204,183,202,181,206,187,205,185,209,191};
const unsigned int CDS0_4_BAT3_LEVEL_SETTbl[12] = {228,228,182,151,180,150,184,156,183,155,188,161};
const unsigned int CDS0_4_BAT4_LEVEL_SETTbl[12] = {211,211,162,128,162,124,166,130,164,129,170,135};
// 2 LUX
const unsigned int CDS2_BAT1_LEVEL_SETTbl[12] = {235,235,217,207,215,203,219,209,218,208,222,214};
const unsigned int CDS2_BAT2_LEVEL_SETTbl[12] = {226,226,193,172,191,170,196,176,194,174,199,180};
const unsigned int CDS2_BAT3_LEVEL_SETTbl[12] = {218,218,171,140,169,139,173,145,172,144,177,150};
const unsigned int CDS2_BAT4_LEVEL_SETTbl[12] = {211,211,153,115,151,114,156,120,155,118,159,124};
// 4 LUX
const unsigned int CDS4_BAT1_LEVEL_SETTbl[12] = {223,223,204,194,202,161,203,196,205,195,210,141};
const unsigned int CDS4_BAT2_LEVEL_SETTbl[12] = {214,214,180,159,178,157,182,162,182,161,186,164};
const unsigned int CDS4_BAT3_LEVEL_SETTbl[12] = {205,205,158,127,156,125,160,131,159,130,164,146};
const unsigned int CDS4_BAT4_LEVEL_SETTbl[12] = {198,198,140,103,138,100,142,106,141,104,146,111};

const unsigned int MOTORSTEP_BAT_LEVEL_SETT0[5] = {646, 708, 733, 762, 806};
const unsigned int MOTORSTEP_BAT_LEVEL_SETT1[5] = {635, 699, 724, 754, 806};
const unsigned int MOTORSTEP_BAT_LEVEL_SETT2[5] = {632, 696, 722, 752, 806};
const unsigned int MOTORSTEP_BAT_LEVEL_SETT3[5] = {627, 692, 718, 749, 806};
const unsigned int MOTORSTEP_BAT_LEVEL_SETT4[5] = {615, 682, 709, 742, 806};
const unsigned int MOTORSTEP_BAT_LEVEL_SETT5[5] = {605, 670, 698, 732, 806};	// 603 : 9.65V

const unsigned int MOTORSTEP_BAT_LEVEL_SETTCH[5] = {650, 746, 757, 789, 811};

unsigned int *CDS_BAT_LEVEL_TEMP = 0;

unsigned int *MOTORSTEP_BAT_LEVEL_TEMP = 0;                                            

                                            

void Timer_control(void)
{
    //unsigned char cds_data;
    //unsigned char cds_time;
    //unsigned char cock_time;
    unsigned int timeout;

	//if(!help_delay_count) help_mode_in_step = 0;
    
    //CheckGasSensor();  // ���� ������ 100ms ���� ������   //�������� ������ ��
    if(MenuMode == MENU_AIRCLEAN_ROOM)
    {
#ifndef TEST_CODE_SIZE_OPTIMIZE
        CheckDustSensorRoom();  //AJH 160813 ROOM CARE
#else
        CheckDustSensor();
#endif
        CheckAirLevel();
    }
    else if(MenuMode == MENU_AIRCLEAN_HUMI)
    {
        if(HumiMaintain_Init_Timer == 0) CheckDustSensorHumi();
        CheckDustSensor();
        if(HUMI_WATER_LACK) CheckAirLevel();
        else    CheckAirLevelHumi();
    }
    else
    {
        CheckDustSensor();
        CheckAirLevel();
    }

    if(!TIMER_1SEC) return;
    TIMER_1SEC = 0;

    CheckIotSensorStat();
    // �������� ȯ��µ� ����
    WarmEnvAdjust(); 

     
    //if(SET_FLAG2 || MOOD_ONF_SET)
    if(fUSER_SVC_MODE_SET)
    {
        set_timer++;
        if(set_timer >= BUTTON_CANCEL_TIME) //10�ʰ� ���Է�
        {
            set_timer = 0;
            VoiceOutOneSvc(0xC8, 0, NONE_BEEP);   //"(���ȿ����) �ð��� �ʰ��Ǿ� ��� ������ ��ҵǾ����ϴ�."
            
            switch(gUserSvcModeADJ)
            {
                case USRLANG_ADJ:
                    gUsrLangSel = eeprom_addr_r[USR_LANG_ADDR];
                break;
                
                case USRVOLUME_ADJ:     // ���� ���� ����
                    if(eeprom_addr_r[USR_VOLUME_ADDR])
                        voice_adj_volume = VOICE_MUTE - eeprom_addr_r[USR_VOLUME_ADDR];
                    else
                        voice_adj_volume = VOICE_MUTE - DEFAULT_VOICE_VOLUME;   // BEEP ����
                break;
                
                case USRFILSWITCH_ADJ:  // ���ͱ�ü �˸����
                    gSeg_filter_switch = eeprom_addr_r[USR_FILTER_SWITCH_ADDR];
                break;
                
                
                case USRSENSIBILITY_ADJ:
                    gUsrSensibilityIdx = eeprom_addr_r[USR_SENSIBILITY_ADDR];
                break;
                
                case USRFNDDIMMING_ADJ:
                    gUsrLedDimming = eeprom_addr_r[USR_FNDDIMMING_ADDR];
                break;
                
                case USRCDSOPT_ADJ:
                    gCdsNightValueIdx = eeprom_addr_r[USR_CDS_OPT_ADDR];
                break;
                
                case USRTURBO_ADJ:
                    gTurboRunTimeIdx = eeprom_addr_r[USR_TURBO_ADDR];
                break;
                
                case ROOMCARE_ADJ:
                    gUsrRoomcareSel = eeprom_addr_r[USR_ROOMCARE_ADDR];
                break;
            }
           
            gUserSvcModeADJ = USRLANG_ADJ;
            LKEY = 1;
            SET_FLAG2 = 0;
            MOOD_ONF_SET = 0;
            
            fUSER_SVC_MODE_SET = CLR;
            dsp_addr = POWER_OFF_DISP;
        }
     }
     
    if(MONITORING_MODE)
    {
        if(FAST_MODE_ON) timeout = (10*MONITOR_MODE_TIME_OUT); // ���� ��� 18��
        else timeout = MONITOR_MODE_TIME_OUT; //180�� // 3��
        
        if(gMonitorModeTimeOutCnt++ >=  timeout)
        {
            MONITORING_MODE = CLR;
            monitoring_step = gMonitorModeTimeOutCnt = 0;
            
            // TO_DO_LIST: A TOOL �� ���� �ϰ� ��� ȿ���� ���� -.-;
            //VoiceOutOneSvc(0xD0, 0, NONE_BEEP);   //"(���ȿ����) 
        }
    }
    
    // �ʱ����� �ΰ���
     if(INIT)
     {
#ifndef TEST_DISPLAY_FULL_ON_JIG   // DISPLAY ǥ�ø� ������ �������� ������ ��� INIT CLEAR ����.
          timer_count++;
          if(timer_count >= 2)
          {
               timer_count = 0;
               INIT = 0;
          }
#endif          
     }     
     
    // ������� ����
     EnergyEye_control();
}

void EnergyEye_control(void)
{
#if defined(TEST_OPT_NO_ERROR) || defined(SKIP_ENERGY_EYE)
    // ���� �̹߻� ���ǿ����� ������ ���� ���Ծ���
    LIGHT_SENSING = 0;
    return;
#endif

    // �̻�� ����: CDS ������ �̻��
    if(eeprom_addr_r[USR_CDS_OPT_ADDR] == 0)        
    {   
        LIGHT_SENSING = 0;
        return;
    }

    // �̻�� ����: �ʱ��� �̸鼭 �������� �Ǵ� �ݺ����� ���������� �����Ǿ� ���� ������ ���� ���Ծ���
    if(POWER_ON == CLR && Timer_Data == 0)
    {   
        LIGHT_SENSING = 0;
        return;
    }
    

    // �������� �Ǵ� ���ذ� (mood_in_data, mood_out_data) ���
    _cal_mood_in_out_data();
    
    // �Ϲ� ����
    cds_on_time  = 60;
    cds_off_time = 60;
    
    // HELP Mode
	if(HELP_MODE_SET && help_option_step == CDS_CHECK)
	{
        cds_on_time = 1;
        cds_off_time = 1;
        
        mood_in_data = cds_help_data + 30;
        mood_out_data = cds_help_data + 10;
	}
	
	// 
	if(LIGHT_SENSING)
	{
	     if(AD_avg_cds <= mood_out_data || help_option_step == CDS_CHECK )
	     { 		
     		cds_off_time_count++;
     		if(cds_off_time_count >= cds_off_time)
     		{
     			cds_off_time_count = 0;
     			LIGHT_SENSING = 0;
     		}
		}
     	else 
		{
			cds_time_count = 0;		//bku 2014.04.24
			cds_off_time_count = 0;
		}
	}
	else
	{
		if(AD_avg_cds >= mood_in_data || (help_option_step == CDS_CHECK ))
		{
			cds_time_count++;
			if(cds_time_count >= cds_on_time)
			{
				cds_time_count = 0;
	     		LIGHT_SENSING = 1;
			}
		}
		else
		{
			cds_time_count = 0;
			cds_off_time_count = 0;	//bku 2014.04.24
		}
	}	
}

// �������� �Ǵ� ���ذ� (mood_in_data, mood_out_data) ���
/* //Y-tool ����
void _cal_mood_in_out_data(void)
{
    if(eeprom_addr_r[USR_CDS_OPT_ADDR] == 1)      // 0.4 lux : 1�ܰ�
    {
        if( (( (MenuMode == MENU_AIRCLEAN_BABY) || (MenuMode == MENU_AIRCLEAN_BED_TIME) ) && POWER_ON) )
        {
            //  ��ħ, ���� ���� 
            if(gUsrLedDimming) mood_in_data = 244;
            else mood_in_data = 240;  // DIMMING OFF : -4 ����
        }
        else if(Timer_Data && !POWER_ON)
        {
            // �������� ����
            if(gUsrLedDimming) mood_in_data = 240;
            else mood_in_data = 234;  // DIMMING OFF : -6 ����
        }
        else if(Timer_Data && POWER_ON)
        {   // ���� ���� ����
            if(eeprom_addr_w[USR_VOLUME_ADDR]) 
            {
                // ���� ���
                if(gUsrLedDimming) mood_in_data = 225;
                else mood_in_data = 217;
            }
            else
            {
                // ���� OFF
                if(gUsrLedDimming) mood_in_data = 234;
                else mood_in_data = 230;
            }
        }
        else
        {
            // �ڵ�, Ȳ��, ���� ���� �ͺ�
            if(eeprom_addr_w[USR_VOLUME_ADDR]) 
            {
                // ���� ���
                if(gUsrLedDimming) mood_in_data = 232;
                else mood_in_data = 226;
            }
            else
            {
                // ���� OFF
                mood_in_data = 240;
            }
        }

        mood_out_data = 225;    // ���� ����: 4 lux
    }
    else if(eeprom_addr_r[USR_CDS_OPT_ADDR] == 3)      // 4 lux
    {
        if( (( (MenuMode == MENU_AIRCLEAN_BABY) || (MenuMode == MENU_AIRCLEAN_BED_TIME) ) && POWER_ON) )
        {
            //  ��ħ, ���� ���� or ���� ���� ����
            if(gUsrLedDimming) mood_in_data = 210;
            else mood_in_data = 206;  // DIMMING OFF : -4 ����
        }
        else if(Timer_Data && !POWER_ON)
        {
            // �������� ����
            if(gUsrLedDimming) mood_in_data = 205;
            else mood_in_data = 199;  // DIMMING OFF : -6 ����
        }
        else if(Timer_Data && POWER_ON)
        {   // ���� ���� ����
            if(eeprom_addr_w[USR_VOLUME_ADDR]) 
            {
                // ���� ���
                if(gUsrLedDimming) mood_in_data = 190;//227;
                else mood_in_data = 182;//219;
            }
            else
            {
                // ���� OFF
                if(gUsrLedDimming) mood_in_data = 199;//236;
                else mood_in_data = 195;//232;
            }
        }
        else
        {
            // �ڵ�, Ȳ��, ���� ���� �ͺ�
            if(eeprom_addr_w[USR_VOLUME_ADDR]) 
            {
                // ���� ���
                if(gUsrLedDimming) mood_in_data = 197;//234;
                else mood_in_data = 191;//228;
            }
            else
            {
                // ���� OFF
                mood_in_data = 205;//242;
            }
        }

        mood_out_data = 183;    // ���� ����: 7 lux
    }
    else //if(eeprom_addr_r[USR_CDS_OPT_ADDR] == 2)      // 2 lux
    {
        if( (( (MenuMode == MENU_AIRCLEAN_BABY) || (MenuMode == MENU_AIRCLEAN_BED_TIME) ) && POWER_ON) )
        {
            //  ��ħ, ���� ���� or ���� ���� ����
            if(gUsrLedDimming) mood_in_data = 234;//244;
            else mood_in_data = 230;//240;  // DIMMING OFF : -4 ����
        }
        else if(Timer_Data && !POWER_ON)
        {
            // �������� ����
            if(gUsrLedDimming) mood_in_data = 230;
            else mood_in_data = 224;  // DIMMING OFF : -6 ����
        }
        else if(Timer_Data && POWER_ON)
        {   // ���� ���� ����
            if(eeprom_addr_w[USR_VOLUME_ADDR]) 
            {
                // ���� ���
                if(gUsrLedDimming) mood_in_data = 217;//227;
                else mood_in_data = 209;//219;
            }
            else
            {
                // ���� OFF
                if(gUsrLedDimming) mood_in_data = 226;//236;
                else mood_in_data = 222;//232;
            }
        }
        else
        {
            // �ڵ�, Ȳ��, ���� ���� �ͺ�
            if(eeprom_addr_w[USR_VOLUME_ADDR]) 
            {
                // ���� ���
                if(gUsrLedDimming) mood_in_data = 224;//234;
                else mood_in_data = 218;//228;
            }
            else
            {
                // ���� OFF
                mood_in_data = 232;//242;
            }
        }
        mood_out_data = 203;   // ���� ����: 5 lux
    }
}
*/
void _cal_mood_in_out_data(void)
{
    if(eeprom_addr_r[USR_CDS_OPT_ADDR] == 1)      // 1 lux : 1�ܰ�
    {
        mood_in_data = 235;     // ���� ���� : 1 LUX
        mood_out_data = 225;    // ���� ���� : 5 LUX
    }
    else if(eeprom_addr_r[USR_CDS_OPT_ADDR] == 3)      // 5 lux
    {
        mood_in_data = 210;     // ���� ���� : 5 LUX
        mood_out_data = 200;    // ���� ����: 9 lux
    }
    else //if(eeprom_addr_r[USR_CDS_OPT_ADDR] == 2)      // 3 lux
    {
        mood_in_data = 225;     // ���� ���� : 3 LUX
        mood_out_data = 215;   // ���� ����: 7 lux
    }
}

// HUMI û����
void CheckAirLevelHumi(void)
{
    if(Humi_Fan_Value == 1 && Dust_Fan_Value == 1)
    {
        gTotalAirLevel = 1; // û��: BLUE
    }
    else if((Humi_Fan_Value == 2 && Dust_Fan_Value <= 2) || (Humi_Fan_Value <= 2 && Dust_Fan_Value == 2))
    {
        gTotalAirLevel = 2; // ����: GREEN
    }
    else if((Humi_Fan_Value == 3 && Dust_Fan_Value <= 3) || (Humi_Fan_Value <= 3 && Dust_Fan_Value == 3))
    {
        gTotalAirLevel = 3; // ����: YELLOW
    }
    else if((Humi_Fan_Value == 4 && Dust_Fan_Value <= 4) || (Humi_Fan_Value <= 4 && Dust_Fan_Value == 4))
    {
        gTotalAirLevel = 4; // ����: YELLOW
    }
    else if((Humi_Fan_Value == 5 && Dust_Fan_Value <= 5) || (Humi_Fan_Value <= 5 && Dust_Fan_Value == 5))
    {
        gTotalAirLevel = 5; // ����: ����
    }
    else 
    {
        gTotalAirLevel = 6; // �ſ쳪��: RED
    }
}


// û���� (DUST)
void CheckAirLevel(void)
{
    if(Dust_Fan_Value == 1)
    {
        gTotalAirLevel = 1; // û��: BLUE
    }
    else if((Dust_Fan_Value == 2 ))
    {
        gTotalAirLevel = 2; // ����: û���
    }
    else if((Dust_Fan_Value == 3))
    {
        gTotalAirLevel = 3; // ����: GREEN
    }
    else if((Dust_Fan_Value == 4))
    {
        gTotalAirLevel = 4; // ����: YELLOW
    }
    else if((Dust_Fan_Value == 5))
    {
        gTotalAirLevel = 5; // ����: ����
    }
    else //if((Gas_Fan_Value == 4 && Dust_Fan_Value <= 4) || (Gas_Fan_Value <= 4 && Dust_Fan_Value == 4))
    {
        gTotalAirLevel = 6; // �ſ쳪��: RED
    }
}
// û���� (GAS+DUST)
/*
void CheckAirLevel(void)
{
    //if(fGAS_SENSOR_INIT_3MIN == CLR)
    //{
    //    gTotalAirLevel = 2; // ����: GREEN
    //    return;
    //}
    if(Gas_Fan_Value == 1 && Dust_Fan_Value == 1)
    {
        gTotalAirLevel = 1; // û��: BLUE
    }
    else if((Gas_Fan_Value == 2 && Dust_Fan_Value <= 2) || (Gas_Fan_Value <= 2 && Dust_Fan_Value == 2))
    {
        gTotalAirLevel = 2; // ����: GREEN
    }
    else if((Gas_Fan_Value == 3 && Dust_Fan_Value <= 3) || (Gas_Fan_Value <= 3 && Dust_Fan_Value == 3))
    {
        gTotalAirLevel = 3; // ����: YELLOW
    }
    else if((Gas_Fan_Value == 4 && Dust_Fan_Value <= 4) || (Gas_Fan_Value <= 4 && Dust_Fan_Value == 4))
    {
        gTotalAirLevel = 4; // ����: YELLOW
    }
    else if((Gas_Fan_Value == 5 && Dust_Fan_Value <= 5) || (Gas_Fan_Value <= 5 && Dust_Fan_Value == 5))
    {
        gTotalAirLevel = 5; // ����: ����
    }
    else //if((Gas_Fan_Value == 4 && Dust_Fan_Value <= 4) || (Gas_Fan_Value <= 4 && Dust_Fan_Value == 4))
    {
        gTotalAirLevel = 6; // �ſ쳪��: RED
    }

}
*/
//====================================================
//  FUNC. Flow  : (100ms routine)
//
//  Description : Check Gas_Sensor data [100ms] 
//==================================================
//void GasCKsensor(void)
//unsigned char gasLevel;
//void CheckGasSensor(void)
//{
//    unsigned char gasLevel;
//    
//    if(!TIMER_01SEC) return;
//    TIMER_01SEC = 0;
//    
//	if(GAS_SENSOR_ENABLE == 0)	return;
//	
//	gasLevel = ReadAirCleanLevel();
//	
//	if(gasLevel == LEVEL_H)
//	{
//		GasCKsen6(); 
//	}
//	else if(gasLevel == LEVEL_AFTER_M)
//	{
//		GasCKsen5(); 
//	}
//	else if(gasLevel == LEVEL_M)
//	{
//		GasCKsen4(); 
//	}
//	else if(gasLevel == LEVEL_L)
//	{
//		GasCKsen3(); 
//	}
//	else if(gasLevel == LEVEL_BEFORE_L)
//	{
//		GasCKsen2(); 
//	}
//	else
//	{
//		GasCKsen1(); 
//	}
//}

/*
#define  fGAS_SENSOR_INIT_3MIN     _set_flag3.bit.b0 //f_GasSensorOn
#define  fGAS_SENSOR_180MIN        _set_flag3.bit.b1*/
//void GasCKsen1(void)
//{
//	if(GasCmpCNT == 0)
//	{
//		//if(fGAS_SENSOR_180MIN == SET)
//		//{
//		//	Gas_Fan_Value = 2;			//2��
//		//	Gas_Fan_Value_S = Gas_Fan_Value;
//		//	//CleanMaintain_Timer = 180;		//�����ð� 180��
//		//	CleanMaintain_Timer = 60;		//�����ð� 60��
//		//	GasCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define �ʿ�
//		//	fGAS_SENSOR_180MIN = CLR;
//		//	return;
//		//}
//        
//        // GAS LEVEL ���ҽ� 3�� �� �� ������
//        if(Gas_Fan_Value_S > 1)
//        {
//            if(CleanMaintain_Timer == 0)
//			{
//			    // LEVEL ���� ������ ���� ����: ���� LEVEL �� 4�� -> 3�� -> 2��(90��) ���� �� 1�� ���� ������
//			    Gas_Fan_Value_S--;
//			    if(Gas_Fan_Value_S > 1)
//			    {
//			        CleanMaintain_Timer = 60;
//			    }
//			    Gas_Fan_Value = Gas_Fan_Value_S;
//			    // ORG
//				//Gas_Fan_Value = Gas_Fan_Value_S = 1;
//			}
//        }
//        else
//        {   // GAS LEVEL ������
//            Gas_Fan_Value = Gas_Fan_Value_S = 1;
//        }
//
//		GasCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define �ʿ�
//	    return;
//	}
//	if(GasCmpCNT) GasCmpCNT--;
//
//	return;
//}
//
//void GasCKsen2(void)
//{
//	if(GasCmpCNT == 0)
//	{
//        if(Gas_Fan_Value_S > 2)
//        {   // GAS LEVEL ���ҽ� 3�� �� �� ������
//            if(CleanMaintain_Timer == 0)
//			{
//			    // LEVEL ���� ������ ���� ����: ���� LEVEL �� 4�� -> 3�� -> 2��(90��) ���� �� 1�� ���� ������
//			    Gas_Fan_Value_S--;
//			    if(Gas_Fan_Value_S > 2)
//			    {
//			        CleanMaintain_Timer = 60;
//			    }
//			    Gas_Fan_Value = Gas_Fan_Value_S;
//			    
//			    // ORG
//				//Gas_Fan_Value = Gas_Fan_Value_S = 2;
//			}
//        }
//        else if(Gas_Fan_Value_S < 2)
//        {   // GAS LEVEL ������ ��� ����, 3�� Timer ������
//			Gas_Fan_Value = Gas_Fan_Value_S = 2;
//            //CleanMaintain_Timer = 180;
//            CleanMaintain_Timer = 60;		//�����ð� 60��
//        }
//        else
//        {   // GAS LEVEL ������
//            Gas_Fan_Value = Gas_Fan_Value_S = 2;
//        }
//
//        GasCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define �ʿ�
//	    return;
//	}
//	if(GasCmpCNT) GasCmpCNT--;
//	
//	return;
//}
//
//void GasCKsen3(void)
//{
//	if(GasCmpCNT == 0)
//	{
//	    if(Gas_Fan_Value_S > 3)
//        {   // GAS LEVEL ���ҽ� 3�� �� �� ������
//            if(CleanMaintain_Timer == 0)
//			{
//			    Gas_Fan_Value_S--;
//			    if(Gas_Fan_Value_S > 3)
//			    {
//			        CleanMaintain_Timer = 60;
//			    }
//			    Gas_Fan_Value = Gas_Fan_Value_S;
//			}
//        }
//        else if(Gas_Fan_Value_S < 3)
//        {   // GAS LEVEL ������ ��� ����, 3�� Timer ������
//			Gas_Fan_Value = Gas_Fan_Value_S = 3;
//            //CleanMaintain_Timer = 180;
//            CleanMaintain_Timer = 60;		//�����ð� 60��
//        }
//        else
//        {   // GAS LEVEL ������
//            Gas_Fan_Value = Gas_Fan_Value_S = 3;
//        }
//        
//		GasCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define �ʿ�
//        return;
//	}
//	if(GasCmpCNT) GasCmpCNT--;
//
//	return;
//}
//
//void GasCKsen4(void)
//{
//	if(GasCmpCNT == 0)
//	{
//	    if(Gas_Fan_Value_S > 4)
//        {   // GAS LEVEL ���ҽ� 3�� �� �� ������
//            if(CleanMaintain_Timer == 0)
//			{
//			    Gas_Fan_Value_S--;
//			    if(Gas_Fan_Value_S > 4)
//			    {
//			        CleanMaintain_Timer = 60;
//			    }
//				Gas_Fan_Value = Gas_Fan_Value_S;
//			}
//        }
//        else if(Gas_Fan_Value_S < 4)
//        {   // GAS LEVEL ������ ��� ����, 3�� Timer ������
//			Gas_Fan_Value = Gas_Fan_Value_S = 4;
//            //CleanMaintain_Timer = 180;
//            CleanMaintain_Timer = 60;		//�����ð� 60��
//        }
//        else
//        {   // GAS LEVEL ������
//            Gas_Fan_Value = Gas_Fan_Value_S = 4;
//        }
//        
//		GasCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define �ʿ�
//        return;
//	}
//	if(GasCmpCNT) GasCmpCNT--;
//
//	return;
//}
//void GasCKsen5(void)
//{
//    if(GasCmpCNT == 0)
//	{
//	    if(Gas_Fan_Value_S > 5)
//        {   // GAS LEVEL ���ҽ� 3�� �� �� ������
//            if(CleanMaintain_Timer == 0)
//			{
//				Gas_Fan_Value = Gas_Fan_Value_S = 5;
//			}
//        }
//        else if(Gas_Fan_Value_S < 5)
//        {   // GAS LEVEL ������ ��� ����, 3�� Timer ������
//			Gas_Fan_Value = Gas_Fan_Value_S = 5;
//            //CleanMaintain_Timer = 180;
//            CleanMaintain_Timer = 60;		//�����ð� 60��
//        }
//        else
//        {   // GAS LEVEL ������
//            Gas_Fan_Value = Gas_Fan_Value_S = 5;
//        }
//        
//		GasCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define �ʿ�
//        return;
//	}
//	if(GasCmpCNT) GasCmpCNT--;
//
//	return;
//}
//void GasCKsen6(void)
//{
//    if(GasCmpCNT == 0)
//	{
//        if(Gas_Fan_Value_S < 6)
//        {   // GAS LEVEL ������ ��� ����, 3�� Timer ������
//			Gas_Fan_Value = Gas_Fan_Value_S = 6;
//            //CleanMaintain_Timer = 180;
//            CleanMaintain_Timer = 60;		//�����ð� 60��
//        }
//        else
//        {   // GAS LEVEL ������
//            Gas_Fan_Value = Gas_Fan_Value_S = 6;
//        }
//        
//		GasCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define �ʿ�
//        return;
//	}
//	if(GasCmpCNT) GasCmpCNT--;
//
//	return;
//}


//====================================================
//  FUNC. Flow  : (100ms routine)
//
//  Description : Compare Dust Sensor data [100ms] 
//====================================================
void CheckDustSensorHumi(void)  //�ڵ�����
{
    if(Display_HU_val >= 55)
    {
        HumiCKsen1();
    }
	else if(Display_HU_val >= 50 && Display_HU_val < 55)
	{
        HumiCKsen2();
	}
	else if(Display_HU_val >= 45 && Display_HU_val < 50)
	{
        HumiCKsen3();
	}
	else if(Display_HU_val >= 40 && Display_HU_val < 45)
	{
        HumiCKsen4();
	}
	else if(Display_HU_val >= 35 && Display_HU_val < 40)
	{
        HumiCKsen5();
	}
	else if(Display_HU_val < 35)
	{
        HumiCKsen6();
	}
}

void HumiCKsen1(void)
{
	if(HumiCmpCNT == 0)
	{
        if(Humi_Fan_Value_S > 1)
        {
            if(HumiMaintain_Timer == 0)
			{
                Humi_Fan_Value_Old = Humi_Fan_Value_S;			    			    
			    Humi_Fan_Value_S--;
			    if(Humi_Fan_Value_S > 1)
			    {
			        HumiMaintain_Timer = 60;
			    }
			    Humi_Fan_Value = Humi_Fan_Value_S;
			}
        }
        else
        {
            Humi_Fan_Value = Humi_Fan_Value_S = 1;
            HumiMaintain_Timer = 60;
            
            Humi_Fan_Value_Old = Humi_Fan_Value_S;
        }
		HumiCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define ;
        return;
	}
	if(HumiCmpCNT) (HumiCmpCNT)--;
	return;
}
void HumiCKsen2(void)
{
    if(HumiCmpCNT == 0)
	{
        if(Humi_Fan_Value_S > 2)
        {
            if(HumiMaintain_Timer == 0)
			{
			    Humi_Fan_Value_S--;
			    if(Humi_Fan_Value_S > 2)
			    {
			        HumiMaintain_Timer = 60;
			    }
			    Humi_Fan_Value = Humi_Fan_Value_S;
			}
        }
        else if(Humi_Fan_Value_S < 2)
        {  
			Humi_Fan_Value = Humi_Fan_Value_S = 2;
            HumiMaintain_Timer = 60;		
        }
        else
        {   
            Humi_Fan_Value = Humi_Fan_Value_S = 2;
        }
        HumiCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define �ʿ�
	    return;
	}
	if(HumiCmpCNT) HumiCmpCNT--;
	return;
}
void HumiCKsen3(void)
{
	if(HumiCmpCNT == 0)
	{
	    if(Humi_Fan_Value_S > 3)
        {   
            if(HumiMaintain_Timer == 0)
			{
			    Humi_Fan_Value_S--;
			    if(Humi_Fan_Value_S > 3)
			    {
			        HumiMaintain_Timer = 60;
			    }
			    Humi_Fan_Value = Humi_Fan_Value_S;
			}
        }
        else if(Humi_Fan_Value_S < 3)
        {   
			Humi_Fan_Value = Humi_Fan_Value_S = 3;
            HumiMaintain_Timer = 60;		//�����ð� 60��
        }
        else
        {  
            Humi_Fan_Value = Humi_Fan_Value_S = 3;
        }
        
		HumiCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define �ʿ�
        return;
	}
	if(HumiCmpCNT) HumiCmpCNT--;
	return;
}
void HumiCKsen4(void)
{
	if(HumiCmpCNT == 0)
	{
	    if(Humi_Fan_Value_S > 4)
        {   
            if(HumiMaintain_Timer == 0)
			{
			    Humi_Fan_Value_S--;
			    if(Humi_Fan_Value_S > 4)
			    {
			        HumiMaintain_Timer = 60;
			    }
				Humi_Fan_Value = Humi_Fan_Value_S;
			}
        }
        else if(Gas_Fan_Value_S < 4)
        {  
			Humi_Fan_Value = Humi_Fan_Value_S = 4;
            HumiMaintain_Timer = 60;		//�����ð� 60��
        }
        else
        {  
            Humi_Fan_Value = Humi_Fan_Value_S = 4;
        }
		HumiCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define �ʿ�
        return;
	}
	if(HumiCmpCNT) HumiCmpCNT--;
	return;
}
void HumiCKsen5(void)
{
    if(HumiCmpCNT == 0)
	{
	    if(Humi_Fan_Value_S > 5)
        {   
            if(HumiMaintain_Timer == 0)
			{
				Humi_Fan_Value = Humi_Fan_Value_S = 5;
				HumiMaintain_Timer = 60;		//�����ð� 60��
			}
        }
        else if(Humi_Fan_Value_S < 5)
        {   
			Humi_Fan_Value = Humi_Fan_Value_S = 5;
            HumiMaintain_Timer = 60;		//�����ð� 60��
        }
        else
        {   
            Humi_Fan_Value = Humi_Fan_Value_S = 5;
            HumiMaintain_Timer = 60;
        }
		HumiCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define �ʿ�
        return;
	}
	if(HumiCmpCNT) HumiCmpCNT--;
	return;
}
void HumiCKsen6(void)
{
    if(HumiCmpCNT == 0)
	{
        if(Humi_Fan_Value_S < 6)
        {   
			Humi_Fan_Value = Humi_Fan_Value_S = 6;
            HumiMaintain_Timer = 60;		//�����ð� 60��
        }
        else
        {   // GAS LEVEL ������
            Humi_Fan_Value = Humi_Fan_Value_S = 6;
            HumiMaintain_Timer = 60;
        }
		HumiCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define �ʿ�
        return;
	}
	if(HumiCmpCNT) HumiCmpCNT--;
	return;
}

void CheckIotSensorStat(void)
{
    if(glOneM2MConnectOK)
    {
        //if(glOneM2MConnectOK) fChgIotDustFanLevel = 1;
        if(Dust_Fan_Value != Dust_Fan_ValueOldIot)
        {
            fChgIotDustFanLevel = 1;
            Dust_Fan_ValueOldIot = Dust_Fan_Value;
        }
        
        //if(glOneM2MConnectOK) fChgIotExtrDustLevel = 1;
        //if(glOneM2MConnectOK) fChgIotUltraDustLevel = 1;

        //if(glOneM2MConnectOK) fChgIotTotalAirLevel = 1;
        if(gTotalAirLevel != gTotalAirLevelOldIot)
        {
            gTotalAirLevelOldIot = gTotalAirLevel;
            fChgIotTotalAirLevel = 1;
        }

        //if(glOneM2MConnectOK) fChgIotGasFanLevel = 1;
        
        //if(glOneM2MConnectOK) fChgIotHumiData = 1;
        if(HU_Val != HU_ValOldIot)
        {
            HU_ValOldIot = HU_Val;
            fChgIotHumiData = 1;
        }
        
        //if(glOneM2MConnectOK) fChgIotFilterWork = 1;
        if(FilterWorkPercent != FilterWorkPercentOldIot)
        {
            FilterWorkPercentOldIot = FilterWorkPercent;
            fChgIotFilterWork = 1;
        }
        
    }
}

#ifndef TEST_CODE_SIZE_OPTIMIZE
///////////////////////////////////////////////////////////
void CheckDustSensorRoom(void)  //AJH   160813 ROOM CARE
{
	if(DUST_SENSOR_ENABLE == CLR)	return;

#ifdef TEST_GAS_INFO_SAVE
    return;     // Gas sensor ���� TEST �� ���� ���� ���� ���� ����
#endif
	
	if(gUsrSensibilityIdx>2) gUsrSensibilityIdx = 1; // ���� ����� default �Ҵ�
    
    // �������� ���� �Ǵ� ����(30�� �� LOW ��½ð�) �Ҵ�
	gDustLevelGood   = DustLevelGoodTbl[gUsrSensibilityIdx];
	gDustLevelGoodNormal = DustLevelGoodNormalTbl[gUsrSensibilityIdx];
	gDustLevelNormal = DustLevelNormalTbl[gUsrSensibilityIdx];
	gDustLevelNormalPoor = DustLevelNormalPoorTbl[gUsrSensibilityIdx];
	gDustLevelPoor   = DustLevelPoorTbl[gUsrSensibilityIdx];
	
	// �������� PM2.5 �Ǵ� ���� (PP)
    gDustPM2_5Good   = Dust_PM2_5_GoodTbl[gUsrSensibilityIdx];
    gDustPM2_5GoodNormal = Dust_PM2_5_GoodNormalTbl[gUsrSensibilityIdx];
    gDustPM2_5Normal = Dust_PM2_5_NormalTbl[gUsrSensibilityIdx];
    gDustPM2_5NormalPoor = Dust_PM2_5_NormalPoorTbl[gUsrSensibilityIdx];
    gDustPM2_5Poor   = Dust_PM2_5_PoorTbl[gUsrSensibilityIdx];
    
    CheckDustLevelChangeFast();

    // �������� ���� ������ �Ǵ�
    if((gPM10_UnitData >= DUST_PULSE_TIME_GOOD_UNIT) && (gPM10_UnitData < DUST_PULSE_TIME_GOOD_NORMAL_UNIT) && (Dust_Fan_Value_S < 2) && Dust_level_fast_up_flag)
	{   // ������ 5�� ��� �� �Ǵ�
	    DustCKsenRoom2();
	}
	else if((gPM10_UnitData >= DUST_PULSE_TIME_GOOD_NORMAL_UNIT) && (gPM10_UnitData < DUST_PULSE_TIME_NORMAL_UNIT) && (Dust_Fan_Value_S < 3) && Dust_level_fast_up_flag)
	{   // ������ 5�� ��� �� �Ǵ�
	    DustCKsenRoom3();
	}
	else if((gPM10_UnitData >= DUST_PULSE_TIME_NORMAL_UNIT) && (gPM10_UnitData < DUST_PULSE_TIME_NORMAL_POOR_UNIT) && (Dust_Fan_Value_S < 4) && Dust_level_fast_up_flag)
	{   // ������ 5�� ��� �� �Ǵ�
	    DustCKsenRoom4();
	}
	else if((gPM10_UnitData >= DUST_PULSE_TIME_NORMAL_POOR_UNIT) && (gPM10_UnitData < DUST_PULSE_TIME_POOR_UNIT) && (Dust_Fan_Value_S < 5) && Dust_level_fast_up_flag)
	{   // ������ 5�� ��� �� �Ǵ�
	    DustCKsenRoom5();
	}
	else if((gPM10_UnitData >= DUST_PULSE_TIME_POOR_UNIT) && (Dust_Fan_Value_S < 6) && Dust_level_fast_up_flag)
	{   // ������ 5�� ��� �� �Ǵ�
	    DustCKsenRoom6();
	}
	else if((gPM10_SumData < gDustLevelGood) && (gPM2_5_Concentration < gDustPM2_5Good))
	{   // P1: û�� & P2: û�� => û��
		DustCKsenRoom1();
	}
	else if((gPM10_SumData >= gDustLevelGood) && (gPM10_SumData < gDustLevelGoodNormal) 
	        && (gPM2_5_Concentration < gDustPM2_5GoodNormal)) 
	{   // P1: ���� & P2: (û�� or ����) => ����
	    DustCKsenRoom2();
	}
	else if((gPM2_5_Concentration >= gDustPM2_5Good) && (gPM2_5_Concentration < gDustPM2_5GoodNormal)
	        && (gPM10_SumData < gDustLevelGoodNormal) ) 
	{   // P1:(û�� or ����) & P2: ���� => ����
	    DustCKsenRoom2();
	}
	else if((gPM10_SumData >= gDustLevelGoodNormal) && (gPM10_SumData < gDustLevelNormal) 
	        && (gPM2_5_Concentration < gDustPM2_5Normal) ) 
	{   // P1: ���� & P2: (û�� or ����) => ����
	    DustCKsenRoom3();
	}
	else if((gPM2_5_Concentration >= gDustPM2_5GoodNormal) && (gPM2_5_Concentration < gDustPM2_5Normal)
	        && (gPM10_SumData < gDustLevelNormal) ) 
	{   // P1:(û�� or ����) & P2: ���� => ����
	    DustCKsenRoom3();
	}
	else if((gPM10_SumData >= gDustLevelNormal) && (gPM10_SumData < gDustLevelNormalPoor) 
	        && (gPM2_5_Concentration < gDustPM2_5NormalPoor) ) 
	{   // P1: ���� & P2: (û�� or ����) => ����
	    DustCKsenRoom4();
	}
	else if((gPM2_5_Concentration >= gDustPM2_5Normal) && (gPM2_5_Concentration < gDustPM2_5NormalPoor)
	        && (gPM10_SumData < gDustLevelNormalPoor) ) 
	{   // P1:(û�� or ����) & P2: ���� => ����
	    DustCKsenRoom4();
	}
	else if( (gPM10_SumData >= gDustLevelNormalPoor) && (gPM10_SumData < gDustLevelPoor)
	        && (gPM2_5_Concentration < gDustPM2_5Poor) )
	{
	    // P1: ���� & P2: (û�� or ���� or ����) => ����
	    DustCKsenRoom5();
	}
	else if( (gPM2_5_Concentration >= gDustPM2_5NormalPoor) && (gPM2_5_Concentration < gDustPM2_5Poor)
	        && (gPM10_SumData < gDustLevelPoor) )
	{
	    // P1: (û�� or ���� or ����) & P2:���� => ����
	    DustCKsenRoom5();
	}
	else if( (gPM10_SumData >= gDustLevelPoor) || (gPM2_5_Concentration >= gDustPM2_5Poor) )
	{   // P1:�ſ쳪�� or P2: �ſ쳪�� => �ſ쳪��
	    DustCKsenRoom6();
	}
}

void DustCKsenRoom1(void)
{
	if(DustCmpCNT == 0)
	{
        if(Dust_Fan_Value_S > 1)
        {
            if(CleanMaintain_RoomTimer == 0)
			{
                Dust_level_fast_up_cnt = DUST_LEVEL_FAST_UP_DELAY_COUNT;
                Dust_Fan_Value_Old = Dust_Fan_Value_S;
                Dust_level_fast_up_ChangeCnt = 0;
			    			    
			    // LEVEL ���� ������ ���� ����: ���� LEVEL �� 4�� -> 3�� -> 2��(90��) ���� �� 1�� ���� ������
			    Dust_Fan_Value_S--;
			    if(Dust_Fan_Value_S > 1)
			    {   
                    if(Dust_Fan_Value_S > 3)
                    {
                        CleanMaintain_RoomTimer = RoomTimer_Value2;
			            CleanMaintain_LowLevel_Cnt = RoomTimer_Value3;
                    }
                    else
                    {
			            CleanMaintain_RoomTimer = 60;
                    }
			    }
			    Dust_Fan_Value = Dust_Fan_Value_S;
			}
        }
        else
        {
            if(CleanMaintain_LowLevel_Cnt == 0)
            {
                Dust_Fan_Value_Old = Dust_Fan_Value_S;
                Dust_Fan_Value = Dust_Fan_Value_S = 4;
                CleanMaintain_RoomTimer = RoomTimer_Value2;
                CleanMaintain_LowLevel_Cnt = RoomTimer_Value3;
            }
            else
            {
                Dust_Fan_Value = Dust_Fan_Value_S = 1;
                CleanMaintain_RoomTimer = 60;
                Dust_Fan_Value_Old = Dust_Fan_Value_S;
            }
        }
		DustCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define ;
        return;
	}
	if(DustCmpCNT) (DustCmpCNT)--;
	return;
}

void DustCKsenRoom2(void)
{
	if(DustCmpCNT == 0)
	{
        if(Dust_Fan_Value_S > 2)
        {   // DUST LEVEL ���ҽ� 3�� �� �� ������
            if(CleanMaintain_RoomTimer == 0)
			{
			    Dust_level_fast_up_cnt = DUST_LEVEL_FAST_UP_DELAY_COUNT;
			    Dust_level_fast_up_ChangeCnt = 0;
			    Dust_Fan_Value_Old = Dust_Fan_Value_S;
			    
			    // LEVEL ���� ������ ���� ����: ���� LEVEL �� 4�� �� ��� 90�ʰ� 3�� ���� �� 2�� ���� ������
			    Dust_Fan_Value_S--;
			    if(Dust_Fan_Value_S > 2)
			    {
                    if(Dust_Fan_Value_S > 3)
                    {
                        CleanMaintain_RoomTimer = RoomTimer_Value2;
			            CleanMaintain_LowLevel_Cnt = RoomTimer_Value3;
                    }
                    else
                    {
			            CleanMaintain_RoomTimer = 60;
                    }
			    }
			    Dust_Fan_Value = Dust_Fan_Value_S;
			}
        }
        else if(Dust_Fan_Value_S < 2)
        {
            Dust_level_fast_up_cnt = 0;
            Dust_Fan_Value_Old = Dust_Fan_Value_S;
			Dust_Fan_Value = Dust_Fan_Value_S = 4;
            CleanMaintain_RoomTimer = RoomTimer_Value2;
            CleanMaintain_LowLevel_Cnt = RoomTimer_Value3;
        }
        else
        {
            if(CleanMaintain_LowLevel_Cnt == 0)
            {
                Dust_Fan_Value = Dust_Fan_Value_S = 4;
                CleanMaintain_RoomTimer = RoomTimer_Value2;
                CleanMaintain_LowLevel_Cnt = RoomTimer_Value3;
            }
            else
            {
                Dust_Fan_Value = Dust_Fan_Value_S = 2;
                CleanMaintain_RoomTimer = 60;
            }
        }
	    
		DustCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define ;
        return;
	}
	if(DustCmpCNT) (DustCmpCNT)--;
	return;
}

void DustCKsenRoom3(void)
{
	if(DustCmpCNT == 0)
	{
	    if(Dust_Fan_Value_S > 3)
        {   // Dust LEVEL ���ҽ� 3�� �� �� ������
            if(CleanMaintain_RoomTimer == 0)
			{
			    Dust_level_fast_up_cnt = DUST_LEVEL_FAST_UP_DELAY_COUNT;
			    Dust_Fan_Value_Old = Dust_Fan_Value_S;
			    Dust_level_fast_up_ChangeCnt = 0;
			    
			    Dust_Fan_Value_S--;
			    if(Dust_Fan_Value_S > 3)
			    {
			        CleanMaintain_RoomTimer = RoomTimer_Value2;
			        CleanMaintain_LowLevel_Cnt = RoomTimer_Value3;
			    }
			    else
			    {
			        CleanMaintain_RoomTimer = 60;
			    }
				Dust_Fan_Value = Dust_Fan_Value_S;
			}
        }
        else if(Dust_Fan_Value_S < 3)
        {  
            Dust_level_fast_up_cnt = 0;
            Dust_Fan_Value_Old = Dust_Fan_Value_S;
            
			Dust_Fan_Value = Dust_Fan_Value_S = 4;
            CleanMaintain_RoomTimer = RoomTimer_Value2;
            CleanMaintain_LowLevel_Cnt = RoomTimer_Value3;
        }
        else
        {   // Dust LEVEL ������
            if(CleanMaintain_LowLevel_Cnt == 0)
            {
                Dust_Fan_Value = Dust_Fan_Value_S = 4;
                CleanMaintain_RoomTimer = RoomTimer_Value2;
                CleanMaintain_LowLevel_Cnt = RoomTimer_Value3;
            }
            else
            {
                Dust_Fan_Value = Dust_Fan_Value_S = 3;
                CleanMaintain_RoomTimer = 60;
            }
        }
		DustCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define ;
        return;
	}
	if(DustCmpCNT) (DustCmpCNT)--;
	return;
}

void DustCKsenRoom4(void)
{
    if(DustCmpCNT == 0)
	{
	    if(Dust_Fan_Value_S > 4)
        {   // Dust LEVEL ���ҽ� 3�� �� �� ������
            if(CleanMaintain_RoomTimer == 0)
			{
			    Dust_level_fast_up_cnt = DUST_LEVEL_FAST_UP_DELAY_COUNT;
			    Dust_Fan_Value_Old = Dust_Fan_Value_S;
			    Dust_level_fast_up_ChangeCnt = 0;
			    
			    Dust_Fan_Value_S--;
			    if(Dust_Fan_Value_S > 4)
			    {
			        CleanMaintain_RoomTimer = RoomTimer_Value2;
			        CleanMaintain_LowLevel_Cnt = RoomTimer_Value3;
			    }
				Dust_Fan_Value = Dust_Fan_Value_S;
			}
        }
        else if(Dust_Fan_Value_S < 4)
        {   
            Dust_level_fast_up_cnt = 0;
            Dust_Fan_Value_Old = Dust_Fan_Value_S;
            
            // GAS LEVEL ������ ��� ����, 3�� Timer ������
			Dust_Fan_Value = Dust_Fan_Value_S = 4;
            CleanMaintain_RoomTimer = RoomTimer_Value2;
            CleanMaintain_LowLevel_Cnt = RoomTimer_Value3;
        }
        else
        {   // GAS LEVEL ������
            Dust_Fan_Value = Dust_Fan_Value_S = 4;
            CleanMaintain_RoomTimer = RoomTimer_Value2;
            CleanMaintain_LowLevel_Cnt = RoomTimer_Value3;
        }
		DustCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define �ʿ�
        return;
	}
	if(DustCmpCNT) DustCmpCNT--;
	return;
}
void DustCKsenRoom5(void)
{
    if(DustCmpCNT == 0)
	{
	    if(Dust_Fan_Value_S > 5)
        {   // Dust LEVEL ���ҽ� 3�� �� �� ������
            if(CleanMaintain_RoomTimer == 0)
			{
			    Dust_level_fast_up_cnt = DUST_LEVEL_FAST_UP_DELAY_COUNT;
			    Dust_Fan_Value_Old = Dust_Fan_Value_S;
			    Dust_level_fast_up_ChangeCnt = 0;
			    
				Dust_Fan_Value = Dust_Fan_Value_S = 5;
				CleanMaintain_LowLevel_Cnt = RoomTimer_Value3;
				CleanMaintain_RoomTimer = RoomTimer_Value2;  //AJH 161009 ROOM CARE ������ ����
			}
        }
        else if(Dust_Fan_Value_S < 5)
        {   // Dust LEVEL ������ ��� ����, 3�� Timer ������
            Dust_level_fast_up_cnt = 0;
            Dust_Fan_Value_Old = Dust_Fan_Value_S;
            
			Dust_Fan_Value = Dust_Fan_Value_S = 5;
            CleanMaintain_RoomTimer = RoomTimer_Value2; //
            CleanMaintain_LowLevel_Cnt = RoomTimer_Value3;
        }
        else //if(Dust_Fan_Value_S == 5)
        {   // Dust LEVEL ������
            Dust_Fan_Value = Dust_Fan_Value_S = 5;
            CleanMaintain_RoomTimer = RoomTimer_Value2;
            CleanMaintain_LowLevel_Cnt = RoomTimer_Value3;
        }
		DustCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define ;
        return;
	}
	if(DustCmpCNT) (DustCmpCNT)--;
	return;
}
void DustCKsenRoom6(void)
{
    if(DustCmpCNT == 0)
	{
        if(Dust_Fan_Value_S < 6)
        {   
            Dust_Fan_Value_Old = Dust_Fan_Value_S;
            
            // GAS LEVEL ������ ��� ����, 3�� Timer ������
			Dust_Fan_Value = Dust_Fan_Value_S = 6;
            CleanMaintain_RoomTimer = RoomTimer_Value;  //ROOM CARE ������ ����
            CleanMaintain_LowLevel_Cnt = RoomTimer_Value3;
        }
        else
        {   // GAS LEVEL ������
            Dust_Fan_Value = Dust_Fan_Value_S = 6;
            CleanMaintain_RoomTimer = RoomTimer_Value;  //ROOM CARE ������ ����
            CleanMaintain_LowLevel_Cnt = RoomTimer_Value3;
        }
        
        Dust_level_fast_up_cnt = DUST_LEVEL_FAST_UP_DELAY_COUNT;
        Dust_level_fast_up_ChangeCnt = 0;
		DustCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define �ʿ�
        return;
	}
	if(DustCmpCNT) DustCmpCNT--;
	return;
}
#endif

// �ڵ����
void CheckDustSensor(void)
{
	if(DUST_SENSOR_ENABLE == CLR)	return;

#ifdef TEST_GAS_INFO_SAVE
    return;     // Gas sensor ���� TEST �� ���� ���� ���� ���� ����
#endif
	
	if(gUsrSensibilityIdx>2) gUsrSensibilityIdx = 1; // ���� ����� default �Ҵ�
    
    // �������� ���� �Ǵ� ����(30�� �� LOW ��½ð�) �Ҵ�
	gDustLevelGood   = DustLevelGoodTbl[gUsrSensibilityIdx];
	gDustLevelGoodNormal = DustLevelGoodNormalTbl[gUsrSensibilityIdx];
	gDustLevelNormal = DustLevelNormalTbl[gUsrSensibilityIdx];
	gDustLevelNormalPoor = DustLevelNormalPoorTbl[gUsrSensibilityIdx];
	gDustLevelPoor   = DustLevelPoorTbl[gUsrSensibilityIdx];
	
	// �������� PM2.5 �Ǵ� ���� (PP)
    gDustPM2_5Good   = Dust_PM2_5_GoodTbl[gUsrSensibilityIdx];
    gDustPM2_5GoodNormal = Dust_PM2_5_GoodNormalTbl[gUsrSensibilityIdx];
    gDustPM2_5Normal = Dust_PM2_5_NormalTbl[gUsrSensibilityIdx];
    gDustPM2_5NormalPoor = Dust_PM2_5_NormalPoorTbl[gUsrSensibilityIdx];
    gDustPM2_5Poor   = Dust_PM2_5_PoorTbl[gUsrSensibilityIdx];
    
    CheckDustLevelChangeFast();

    // �������� ���� ������ �Ǵ�
    if((gPM10_UnitData >= DUST_PULSE_TIME_GOOD_UNIT) && (gPM10_UnitData < DUST_PULSE_TIME_GOOD_NORMAL_UNIT) && (Dust_Fan_Value_S < 2) && Dust_level_fast_up_flag)
	{   // ������ 5�� ��� �� �Ǵ�
	    DustCKsen2();
	}
	else if((gPM10_UnitData >= DUST_PULSE_TIME_GOOD_NORMAL_UNIT) && (gPM10_UnitData < DUST_PULSE_TIME_NORMAL_UNIT) && (Dust_Fan_Value_S < 3) && Dust_level_fast_up_flag)
	{   // ������ 5�� ��� �� �Ǵ�
	    DustCKsen3();
	}
	else if((gPM10_UnitData >= DUST_PULSE_TIME_NORMAL_UNIT) && (gPM10_UnitData < DUST_PULSE_TIME_NORMAL_POOR_UNIT) && (Dust_Fan_Value_S < 4) && Dust_level_fast_up_flag)
	{   // ������ 5�� ��� �� �Ǵ�
	    DustCKsen4();
	}
	else if((gPM10_UnitData >= DUST_PULSE_TIME_NORMAL_POOR_UNIT) && (gPM10_UnitData < DUST_PULSE_TIME_POOR_UNIT) && (Dust_Fan_Value_S < 5) && Dust_level_fast_up_flag)
	{   // ������ 5�� ��� �� �Ǵ�
	    DustCKsen5();
	}
	else if((gPM10_UnitData >= DUST_PULSE_TIME_POOR_UNIT) && (Dust_Fan_Value_S < 6) && Dust_level_fast_up_flag)
	{   // ������ 5�� ��� �� �Ǵ�
	    DustCKsen6();
	}
	else if((gPM10_SumData < gDustLevelGood) && (gPM2_5_Concentration < gDustPM2_5Good))
	{   // P1: û�� & P2: û�� => û��
		DustCKsen1();
	}
	else if((gPM10_SumData >= gDustLevelGood) && (gPM10_SumData < gDustLevelGoodNormal) 
	        && (gPM2_5_Concentration < gDustPM2_5GoodNormal)) 
	{   // P1: ���� & P2: (û�� or ����) => ����
	    DustCKsen2();
	}
	else if((gPM2_5_Concentration >= gDustPM2_5Good) && (gPM2_5_Concentration < gDustPM2_5GoodNormal)
	        && (gPM10_SumData < gDustLevelGoodNormal) ) 
	{   // P1:(û�� or ����) & P2: ���� => ����
	    DustCKsen2();
	}
	else if((gPM10_SumData >= gDustLevelGoodNormal) && (gPM10_SumData < gDustLevelNormal) 
	        && (gPM2_5_Concentration < gDustPM2_5Normal) ) 
	{   // P1: ���� & P2: (û�� or ����) => ����
	    DustCKsen3();
	}
	else if((gPM2_5_Concentration >= gDustPM2_5GoodNormal) && (gPM2_5_Concentration < gDustPM2_5Normal)
	        && (gPM10_SumData < gDustLevelNormal) ) 
	{   // P1:(û�� or ����) & P2: ���� => ����
	    DustCKsen3();
	}
	else if((gPM10_SumData >= gDustLevelNormal) && (gPM10_SumData < gDustLevelNormalPoor) 
	        && (gPM2_5_Concentration < gDustPM2_5NormalPoor) ) 
	{   // P1: ���� & P2: (û�� or ����) => ����
	    DustCKsen4();
	}
	else if((gPM2_5_Concentration >= gDustPM2_5Normal) && (gPM2_5_Concentration < gDustPM2_5NormalPoor)
	        && (gPM10_SumData < gDustLevelNormalPoor) ) 
	{   // P1:(û�� or ����) & P2: ���� => ����
	    DustCKsen4();
	}
	else if( (gPM10_SumData >= gDustLevelNormalPoor) && (gPM10_SumData < gDustLevelPoor)
	        && (gPM2_5_Concentration < gDustPM2_5Poor) )
	{
	    // P1: ���� & P2: (û�� or ���� or ����) => ����
	    DustCKsen5();
	}
	else if( (gPM2_5_Concentration >= gDustPM2_5NormalPoor) && (gPM2_5_Concentration < gDustPM2_5Poor)
	        && (gPM10_SumData < gDustLevelPoor) )
	{
	    // P1: (û�� or ���� or ����) & P2:���� => ����
	    DustCKsen5();
	}
	else if( (gPM10_SumData >= gDustLevelPoor) || (gPM2_5_Concentration >= gDustPM2_5Poor) )
	{   // P1:�ſ쳪�� or P2: �ſ쳪�� => �ſ쳪��
	    DustCKsen6();
	}
}

void DustCKsen1(void)
{
	if(DustCmpCNT == 0)
	{
		//if(fGAS_SENSOR_180MIN == SET)
		//{
		//	Dust_Fan_Value = 2;
		//	Dust_Fan_Value_S = Dust_Fan_Value;
		//	DustCleanMaintain_Timer = 60;//180;
		//	DustCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define ;
		//	fGAS_SENSOR_180MIN = CLR;
		//	return;
		//}

        // DUST LEVEL ���ҽ� 3�� �� �� ������
        if(Dust_Fan_Value_S > 1)
        {
            if(DustCleanMaintain_Timer == 0)
			{
                Dust_level_fast_up_cnt = DUST_LEVEL_FAST_UP_DELAY_COUNT;
                Dust_Fan_Value_Old = Dust_Fan_Value_S;
                Dust_level_fast_up_ChangeCnt = 0;
			    			    
			    // LEVEL ���� ������ ���� ����: ���� LEVEL �� 4�� -> 3�� -> 2��(90��) ���� �� 1�� ���� ������
			    Dust_Fan_Value_S--;
			    if(Dust_Fan_Value_S > 1)
			    {
			        DustCleanMaintain_Timer = 60;
			    }
			    Dust_Fan_Value = Dust_Fan_Value_S;
			    
				//Dust_Fan_Value = Dust_Fan_Value_S = 1;
			}
        }
        else
        {   // GAS LEVEL ������
            Dust_Fan_Value = Dust_Fan_Value_S = 1;
            DustCleanMaintain_Timer = 60;
            
            Dust_Fan_Value_Old = Dust_Fan_Value_S;
        }

		DustCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define ;
        return;
	}
	if(DustCmpCNT) (DustCmpCNT)--;
	return;
}

void DustCKsen2(void)
{
	if(DustCmpCNT == 0)
	{
        if(Dust_Fan_Value_S > 2)
        {   // DUST LEVEL ���ҽ� 3�� �� �� ������
            if(DustCleanMaintain_Timer == 0)
			{
			    Dust_level_fast_up_cnt = DUST_LEVEL_FAST_UP_DELAY_COUNT;
			    Dust_level_fast_up_ChangeCnt = 0;
			    Dust_Fan_Value_Old = Dust_Fan_Value_S;
			    
			    // LEVEL ���� ������ ���� ����: ���� LEVEL �� 4�� �� ��� 90�ʰ� 3�� ���� �� 2�� ���� ������
			    Dust_Fan_Value_S--;
			    if(Dust_Fan_Value_S > 2)
			    {
			        DustCleanMaintain_Timer = 60;
			    }
			    Dust_Fan_Value = Dust_Fan_Value_S;
				//Dust_Fan_Value = Dust_Fan_Value_S = 2;
			}
        }
        else if(Dust_Fan_Value_S < 2)
        {   // DUST LEVEL ������ ��� ����, 3�� Timer ������
            Dust_level_fast_up_cnt = 0;
            Dust_Fan_Value_Old = Dust_Fan_Value_S;
            
			Dust_Fan_Value = Dust_Fan_Value_S = 2;
            DustCleanMaintain_Timer = 60;//180;
        }
        else
        {   // DUST LEVEL ������
            Dust_Fan_Value = Dust_Fan_Value_S = 2;
            DustCleanMaintain_Timer = 60;
        }
	    
		DustCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define ;
        return;
	}
	if(DustCmpCNT) (DustCmpCNT)--;
	return;
}

void DustCKsen3(void)
{
	if(DustCmpCNT == 0)
	{
	    if(Dust_Fan_Value_S > 3)
        {   // Dust LEVEL ���ҽ� 3�� �� �� ������
            if(DustCleanMaintain_Timer == 0)
			{
			    Dust_level_fast_up_cnt = DUST_LEVEL_FAST_UP_DELAY_COUNT;
			    Dust_Fan_Value_Old = Dust_Fan_Value_S;
			    Dust_level_fast_up_ChangeCnt = 0;
			    
			    Dust_Fan_Value_S--;
			    if(Dust_Fan_Value_S > 3)
			    {
			        DustCleanMaintain_Timer = 60;
			    }
				Dust_Fan_Value = Dust_Fan_Value_S;
			}
        }
        else if(Dust_Fan_Value_S < 3)
        {   // Dust LEVEL ������ ��� ����, 3�� Timer ������
            Dust_level_fast_up_cnt = 0;
            Dust_Fan_Value_Old = Dust_Fan_Value_S;
            
			Dust_Fan_Value = Dust_Fan_Value_S = 3;
            DustCleanMaintain_Timer = 60;//180;
        }
        else
        {   // Dust LEVEL ������
            Dust_Fan_Value = Dust_Fan_Value_S = 3;
            DustCleanMaintain_Timer = 60;
        }
		DustCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define ;
        return;
	}
	if(DustCmpCNT) (DustCmpCNT)--;
	return;
}

void DustCKsen4(void)
{
    if(DustCmpCNT == 0)
	{
	    if(Dust_Fan_Value_S > 4)
        {   // Dust LEVEL ���ҽ� 3�� �� �� ������
            if(DustCleanMaintain_Timer == 0)
			{
			    Dust_level_fast_up_cnt = DUST_LEVEL_FAST_UP_DELAY_COUNT;
			    Dust_Fan_Value_Old = Dust_Fan_Value_S;
			    Dust_level_fast_up_ChangeCnt = 0;
			    
			    Dust_Fan_Value_S--;
			    if(Dust_Fan_Value_S > 4)
			    {
			        DustCleanMaintain_Timer = 60;
			    }
				Dust_Fan_Value = Dust_Fan_Value_S;
			}
        }
        else if(Dust_Fan_Value_S < 4)
        {   
            Dust_level_fast_up_cnt = 0;
            Dust_Fan_Value_Old = Dust_Fan_Value_S;
            
            // GAS LEVEL ������ ��� ����, 3�� Timer ������
			Dust_Fan_Value = Dust_Fan_Value_S = 4;
            DustCleanMaintain_Timer = 60;//180;
        }
        else
        {   // GAS LEVEL ������
            Dust_Fan_Value = Dust_Fan_Value_S = 4;
            DustCleanMaintain_Timer = 60;
        }
        
//        Dust_level_fast_up_cnt = DUST_LEVEL_FAST_UP_DELAY_COUNT;
 //       Dust_level_fast_up_ChangeCnt = 0;
		DustCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define �ʿ�
        return;
	}
	if(DustCmpCNT) DustCmpCNT--;

	return;
}
void DustCKsen5(void)
{
    if(DustCmpCNT == 0)
	{
	    if(Dust_Fan_Value_S > 5)
        {   // Dust LEVEL ���ҽ� 3�� �� �� ������
            if(DustCleanMaintain_Timer == 0)
			{
			    Dust_level_fast_up_cnt = DUST_LEVEL_FAST_UP_DELAY_COUNT;
			    Dust_Fan_Value_Old = Dust_Fan_Value_S;
			    Dust_level_fast_up_ChangeCnt = 0;
			    
				Dust_Fan_Value = Dust_Fan_Value_S = 5;
			}
        }
        else if(Dust_Fan_Value_S < 5)
        {   // Dust LEVEL ������ ��� ����, 3�� Timer ������
            Dust_level_fast_up_cnt = 0;
            Dust_Fan_Value_Old = Dust_Fan_Value_S;
            
			Dust_Fan_Value = Dust_Fan_Value_S = 5;
            DustCleanMaintain_Timer = 60;//180;
        }
        else //if(Dust_Fan_Value_S == 5)
        {   // Dust LEVEL ������
            Dust_Fan_Value = Dust_Fan_Value_S = 5;
            DustCleanMaintain_Timer = 60;
        }
		DustCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define ;
        return;
	}
	if(DustCmpCNT) (DustCmpCNT)--;
	return;
}
void DustCKsen6(void)
{
    if(DustCmpCNT == 0)
	{
        if(Dust_Fan_Value_S < 6)
        {   
            Dust_Fan_Value_Old = Dust_Fan_Value_S;
            
            // GAS LEVEL ������ ��� ����, 3�� Timer ������
			Dust_Fan_Value = Dust_Fan_Value_S = 6;
            DustCleanMaintain_Timer = 60;//180;
        }
        else
        {   // GAS LEVEL ������
            Dust_Fan_Value = Dust_Fan_Value_S = 6;
            DustCleanMaintain_Timer = 60;
        }
        
        Dust_level_fast_up_cnt = DUST_LEVEL_FAST_UP_DELAY_COUNT;
        Dust_level_fast_up_ChangeCnt = 0;
		DustCmpCNT = 18;		            //üũŸ�� 1.8�� TO_DO_LIST: Define �ʿ�
        return;
	}
	if(DustCmpCNT) DustCmpCNT--;
	return;
}

//====================================================
//  FUNC. Flow  : (1min routine)               
//                                                    
//  Description : Process Time Check Routine [1Min]   
//====================================================
// 3�ð� ���� û���� ��� �����ϸ� ������ 2������ ������
//void Gas3HrCheck(void)                                
//{
//    if(MenuMode != MENU_AIRCLEAN_AUTO)  return;
//	
//	// Count 3�ð� û���� ���� �ð� Ȯ��
//	if(Gas_Fan_Value <= 1 && Dust_Fan_Value <= 1)
//	{
//		Gas180Min_Cnt++;
//		if(Gas180Min_Cnt >= 177)
//		{
//			Gas180Min_Cnt = 0;
//			fGAS_SENSOR_180MIN = SET;
//		}
//	}
//	
//	// ������ ����� Count �ʱ�ȭ
//	if(Gas_Fan_Value > 1 || Dust_Fan_Value > 1)
//	{
//		Gas180Min_Cnt = 0;
//		fGAS_SENSOR_180MIN = CLR;
//	}
//}
void WaterLack5MinCheck(void)
{
    if(MenuMode != MENU_AIRCLEAN_HUMI)  return;
    
    if(WATER_LACK)
	{
	    if(HUMI_WATER_LACK) return;
		Humi10Sec_Cnt++;
		if(Humi10Sec_Cnt >= 10)
		{
			Humi10Sec_Cnt = 0;
			HUMI_WATER_LACK = SET;
            if(Humi_Fan_Value_S > Dust_Fan_Value_S)
            {
                Dust_Fan_Value = Dust_Fan_Value_S = Humi_Fan_Value_S;
            } 
			//MenuMode = MENU_AIRCLEAN_AUTO;
			//_mode_Auto_Set();
		}
	}
	else
	{
	    Humi10Sec_Cnt = 0;
	    HUMI_WATER_LACK = CLR;
	}
}

void CheckDustLevelChangeFast(void)
{
    if(Dust_level_fast_up_cnt == 0) 
    {
        if(Dust_Fan_Value_Old != Dust_Fan_Value)
            Dust_Fan_Value_Old = Dust_Fan_Value;
        
        if(Dust_Fan_Value >= Dust_Fan_Value_Old || Dust_Fan_Value <= 2 )
            Dust_level_fast_up_flag = 1;    // 2�а� 30�� ������� �Ǻ��� û������ ���� ���� ���� �Ǵ� ������ ��� 5�� ��� ������ �Ǵ���
        else 
            Dust_level_fast_up_flag = 0;    // 30�� ��� ������ �Ǵ���
    }
    else
    {
        Dust_level_fast_up_flag = 0;    // 30�� ��� ������ �Ǵ���
    }
    
    // 4�� ���Ͽ��� 30�� ������� ���� �� 
    if(Dust_level_fast_up_flag == 0 && Dust_Fan_Value < 6 )
    {
        if(gPM10_UnitData >= DUST_PULSE_TIME_5SEC_MIN) //75
        {
            // 2ȸ ���� 2�� �̻� ������ �Է½� 5�� ��� ������ ���� �ǵ��� ��
            if(gPM10_UnitDataOld != gPM10_UnitData)
            {
                if(Dust_level_fast_up_ChangeCnt++ >= 2)
                {
                    Dust_level_fast_up_cnt  = 0;
                    Dust_level_fast_up_flag = 1; 
                }
                gPM10_UnitDataOld = gPM10_UnitData;
            }

            if(gPM10_UnitData > DUST_PULSE_TIME_5SEC_MAX)   //200
            {
                Dust_level_fast_up_cnt  = 0;
                Dust_level_fast_up_flag = 1; 
            }
        }
    }
}

void CheckBattery(void)
{
	//AD_Battery_temp = (AD_avg_bat*15) >> 4;  //[Q6] AD_Battery_temp/ 2^6(62.23) = Battery Voltage
	//CE_40210 = ~CE_40210;

	AD_count_Battery_temp++;
	AD_sum_Battery_temp += AD_avg_bat;

    if(AD_count_Battery_temp >= 10)	// 1sec
    {   
        AD_Battery_temp = AD_sum_Battery_temp/AD_count_Battery_temp;
		AD_count_Battery_temp = 0;
        AD_sum_Battery_temp = 0;
    }  
	//	AD_Battery_temp = AD_avg_bat;
	AD_avg_bat_100 = AD_Battery_temp/100;
	AD_avg_bat_10 = AD_Battery_temp%100;
	
	//test
	if(Battery_STAT1)
	{
	    Bat_State1 = 1;
	}
	else
	{
	    Bat_State1 = 0;
	}
    
    if(Battery_STAT2)
	{
	    Bat_State2 = 1;
	}
	else
	{
	    Bat_State2 = 0;
	}
	//TEST
	//�ƴ��� ���� ����
	if(Battery_STAT1 && Battery_STAT2)  //
	{
	    Bat_Discharge_Mode = 1;
	}
	else
	{
	    Bat_Discharge_Mode = 0;
	}
    //�ƴ��� ���Ű���
    
	if((Battery_STAT1 == SET)&&(Battery_STAT2 != SET))
	{
		Battery_State = BAT_STATE_COMPLETE;	//2			FULL Charging Complete
	}
	else if((Battery_STAT1 != SET)&&(Battery_STAT2 == SET))
	{
		Battery_State = BAT_STATE_CHARGING;	//1			Under Charging
		ucBATTERY_LOW_voice = 0;
	}
	else
	{
		Battery_State = BAT_STATE_SUSPEND;  //0 or 3	Suspend

		switch (gLoadMotorStep)
		{
			case 0:
				MOTORSTEP_BAT_LEVEL_TEMP = MOTORSTEP_BAT_LEVEL_SETT0 ;
			break;
				
			case 1:
				MOTORSTEP_BAT_LEVEL_TEMP = MOTORSTEP_BAT_LEVEL_SETT1 ;				
			break;
				
			case 2:
				MOTORSTEP_BAT_LEVEL_TEMP = MOTORSTEP_BAT_LEVEL_SETT2 ;				
			break;
				
			case 3:
				MOTORSTEP_BAT_LEVEL_TEMP = MOTORSTEP_BAT_LEVEL_SETT3 ;	
			break;

			case 4:
				MOTORSTEP_BAT_LEVEL_TEMP = MOTORSTEP_BAT_LEVEL_SETT4 ;	
			break;

			case 5:
				MOTORSTEP_BAT_LEVEL_TEMP = MOTORSTEP_BAT_LEVEL_SETT5 ;	
			break;

			default :// 0
				//MotorStep_BAT_LEVEL_TEMP = MOTORSTEP_BAT_LEVEL_SETT5 ;		
			break;	
		}
	}

	if((Battery_State == BAT_STATE_SUSPEND)&&(AD_count_Battery_temp == 0))	// 2016_0926_adh_test
	{	
		AD_Battery_temp_MAX1 = AD_Battery_temp;
		AD_Battery_temp_MAX2 = AD_Battery_temp_MAX1;
		AD_Battery_temp_MAX3 = AD_Battery_temp_MAX2;
		
		if( AD_Battery_temp_MAX1 >= AD_Battery_temp_MAX2)
			AD_Battery_temp_MAX = AD_Battery_temp_MAX1;
		else
			AD_Battery_temp_MAX = AD_Battery_temp_MAX2;

		if( AD_Battery_temp_MAX <= AD_Battery_temp_MAX3)
			AD_Battery_temp_MAX = AD_Battery_temp_MAX3;
		
	}
	
	if(dsp_addr == HELP_MODE_DSP) return;		// 2016_0831 adh
	//return; //test

	if(Battery_State == BAT_STATE_CHARGING)
	{
		MOTORSTEP_BAT_LEVEL_TEMP = MOTORSTEP_BAT_LEVEL_SETTCH ;
		/*
		if(AD_Battery_temp > BAT_CHANGING_LEVEL_F )	//[Q6] 12.0V x 2^6 Full Changing voltage
		{
			BATTERY_LED4 = SET;		// 87.3%   BATTERY_LED4(11.0V �̻�)
			BATTERY_LED3 = SET;		// 82.54%  BATTERY_LED3(10.4V �̻�)
			BATTERY_LED2 = SET;		// 73.8%   BATTERY_LED2( 9.3V �̻�)
			BATTERY_LED1 = SET;		// 69.0%   BATTERY_LED1( 8.7V �̻�)	
		}
		else 
		*/
		//gSelMotorStep => 0, 1, 2, 3, 4, 5 �ܿ� ���� ���͸� ���� ���� 
		
		//*(CDS_BAT_LEVEL_TEMP + 0)
		
		if(AD_Battery_temp > *(MOTORSTEP_BAT_LEVEL_TEMP + 3) )	//797 12.24V 90%�̻� ~ 100%�̸� (12.24V ~ 12.46V) 2.94V(100)
		{
			/*
			if((Battery_State == BAT_STATE_COMPLETE)||(AD_Battery_temp >  *(MOTORSTEP_BAT_LEVEL_TEMP + 4) ))
			{
				BATTERY_LED4 = SET;		// 87.3%   BATTERY_LED4(11.0V �̻�)
				BATTERY_LED3 = SET;		// 82.54%  BATTERY_LED3(10.4V �̻�)
				BATTERY_LED2 = SET;		// 73.8%   BATTERY_LED2( 9.3V �̻�)
				BATTERY_LED1 = SET;		// 69.0%   BATTERY_LED1( 8.7V �̻�)

					
				if((ucBATTERY_COMPLETE_voice == 0)&&(MenuMode != MENU_AIRCLEAN_BABY)
				&&(MenuMode != MENU_AIRCLEAN_BED_TIME)&&(!LIGHT_SENSING)&&(gPowerOnSec == 0)&&(POWER_ON == ON))
				{	// 2016_0908_adh
					ucBATTERY_COMPLETE_voice = 1;
					//VoiceOutOneSvc(0xF5,0, NONE_BEEP); //���͸� ������ �Ϸ�Ǿ����ϴ�..
					VoiceOutOneSvc(0x8A,0, NONE_BEEP); //���� ������ ü���� �ּ���.
				}	

			}else*/
			{
				if(TOGGL_500)	BATTERY_LED4 = SET;		// 87.3%   BATTERY_LED4(11.0V �̻�)
				BATTERY_LED3 = SET;		// 82.54%  BATTERY_LED3(10.4V �̻�)
				BATTERY_LED2 = SET;		// 73.8%   BATTERY_LED2( 9.3V �̻�)
				BATTERY_LED1 = SET;		// 69.0%   BATTERY_LED1( 8.7V �̻�)
			}
			ucBATTERY_CDS_state = BAT_CDS_LEVEL4;
					
		}else if(AD_Battery_temp >  *(MOTORSTEP_BAT_LEVEL_TEMP + 2) )//768 11.62V 70%�̻� ~ 90%�̸� (11.62V ~ 12.24V)
		{
			BATTERY_LED4 = CLR;	
			if(TOGGL_500)	BATTERY_LED3 = SET;		
			BATTERY_LED2 = SET;		
			BATTERY_LED1 = SET;	
			ucBATTERY_CDS_state = BAT_CDS_LEVEL3;			
		}else if(AD_Battery_temp >  *(MOTORSTEP_BAT_LEVEL_TEMP + 1) )//720 10.73V 40%�̻� ~ 70%�̸� (10.73V ~ 11.62V)
		{
			BATTERY_LED4 = CLR;		
			BATTERY_LED3 = CLR;		
			if(TOGGL_500)	BATTERY_LED2 = SET;		
			BATTERY_LED1 = SET;		
			ucBATTERY_CDS_state = BAT_CDS_LEVEL2;			
		}else// if(AD_Battery_temp >  *(MOTORSTEP_BAT_LEVEL_TEMP + 0) )//656 9.67V 5%�̻� ~ 40%�̸� (9.67V ~ 10.73V)
		{
			BATTERY_LED4 = CLR;		
			BATTERY_LED3 = CLR;		
			BATTERY_LED2 = CLR;		
			if(TOGGL_500)	BATTERY_LED1 = SET;	
			ucBATTERY_CDS_state = BAT_CDS_LEVEL1;				
		}//else//(AD_Battery_temp > BAT_CHANGING_LEVEL_OFF)
		//{
		//	BATTERY_LED4 = CLR;		
		//	BATTERY_LED3 = CLR;		
		//	BATTERY_LED2 = CLR;		
		//	BATTERY_LED1 = CLR;	
		//	ucBATTERY_CDS_state = BAT_CDS_LEVEL0;	
		//}		

		if(ucBATTERY_LOW_Lock == 1)			// 2016_0909_adh
		{
			ucBATTERY_LOW_Lock = 0;

			if(POWER_ON == OFF)
				Power_On_Exe();
		}

	}
	else if(Battery_State == BAT_STATE_COMPLETE)
	{
			BATTERY_LED4 = SET;		// 87.3%   BATTERY_LED4(11.0V �̻�)
			BATTERY_LED3 = SET;		// 82.54%  BATTERY_LED3(10.4V �̻�)
			BATTERY_LED2 = SET;		// 73.8%   BATTERY_LED2( 9.3V �̻�)
			BATTERY_LED1 = SET;		// 69.0%   BATTERY_LED1( 8.7V �̻�)

			if((ucBATTERY_COMPLETE_voice == 0)&&(MenuMode != MENU_AIRCLEAN_BABY)
			&&(MenuMode != MENU_AIRCLEAN_BED_TIME)&&(!LIGHT_SENSING)&&(gPowerOnSec == 0)&&(POWER_ON == ON))
			{	// 2016_0908_adh
				ucBATTERY_COMPLETE_voice = 1;
				//VoiceOutOneSvc(0xF5,0, NONE_BEEP); //���͸� ������ �Ϸ�Ǿ����ϴ�..
				//VoiceOutOneSvc(0x8A,0, NONE_BEEP); //���� ������ ü���� �ּ���.
			}
	}
	else
	{
		if(AD_Battery_temp > *(MOTORSTEP_BAT_LEVEL_TEMP + 3) )	//762 11.51V 70%�̻� ~ 100%���� (11.51V ~ 12.46V)   3.1V(100)
		{
			BATTERY_LED4 = SET;		// 
			BATTERY_LED3 = SET;		// 
			BATTERY_LED2 = SET;		// 
			BATTERY_LED1 = SET;		// 	
			ucBATTERY_CDS_state = BAT_CDS_LEVEL4;	
		}
		else if(AD_Battery_temp > *(MOTORSTEP_BAT_LEVEL_TEMP + 2) )//733  10.95V 50%�̻� ~ 70%�̸� (10.95V ~ 11.51V)
		{
			BATTERY_LED4 = CLR;	
			BATTERY_LED3 = SET;		
			BATTERY_LED2 = SET;		
			BATTERY_LED1 = SET;	
			ucBATTERY_CDS_state = BAT_CDS_LEVEL3;			
		}
		else if(AD_Battery_temp > *(MOTORSTEP_BAT_LEVEL_TEMP + 1) )//708 10.51V 35%�̻� ~ 50%�̸� (10.51V ~ 10.95V)
		{
			BATTERY_LED4 = CLR;		
			BATTERY_LED3 = CLR;		
			BATTERY_LED2 = SET;		
			BATTERY_LED1 = SET;
			ucBATTERY_CDS_state = BAT_CDS_LEVEL2;					
		}
		else if(AD_Battery_temp > *(MOTORSTEP_BAT_LEVEL_TEMP + 0) )//646 9.5V 5%�̻� ~ 35%�̸� (9.5V ~ 10.51V)
		{
			BATTERY_LED4 = CLR;		
			BATTERY_LED3 = CLR;		
			BATTERY_LED2 = CLR;		
			BATTERY_LED1 = SET;	
			ucBATTERY_CDS_state = BAT_CDS_LEVEL1;			
		}
		else	// (AD_Battery_temp <= *(MOTORSTEP_BAT_LEVEL_TEMP + 0))
		{

			if((ucBATTERY_LOW_voice == 0)&&(MenuMode != MENU_AIRCLEAN_BABY)
			&&(MenuMode != MENU_AIRCLEAN_BED_TIME)&&(!LIGHT_SENSING)&&(gPowerOnSec == 0)&&(POWER_ON == ON))
			{	// 2016_0908_adh
				ucBATTERY_LOW_voice = 1;
				VoiceOutOneSvc(0xF4,0, NONE_BEEP); //���͸��� ������ �ּ���.
				//VoiceOutOneSvc(0x8A,0, NONE_BEEP); //���� ������ ü���� �ּ���.
			}
						
			BATTERY_LED4 = CLR;		
			BATTERY_LED3 = CLR;		
			BATTERY_LED2 = CLR;		
			BATTERY_LED1 = CLR;			
			ucBATTERY_CDS_state = BAT_CDS_LEVEL1;
	
		}

		if((AD_Battery_temp <= *(MOTORSTEP_BAT_LEVEL_TEMP + 0))&&(AD_count_Battery_temp == 0))	// 1sec period	// 2016_0923_ADH
		{
			ucBATTERY_low_off_count++;		//2016_0926_adh test
		//	ucBATTERY_low_off_count = 0;		//2016_0926_adh test
		}
		else
		{
			if(AD_Battery_temp > *(MOTORSTEP_BAT_LEVEL_TEMP + 0))		// 0.1sec period
				ucBATTERY_low_off_count = 0;
		}
		
		
		if(ucBATTERY_COMPLETE_voice == 1)			// 2016_0908_adh
			ucBATTERY_COMPLETE_voice = 0;


		if(ucBATTERY_low_off_count >= 2)			// 2016_0908_adh		
		{			// 2sec ���� ���ӵ� �� Power Off and ���� 
			if(gPowerOnSec == 0)
			{
				if(POWER_ON)
				{
					Power_Off_Exe();    //���� 

					if(ucBATTERY_LOW_Lock == 0)		// 2016_0909_adh
						ucBATTERY_LOW_Lock = 1;
				}

				ucBATTERY_low_off_count = 0;
				

			}
		}
		//else
		//{
		//	if(AD_Battery_temp > BAT_LEVEL_L )
		//		ucBATTERY_low_off_count = 0;
		//}

		if(POWER_ON == CLR)
		{
			BATTERY_LED4 = CLR;		
			BATTERY_LED3 = CLR;		
			BATTERY_LED2 = CLR;		
			BATTERY_LED1 = CLR;	
		}	



	}

	if(ucBATTERY_LOW_Lock == 1)
	{
		BATTERY_LED4 = CLR;		
		BATTERY_LED3 = CLR;		
		BATTERY_LED2 = CLR;		
		BATTERY_LED1 = CLR;	
	}	


/*
	if((Battery_State_Old == BAT_STATE_SUSPEND)&&(POWER_ON == 0))
	{
		if(( Battery_State == BAT_STATE_COMPLETE)||( Battery_State == BAT_STATE_CHARGING))
			MICOM_RESET = 1;
	}

	if(Battery_State_Old != Battery_State)
	{
		battery_state_check_count++;

		if(battery_state_check_count >= 2)
		{
			Battery_State_Old = Battery_State;	
			battery_state_check_count = 0;
		}
	}else
	{
			battery_state_check_count = 0;
	}
*/
// stat1 : 1, stat2 : 0 => Charge in progress
// stat1 : 0, stat2 : 1 => Charge complete
// stat1 : 0, stat2 : 0 => Charge suspend, timer fault, overvoltage, sleep mode, battery absent	


}

void Power_stop_Mode(void)	// adh
{
	unsigned char d = 0;

	if(PStop_1sec_check == 1)
	{
		PStop_1sec_check = 0;

//		if(( Battery_State == BAT_STATE_SUSPEND )&&(POWER_ON == 0)&&(REPEAT_ON == CLR))
		if(( Battery_State == BAT_STATE_SUSPEND )&&(POWER_ON == 0)&&(REPEAT_ON == CLR)
//			&&(f_Timer == CLR)&&(PG == SET)&&(fUSER_SVC_MODE_SET == CLR)) 
			&&(f_Timer == CLR)&&(fUSER_SVC_MODE_SET == CLR)&&(HELP_MODE_SET == CLR)&&(ucPacking_mode_flag == CLR)) 
		{	// ���͸��� ���� ��, ���� �����̰�, �ݺ� ������ �ƴϰ�, 
			// ������ �ƴϰ�, �ƴ��� ����ȵǰ�, ����� ��尡 �ƴ� �� ����
			// ���� ����, �ݺ����� �����߿��� HELP MODE ���Ծ���
			//if( AD_Battery_temp_MAX < 808)		// 2016_0926_test
			//{
				if(ucPStop_start_count >= 60)// Test :10sec ���� : 5������ set �� �� 10*60=600
				{
					
					STAND_BY_POWER = OFF;
					//ucPStop_start_count++;
					
					//if(ucPStop_start_count >= 61)
					//{
						ucPStop_start_count = 0;
						ucSleep_mode_flag = 1;
						Sleep_mode_init_data();
				//	}

				}else
					ucPStop_start_count++;
			//}else
			//	ucPStop_start_count = 0;

		}
		else
		{
			ucPStop_start_count = 0;
			STAND_BY_POWER  = ON;
		}

	}
	
	// MCU sleep mode
	/*
	if(ucSleep_mode_flag == 1)
	{
	    
		//ModeChange(SLOW);
		//AJH SYSCK = ON;		
		for(d=0 ; d<10 ;++d) __asm("   NOP");
		//AJH XEN = OFF;
		__asm("   NOP");
		__asm("   NOP");
		do{
			//AJH WDCDR = 0x4E;        // fc,reset output
			//AJH IDLE = ON;
			

			//for(d=0 ; d<250 ; ++d) __asm("   NOP");

		}while(ucSleep_mode_flag != 0);
		*/
//		ucSleep_mode_off_flag = 1;
/*
		if((Battery_STAT1 == SET)&&(Battery_STAT2 != SET))
		{
			Battery_State = BAT_STATE_COMPLETE;	//2			FULL Charging Complete
		}
		else if((Battery_STAT1 != SET)&&(Battery_STAT2 == SET))
		{
			Battery_State = BAT_STATE_CHARGING;	//1			Under Charging
		}
				
	//	if((  Battery_State == BAT_STATE_COMPLETE) ||  (Battery_State == BAT_STATE_CHARGING))
		if(Battery_STAT1||Battery_STAT2)
		{
			if(Battery_STAT2)
			{

			}
			else
			{
				if(	ucBATTERY_LOW_Lock == 0)
						init_data();
			}
		}

		if(Battery_STAT2)
		{
			if(	ucBATTERY_LOW_Lock == 0)
					init_data();

		}*/
			//INIT = 1;
			//VOICE_RESETED = CLR;
			//VOICE_START = CLR;
		
		//ModeChange(NORMAL);
		//XEN = ON;
		//for(d=0 ; d<10 ; ++d) __asm("   NOP");
		//SYSCK = OFF;

			

	//}
}

void Sleep_mode_init_data(void)
{
/*
//	port_initial();
	//P0DR = 0x00;
	//P1DR = 0x00;
	//P5DR = 0x00;
	//P7DR = 0x00;
	P2DR = 0x00;	
	P4DR = 0x00;
	P8DR = 0x00;
	P9DR = 0x00;
	PBDR = 0x00;
	VOICE_SSB_PORT = CLR;
	VOICE_MISO_PORT= CLR;
	VOICE_SCLK_PORT   = CLR;        //  P54       // voice clock
/**/

}


