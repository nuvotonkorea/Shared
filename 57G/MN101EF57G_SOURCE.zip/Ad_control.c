/******************************************************************************
**
**  COPYRIGHT (C) 
**
**  THIS WORK CONTAINS TRADE SECRET AND PROPRIETARY INFORMATION WHICH IS
**  THE PROPERTY OF CUCKOO
**
**  PROJECT NAME:   
**
**  FILENAME:       .c
**
**  PURPOSE:        
**
**  FUNCTIONS:      
**
**  AUTHOR:
**
**  VERSION:        1.0
**
**  LAST MODIFIED:  
******************************************************************************/
/*****************************************************************************
Note:

*******************************************************************************/

#include    "typedef.h"
#include    "srMN101EF57G.h"
#include    "main.h"
#include    "global_func.h"
#include    <stdlib.h>
#define ROOT

    //=======================================
    //= ���� A/D�� 10�� DATA Table  =
    //=======================================
const unsigned char Hu_Data_TBL[256] = 
{	//25�� ����
    //      0   1   2   3   4   5   6   7   8   9  
            20, 21, 22, 23, 24, 25, 26, 27, 28, 29, // 000 ~ 009
            30, 30, 31, 31, 32, 32, 33, 33, 34, 34, // 010 ~ 019
            35, 35, 35, 36, 36, 36, 37, 37, 37, 38, // 020 ~ 029
            38, 38, 39, 39, 39, 40, 40, 40, 41, 41, // 030 ~ 039
            41, 41, 41, 42, 42, 42, 42, 42, 43, 43, // 040 ~ 049
            43, 43, 43, 44, 44, 44, 44, 44, 45, 45, // 050 ~ 059
            45, 45, 46, 46, 46, 46, 46, 46, 47, 47, // 060 ~ 069
            47, 47, 47, 47, 48, 48, 48, 48, 48, 48, // 070 ~ 079
            49, 49, 49, 49, 49, 49, 50, 50, 50, 50, // 080 ~ 089
            50, 50, 51, 51, 51, 51, 51, 51, 51, 51, // 090 ~ 099
            52, 52, 52, 52, 52, 52, 52, 52, 53, 53, // 100 ~ 109
            53, 53, 53, 53, 53, 53, 54, 54, 54, 54, // 110 ~ 119
            54, 54, 54, 55, 55, 55, 56, 56, 56, 56, // 120 ~ 129
            56, 56, 57, 57, 57, 57, 57, 57, 57, 58, // 130 ~ 139
            58, 58, 58, 58, 58, 58, 59, 59, 59, 59, // 140 ~ 149
            59, 59, 59, 60, 60, 60, 60, 60, 60, 61, // 150 ~ 159
            61, 61, 61, 61, 61, 62, 62, 62, 62, 62, // 160 ~ 169
            63, 63, 63, 63, 63, 64, 64, 64, 64, 64, // 170 ~ 179
            65, 65, 65, 65, 65, 66, 66, 66, 66, 66, // 180 ~ 189
            67, 67, 67, 67, 67, 68, 68, 68, 68, 69, // 190 ~ 199
            69, 69, 69, 70, 70, 70, 71, 71, 71, 72, // 200 ~ 209
            72, 72, 73, 73, 73, 74, 74, 74, 75, 75, // 210 ~ 219
            76, 76, 77, 77, 78, 78, 78, 79, 79, 80, // 220 ~ 229
            80, 81, 81, 82, 83, 84, 85, 85, 86, 87, // 230 ~ 239
            88, 89, 90, 90, 90, 90, 90, 90, 90, 90, // 240 ~ 249
            90, 90, 90, 90, 90, 90,         // 250 ~ 255
};

#ifndef TEST_CODE_SIZE_OPTIMIZE
const unsigned char Hu_Data_SECOND_TBL[256] = 
{	//15�� ����
    //      0   1   2   3   4   5   6   7   8   9  
            20, 21, 22, 23, 24, 25, 26, 27, 28, 29, // 000 ~ 009
            30, 31, 31, 32, 32, 33, 33, 34, 35, 35, // 010 ~ 019
            35, 36, 36, 36, 37, 37, 37, 38, 38, 38, // 020 ~ 029
            38, 39, 39, 39, 40, 40, 40, 41, 41, 41, // 030 ~ 039
            41, 41, 41, 42, 42, 42, 42, 42, 43, 43, // 040 ~ 049
            43, 43, 43, 44, 44, 44, 44, 44, 45, 45, // 050 ~ 059
            45, 45, 46, 46, 46, 46, 46, 46, 47, 47, // 060 ~ 069
            47, 47, 47, 47, 48, 48, 48, 48, 48, 48, // 070 ~ 079
            49, 49, 49, 49, 49, 49, 50, 50, 50, 50, // 080 ~ 089
            50, 50, 50, 51, 51, 51, 51, 51, 51, 51, // 090 ~ 099
            52, 52, 52, 52, 52, 52, 52, 52, 53, 53, // 100 ~ 109
            53, 53, 53, 53, 53, 53, 54, 54, 54, 54, // 110 ~ 119
            54, 54, 54, 54, 55, 55, 55, 55, 55, 55, // 120 ~ 129
            56, 56, 56, 56, 56, 56, 56, 57, 57, 57, // 130 ~ 139
            57, 57, 57, 57, 57, 58, 58, 58, 58, 58, // 140 ~ 149
            58, 58, 58, 59, 59, 59, 59, 59, 59, 60, // 150 ~ 159
            60, 60, 61, 61, 61, 61, 61, 61, 62, 62, // 160 ~ 169
            62, 62, 62, 63, 63, 63, 63, 63, 63, 64, // 170 ~ 179
            64, 64, 64, 64, 64, 65, 65, 65, 65, 66, // 180 ~ 189
            66, 66, 66, 66, 67, 67, 67, 67, 68, 68, // 190 ~ 199
            68, 68, 68, 69, 69, 69, 69, 70, 70, 70, // 200 ~ 209
            71, 71, 71, 72, 72, 72, 73, 73, 73, 74, // 210 ~ 219
            74, 74, 75, 75, 76, 76, 77, 77, 78, 78, // 220 ~ 229
            79, 79, 80, 80, 81, 82, 83, 84, 85, 85, // 230 ~ 239
            86, 87, 88, 89, 90, 90, 90, 90, 90, 90, // 240 ~ 249
            90, 90, 90, 90, 90, 90,         // 250 ~ 255
};

const unsigned char Hu_Data_THIRD_TBL[256] = 
{	//35�� ����
    //      0   1   2   3   4   5   6   7   8   9  
            20, 21, 22, 23, 24, 25, 26, 27, 28, 29, // 000 ~ 009
            30, 30, 31, 31, 32, 32, 33, 33, 34, 34, // 010 ~ 019
            35, 35, 36, 36, 37, 37, 37, 38, 38, 38, // 020 ~ 029
            38, 39, 39, 39, 40, 40, 40, 41, 41, 41, // 030 ~ 039
            41, 41, 41, 42, 42, 42, 42, 42, 43, 43, // 040 ~ 049
            43, 43, 43, 44, 44, 44, 44, 44, 45, 45, // 050 ~ 059
            45, 45, 46, 46, 46, 46, 46, 46, 47, 47, // 060 ~ 069
            47, 47, 47, 47, 48, 48, 48, 48, 48, 48, // 070 ~ 079
            49, 49, 49, 49, 49, 49, 50, 50, 50, 50, // 080 ~ 089
            50, 50, 50, 51, 51, 51, 51, 51, 51, 52, // 090 ~ 099
            52, 52, 52, 52, 52, 53, 53, 53, 53, 53, // 100 ~ 109
            53, 54, 54, 54, 54, 54, 54, 54, 55, 55, // 110 ~ 119
            55, 55, 55, 55, 55, 56, 56, 56, 56, 56, // 120 ~ 129
            56, 57, 57, 57, 57, 57, 57, 58, 58, 58, // 130 ~ 139
            58, 58, 58, 59, 59, 59, 59, 59, 59, 60, // 140 ~ 149
            60, 60, 60, 60, 60, 61, 61, 61, 61, 61, // 150 ~ 159
            62, 62, 62, 62, 62, 62, 63, 63, 63, 63, // 160 ~ 169
            63, 63, 64, 64, 64, 64, 64, 65, 65, 65, // 170 ~ 179
            65, 66, 66, 66, 66, 67, 67, 67, 67, 67, // 180 ~ 189
            68, 68, 68, 68, 69, 69, 69, 69, 70, 70, // 190 ~ 199
            70, 70, 71, 71, 71, 72, 72, 72, 73, 73, // 200 ~ 209
            73, 74, 74, 74, 75, 75, 75, 76, 76, 77, // 210 ~ 219
            77, 78, 78, 79, 79, 80, 80, 81, 81, 82, // 220 ~ 229
            83, 84, 84, 85, 85, 86, 87, 88, 89, 90, // 230 ~ 239
            90, 90, 90, 90, 90, 90, 90, 90, 90, 90, // 240 ~ 249
            90, 90, 90, 90, 90, 90,         // 250 ~ 255
};
#endif

    //=======================================
    //= ȯ��µ� A/D�� 10�� DATA Table  =
    //=======================================
const unsigned char Th_Data_TBL[256] = 
{
    //      0   1   2   3   4   5   6   7   8   9  
            99, 99, 99, 99, 99, 99, 99, 99, 99, 99, // 000 ~ 009
            95, 92, 90, 88, 86, 84, 82, 80, 79, 77, // 010 ~ 019
            76, 75, 73, 72, 71, 70, 69, 68, 67, 66, // 020 ~ 029
            65, 64, 63, 62, 61, 61, 60, 59, 58, 58, // 030 ~ 039
            57, 56, 56, 55, 54, 54, 53, 53, 52, 51, // 040 ~ 049
            51, 50, 50, 49, 49, 48, 48, 47, 47, 46, // 050 ~ 059
            46, 45, 45, 44, 44, 43, 43, 42, 42, 42, // 060 ~ 069
            41, 41, 40, 40, 39, 39, 39, 38, 38, 37, // 070 ~ 079
            37, 37, 36, 36, 36, 35, 35, 34, 34, 34, // 080 ~ 089
            33, 33, 33, 32, 32, 32, 31, 31, 31, 30, // 090 ~ 099
            30, 30, 29, 29, 29, 28, 28, 28, 27, 27, // 100 ~ 109
            27, 26, 26, 26, 25, 25, 25, 24, 24, 24, // 110 ~ 119
            23, 23, 23, 22, 22, 22, 22, 21, 21, 21, // 120 ~ 129
            20, 20, 20, 19, 19, 19, 18, 18, 18, 18, // 130 ~ 139
            17, 17, 17, 16, 16, 16, 15, 15, 15, 14, // 140 ~ 149
            14, 14, 14, 13, 13, 13, 12, 12, 12, 11, // 150 ~ 159
            11, 11, 10, 10, 10,  9,  9,  9,  8,  8, // 160 ~ 169
             8,  7,  7,  7,  6,  6,  6,  5,  5,  5, // 170 ~ 179
             4,  4,  4,  3,  3,  3,  2,  2,  2,  1, // 180 ~ 189
             1,  1,  0,  0,  0,  0,  0,  0,  0,  0, // 190 ~ 199
             1,  1,  0,  0,  0,  0,  0,  0,  0,  0, // 200 ~ 209
             1,  1,  0,  0,  0,  0,  0,  0,  0,  0, // 210 ~ 219
             1,  1,  0,  0,  0,  0,  0,  0,  0,  0, // 220 ~ 229
             1,  1,  0,  0,  0,  0,  0,  0,  0,  0, // 230 ~ 239
             1,  1,  0,  0,  0,  0,  0,  0,  0,  0, // 240 ~ 249
             0,  0,  0,  0,  0,  0,         // 250 ~ 255
};

volatile char   WarmEnv_beta = 0;


void Ad_Check_10msec(void);
void Ad_Check_100msec(void);

void Ad_control(void)
{
    //Ad_Check_10msec();
    Ad_Check_100msec();
    //if(Humi_05ms)
    //{
    //    Hu_ADC_Svc();
    //    Humi_05ms = CLR; 
    //}
      
    if(f_AD_REQ)                //0.5ms * 250 => 250ms
    {
        f_AD_REQ = 0;
        HU_Data_Svc();          // A/D(����, �µ�) �Լ� ����
    }
}

void Ad_Check_10msec(void)
{
//    // 10msec ȣ�� 
//    if(!AD_10mS) return;
//    AD_10mS = 0;
//    
//    Cds_ad();
//    Th_ADC_Svc();
}

void Ad_Check_100msec(void)
{
    // 100msec ȣ�� 
    if(!AD_100mS) return;
    AD_100mS = 0;
    
    if(FAST_MODE_ON == SET)
	{
		if(++gFastAdChkCnt < 10) return;
		gFastAdChkCnt = 0;
	}
	
    // Dust sensor data readd
	DUST_DetectPM();

    // Check Filter door open or close
    FilterDoorCheck();
    // ���밨�� ����
    WaterDoorCheck();   //AJH 160528 ���밨�� �߰�
    //�������� ����
    WaterLevelCheck();   //AJH 160609 �������� �߰�    
    // �������� ȯ��µ� ��
//    WarmEnvAdjust();   
    //Battery_voltage_ad();   //codeless
}


//volatile unsigned int ADupperBit;
//volatile unsigned int ADlowerBit;
//volatile unsigned int ADbuffer;

unsigned int GetADCValue(unsigned char Channel)
{
    //unsigned int ad_temp = 0;
	//unsigned char ad_temp = 0;
    //unsigned int ad_imsi_L = 0;
    //unsigned int ad_imsi_H = 0;
    

	ad_temp = 0;
    ad_imsi_L = 0;
    ad_imsi_H = 0;
    
    //ANCTR2  = 0x00;         // TO_DO_LIST:
	//ANCTR0 = 0x0C;
	ANCTR1 = (Channel & 0x0F);                /* Set channel number */
	//ANCTR1 = 0x0e;
	asm("   NOP");
	asm("   NOP");
	asm("   NOP");
	asm("   NOP");
	asm("   NOP");
	
	ANCTR2 = 0x80;							 /* Start AD conversion */
	
    do
    {
        asm("   NOP");
    }while(ANCTR2 & 0x80);

	ad_imsi_H = ANBUF0;
	ad_imsi_L = ANBUF1;
	ad_temp = ANBUF;
	
	//ADlowerBit = ANBUF0;
	//ADupperBit = ANBUF1;
	//ADlowerBit = ADlowerBit >> 6;
	//ADupperBit = ADupperBit << 2;
	//ADbuffer = ADlowerBit | ADupperBit;
	//ad_temp = ADbuffer >> 2;
	
	
	
	//P8OUT0 = CLR; // debug only
	//codeless
	
	if( Channel == BATTERY_GAUGING_AD)
	{
	    //ad_imsi_H = ad_imsi_H >> 6;
	    //ad_temp = ad_imsi_H | ad_imsi_L;
	    ad_temp = ad_temp >> 6;
		ad_temp = ad_temp & 0x03ff;		//unsign int 10Bit
	}
	else
	{
	    //ad_temp = ANBUF1;
		ad_temp = ad_temp >> 8;       // 10Bit --> 8Bit
		ad_temp = ad_temp & 0x03ff;		//unsign	
	}
	

    return ad_temp;
}

void Delay_Routine(unsigned int Delay)
{
    while(--Delay)
    {
        asm("nop");
    }
}

// 10msec ȣ��
void Cds_ad(void)
{
    AD_value_cds = GetADCValue(CDS_AD);
    AD_count_cds++;
    AD_sum_cds = AD_sum_cds + AD_value_cds;
    if(AD_count_cds >= 10)
    {
        AD_count_cds = 0;
        AD_avg_cds = AD_sum_cds/10;
        AD_sum_cds = 0;
    }
}

void Th_ADC_Svc(void)   //600ms
{
    if(!CH_MODEL_FLAG) return;
    
    AD_value_th = GetADCValue(HU_TH_AD);
    AD_count_th++;
    AD_sum_th = AD_sum_th + AD_value_th;
    if(AD_count_th >= 60)
    {
        AD_count_th = 0;
        AD_avg_th = AD_sum_th/60;
        AD_sum_th = 0;
    }
}

// 0.5ms ȣ�� 
void Hu_ADC_Svc(void)   //AJH 160320 �������� �߰�
{
    if(!CH_MODEL_FLAG) return;
    
    AD_value_humi = GetADCValue(HUMIDITY_AD);
    AD_count_humi++;

    AD_sum_humi = AD_sum_humi + AD_value_humi;
    HU_250Reg[AD_count_humi] = AD_value_humi;

    if(AD_count_humi >= 250)
    {
        AD_count_humi = 0;
        AD_avg_humi = AD_sum_humi/250;
        AD_sum_humi = 0;
        f_AD_REQ = 1;
        Humi_check = 1;
        Humi_check_int = SET;
    }   
}

void Battery_voltage_ad(void)   //CODELESS
{
    AD_value_bat = GetADCValue(BATTERY_GAUGING_AD);
    AD_count_bat++;
    AD_sum_bat += AD_value_bat;
    if(AD_count_bat >= 10)
    {
        
        AD_avg_bat = AD_sum_bat/AD_count_bat;
		AD_count_bat = 0;
        AD_sum_bat = 0;
    }  
}


//---------------------------------------------------------------
//  task  : HU DATA ó��(�뷫 1��) 10ms X 100 = 1sec
//          1ms *250 * 8 = 2sec
//  input : ������ HU_Scan_Val
//  output: ���� ������ HU_Val
//---------------------------------------------------------------
void HU_Data_Svc(void)
{
    unsigned char rX_Reg, rY_Reg, rA_Reg;
    unsigned int rWord_Reg = 0;
    
    if(!CH_MODEL_FLAG) return;
    
    Humi_Count++;
    if(Humi_Count <= 4)
    {
        Sum_avg_humi = Sum_avg_humi + AD_avg_humi;
        return;
    }
    Humi_Count = 0;
    Avg_humi = Sum_avg_humi/4;
    Sum_avg_humi = 0;
    //HU_8Reg[HU_Point] = AD_avg_humi;    // scan�� data�� 8���� table�� point�� ����Ű�°��� ����
    HU_8Reg[HU_Point] = Avg_humi;    // scan�� data�� 8���� table�� point�� ����Ű�°��� ����
    HU_Point++;             // ���� 8�� Table ���� point
    
    if(HU_Point>=8)
    {
        HU_Point = 0;
        f_Hu_AD_8th =1;
    }

    for(rX_Reg=0;rX_Reg<8;rX_Reg++)
    //for(rX_Reg=0;rX_Reg<16;rX_Reg++)
    {    // Power On�� ram Clear�ǹǷ� ������ ��ü�� ���
        rWord_Reg = rWord_Reg + HU_8Reg[rX_Reg];
        //rWord_Reg = rWord_Reg + HU_16Reg[rX_Reg];
    }
    
    if(f_Hu_AD_8th)
    {            // data 8�� ä�����°�?
        rX_Reg = 8;         // data 8�� ���� ä����
        //rX_Reg = 16;
    }
    else
    {
        rX_Reg = HU_Point;      // power on�� ������� ä���� ����
    }
    
    rY_Reg = rWord_Reg / rX_Reg;        // ä���� ������ŭ ����
    //�������� error ����
    HU_Val_Test = rY_Reg;
#ifndef TEST_CODE_SIZE_OPTIMIZE
    //rA_Reg = Hu_Data_TBL[rY_Reg];       // ���� ����hex������, ���� 10���� �ҷ���
    if(WarmEnvTemp <= 19)
    {
        rA_Reg = Hu_Data_SECOND_TBL[HU_Val_Test];       // ���� ����hex������, ���� 10���� �ҷ���

    }
    else if((WarmEnvTemp >=20) && (WarmEnvTemp < 30))
    {
        rA_Reg = Hu_Data_TBL[HU_Val_Test];       // ���� ����hex������, ���� 10���� �ҷ���
    }
    else
    {
        rA_Reg = Hu_Data_THIRD_TBL[HU_Val_Test];       // ���� ����hex������, ���� 10���� �ҷ���
    }
#else
    rA_Reg = Hu_Data_TBL[HU_Val_Test];       // ���� ����hex������, ���� 10���� �ҷ���
#endif
    HU_Val_Current = rA_Reg;

    if(POWER_ON)
    {
        if(!HUMI_POWER_ON)          //OLD �� �Է�
        {
            HU_Val_Old = HU_Val_Current;
            HUMI_POWER_ON = SET;
        }
        if(HUMI_5MIN)
        {
            if(HU_Val_Old > HU_Val_Current)
            {
                if(FIRST_HUMI_SLOPE_MINUS)
                {
                    if((HU_Val_Old - HU_Val_Current) >= 2)
                    {
                        if((HU_Val_Old - HU_Val_Current) <= 5)
                        {
                            //HU_Val_Old_Current = HU_Val_Old - HU_Val_Current;
                            //HU_Val_Slope = HU_Val_Old_Current>>1;
                            HU_Val_Slope = HU_Val_Old - HU_Val_Current;
                            HUMI_SLOPE_MINUS = SET;
                            HUMI_SLOPE_PLUS = CLR;
                        }
                        else
                        {
                            HU_Val_Slope = 5;
                            HUMI_SLOPE_MINUS = SET;
                            HUMI_SLOPE_PLUS = CLR;
                        }
                    }
                    else
                    {
                        HU_Val_Slope = 0;
                        HUMI_SLOPE_MINUS = CLR;
                        HUMI_SLOPE_PLUS = CLR;
                    }
                }
                else
                {
                    HU_Val_Slope = 0;
                    FIRST_HUMI_SLOPE_MINUS= SET;
                }
            }
            else
            {
                if((HU_Val_Current - HU_Val_Old) >= 2)
                {
                    if((HU_Val_Current - HU_Val_Old) <= 5)
                    {
                        //HU_Val_Old_Current = HU_Val_Current - HU_Val_Old;
                        //HU_Val_Slope = HU_Val_Old_Current>>1;
                        HU_Val_Slope = HU_Val_Current - HU_Val_Old;
                        HUMI_SLOPE_PLUS = SET;
                        HUMI_SLOPE_MINUS = CLR;
                    }
                    else
                    {
                        HU_Val_Slope = 5;
                        HUMI_SLOPE_PLUS = SET;
                        HUMI_SLOPE_MINUS = CLR;
                    }
                }
                else
                {
                    HU_Val_Slope = 0;
                    HUMI_SLOPE_MINUS = CLR;
                    HUMI_SLOPE_PLUS = CLR;
                }
            }
            HUMI_5MIN = CLR;
            HU_Val_Old = HU_Val_Current;
        }
    }
    
    //if(HUMI_1HOUR)
    //{
    //    HU_Val_Slope = 0;
    //}

//CDK
    //if(rA_Reg<50)   { f_Hu_50 = 0; }    // ���� ���� ������ 50% �̻� ?
    //else            { f_Hu_50 = 1; }

    //if(rA_Reg >= 80) {rA_Reg = 80;}     // 90% �̻��� ����
    //if(rA_Reg < 25)  {rA_Reg = 25;}      // 30% ���ϴ� ����
    
    //rA_Reg = rA_Reg + WarmEnv_beta;
    //HU_Val = rA_Reg;            // ������ ����
    if(HUMI_SLOPE_PLUS)
    {
        HU_Val = HU_Val_Current - HU_Val_Slope;
    }
    else if(HUMI_SLOPE_MINUS)
    {
        HU_Val = HU_Val_Current + HU_Val_Slope;
    }
    else
    {
        HU_Val = HU_Val_Current;
    }
}

// 100msec ȣ�� 
void CpiCheck_ad(void)
{
    return;
    
    //AD_value_check_cpi = GetADCValue(ION_CHECK_AD);
    //AD_count_check_cpi++;
    //AD_sum_check_cpi = AD_sum_check_cpi + AD_value_check_cpi;
    //if(AD_count_check_cpi >= 10)
    //{
    //    AD_count_check_cpi = 0;
    //    AD_avg_check_cpi = AD_sum_check_cpi/10;
    //    AD_sum_check_cpi = 0;
    //}   
}

// 100msec ȣ�� 
void FilterDoorCheck(void)
{
    //FILTER_DOOR_NG = CLR;
    //return;
#ifdef TEST_OPT_NO_ERROR
    FILTER_DOOR_NG = CLR;
    return;
#endif
	//if(REED_SWITCH_WDOOR == CLR || POWER_ON == CLR) // ���� ���޽ÿ��� ���� ����
	//if(REED_SWITCH_WDOOR == CLR)
	if(REED_SWITCH_WDOOR == CLR || HELP_MODE_SET == SET)
	{
	    if(FilterDoorCloseCnt >= FILTERDOOR_CLOSE_COUNT) //0.3�� �� �������� ������ �������� ����
	    {
	        FILTER_DOOR_NG = CLR;
	    }
	    else
	    {
	        FilterDoorCloseCnt++;
	    }
		FilterDoorErrCnt = 0;
		
	}
	else // if(POWER_ON == SET && REED_SWITCH_WDOOR == SET)
	{
	    if(FilterDoorErrCnt >= FILTERDOOR_ERR_COUNT)
		{
			FILTER_DOOR_NG = SET;
			error_count = 0;        // 3�� �� ��� ���� display ����
		}
		else//if(FilterDoorErrCnt < FILTERDOOR_ERR_COUNT)
			FilterDoorErrCnt++;

		FilterDoorCloseCnt = 0;
	}

	return;
}
//--------------------------------------------------------
void WaterDoorCheck(void)   //AJH ������ �߰�
{
    //WATER_DOOR_NG = CLR;    //������ ����
    //return;
#ifdef TEST_OPT_NO_ERROR
    WATER_DOOR_NG = CLR;
    return;
#endif
    if(!CH_MODEL_FLAG)      //AJH ������ ����
    {
        WATER_DOOR_NG = CLR;
        return;
    }
    
	if(REED_SWITCH_TANK == CLR || HELP_MODE_SET == SET)
	{
	    if(WaterDoorCloseCnt >= WATERDOOR_CLOSE_COUNT) //0.3�� ������ ����
	    {
	        WATER_DOOR_NG = CLR;
	    }
	    else
	    {
	        WaterDoorCloseCnt++;
	    }
		WaterDoorErrCnt = 0;
		
	}
	else
	{
	    if(WaterDoorErrCnt >= WATERDOOR_ERR_COUNT)
		{
			WATER_DOOR_NG = SET;
			error_count = 0;        // 3�� �� ��� ���� display ����
		}
		else
		{
		    WaterDoorErrCnt++;
		}
		WaterDoorCloseCnt = 0;
	}
	return;
}
//-----------------------------------------------------
void WaterLevelCheck(void)
{
    //if(gVoicePlayWaterLackSkipCnt3) return;
#ifdef TEST_OPT_NO_ERROR
    WATER_LACK = CLR;
    return;
#endif
    if(!CH_MODEL_FLAG)  //AJH ������ ����
    {
        WATER_LACK = CLR;
        return;
    }
	if(REED_SWITCH_FLOAT == CLR || HELP_MODE_SET == SET)
	{
	    if(WaterLevelCloseCnt >= WATERLEVEL_CLOSE_COUNT) //0.3�� ������ ����
	    {
	        WATER_LACK = CLR;
	        gVoicePlayWaterLackSkipCnt2 = 0;
	        gVoicePlayWaterLackSkipCnt3 = 0;
	    }
	    else
	    {
	        WaterLevelCloseCnt++;
	    }
		WaterLevelErrCnt = 0;
		
	}
	else
	{
	    if(WaterLevelErrCnt >= WATERLEVEL_ERR_COUNT)
		{
			//if(!WATER_LACK)
			if(!WATER_LACK && !SET_ERROR_FLAG)
			{
			    //if(POWER_ON) VoiceOutOneSvc(0x7F,0, NONE_BEEP); //���� �������ּ���.
			    if(POWER_ON)
			    {
			        if(gVoicePlayWaterLackSkipCnt2 || gVoicePlayWaterLackSkipCnt3) 
			        {
			            gVoicePlayWaterLackSkipCnt2 = 0;
			            gVoicePlayWaterLackSkipCnt3 = 0;
			        }
			        else if(((MenuMode == MENU_AIRCLEAN_BABY) || (MenuMode == MENU_AIRCLEAN_BED_TIME)) && gVoicePlayWaterLackSkipCnt)
                    {
                        VoiceOutOneSvc(VOICE_STOP_CODE,0, NONE_BEEP); //��ư�� ����
                        gVoicePlayWaterLackSkipCnt = 0;
                    }
			        else 
			        {
			            VoiceOutOneSvc(0x7F,0, NONE_BEEP); //���� �������ּ���.
			        }
			    }
			}
			WATER_LACK = SET;
		}
		else
		{
		    WaterLevelErrCnt++;
		}
		WaterLevelCloseCnt = 0;
	}
	return;
}
//-----------------------------------------------------
//void GasSensorErrCheck(void)
//{
//#ifdef TEST_OPT_NO_ERROR    // main.h�� define ����� ���� ó�� ������
//    return;
//#endif  
//    if((AD_avg_gas < GAS_ERR_VALUE_SHORT) && (AGING_MODE == SET))
//    {
//        ErrGasSenShortCnt++;
//        if(ErrGasSenShortCnt >= GAS_SHORT_ERR_COUNT)
//        {
//            GAS_SENSOR_NG = SET;
//            ErrGasSenShortCnt = 0;
//        }    
//    }
//    else
//    {
//        GAS_SENSOR_NG = CLR;
//        ErrGasSenShortCnt = 0;    
//    }
//}
//�������� ȯ��µ� ���� 
void WarmEnvAdjust(void)
{
    short m;

    ADEnvSensor_sum += AD_avg_th;      //0.6�� ������ ����
    (ADEnvSensor_cnt)++;
    if(ADEnvSensor_cnt == 16)
    {
        ADEnvSensor_cnt = 0;
        ADEnvSensor_ave = ADEnvSensor_sum / 16; // ȯ�溸�� �����ֱ� ����, rev_id_071006_1
        ADEnvSensor_sum = 0;
    }
    ADEnvSensor_Temp = Th_Data_TBL[AD_avg_th];
    if(POWER_ON != SET && !HELP_MODE_SET && !MONITORING_MODE)
    {
        WarmEnvClear();
        return;
    }
    
    if(AGING_MODE == SET)
    {
        if(ADEnvSensor_ave >=250)   HUMI_SENSOR_NG = SET;
        else    HUMI_SENSOR_NG = CLR;
    }
    
    return;
}


void WarmEnvClear(void) 
{
    WarmEnvTemp = 20;
    WarmEnv_state = 0;
    ADEnvSensor_cnt = 0;
    ADEnvSensor_sum = 0;
    WarmEnv_cnt = 0;
    WarmEnv_beta = 0;
    return;
}
