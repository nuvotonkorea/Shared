/******************************************************************************
**
**  COPYRIGHT (C) 
**
**  THIS WORK CONTAINS TRADE SECRET AND PROPRIETARY INFORMATION WHICH IS
**  THE PROPERTY OF CUCKOO
**
**  PROJECT NAME:   
**
**  FILENAME:       .c
**
**  PURPOSE:        
**
**  FUNCTIONS:      
**
**  AUTHOR:
**
**  VERSION:        1.0
**
**  LAST MODIFIED:  
******************************************************************************/
/*****************************************************************************
Note:

*******************************************************************************/
#include    <stdlib.h>
#include    "typedef.h"
#include    "srMN101EF57G.h"
#include    "main.h"
#include    "global_func.h"
#include    "wifi.h"

#define ROOT


//del const unsigned char seg_tbl[];

void DustErrRatio_Display(void);
void DustConcentration2_5_Display(void);
//void DustConcentration10_Display(void);
void DustP1_Display(void);
void DustConcentration10_1hourAvgDisplay(void);  // TEST
void DustConcentration2_5_1hourAvgDisplay(void); // TEST
void BldcCurrentRpm_Display(void);
void BldcStep_Display(void);
void CurrentHumi_Display(void);
void BldcTargetRpm_Display(void);
void BldcFreq_Display(void);
void test_mode_display(void);
void Airclean_mode_display(void);
void Salgyun_display();
void Power_off_display(void);
void All_Seg_on_display(void);
void Flash_Check_display(void);
void MoodDisplay(unsigned char fOpt);
void TurboRunTime_Display(void);
void Wifi_Rssi_Display(void);

void Aging_display_small(void);

void Aging_display_4(void);
void Aging_display_3(void);
void Aging_display_2(void);
void Aging_display_1(void);

void Level_set_display(void);
void Monitoring_display(unsigned char);

void Display_com(void);
void Display_clear(void);

void Help_option_display(void);
void Error_display(unsigned char);

void Save_led_on_off();

void Fnd_display(void);
//void Mood_display(void);
void Buffer_transfer();
//void Buffer_transfer_FullTurnOn(void);
//void mood_led_test(unsigned char fOn);
//void Scroll_display();

//AJH 1660629 TK18A DISPLAY 
void wait_TK18A(void);
unsigned char Cwrite_TK18A(unsigned char start_addr, unsigned char dat);
unsigned char Cread_TK18A(unsigned char addr, unsigned char* ch_r);
void DisplayScan_TK18A(void);   //AJH 160629
void _changeMode_TK18A_SDA_OUT(void);
void _changeMode_TK18A_SDA_IN(void);

void DmWrite(unsigned char data);
void DisplayScan(void);

void Led_MenuMode_Svc(void);
void Led_TEST_ONLY(void);

void Button_Lock_display(void);
void Reservation_Time_display(void);

void Humi_Bojung_mode_display(void);
void User_svc_mode_display(void);
void RoomCare_display(void);
void UsrVolume_display(void);
void UsrFilterChgAlert_display(void);
void UsrFndDimming_display(void);
void UsrVoice_display(void);
void UsrSensibility_display(void);
void UsrCdsOption_display(void);
void UsrTurboRunTime_display(void);
void _user_svc_mode_button_led(void);
void _humi_bojung_button_led(void);

void Filter_ChangeReset_display(void);
EXT_SCH const unsigned int Th_Data_TBL[];

const unsigned char seg_tbl[] = 
{
//0,           1,             2,             3,             4,             5,             6,             7,             8,             9,
0x3F,          0x06,          0x5B,          0x4F,          0x66,          0x6D,          0x7D,          0x27,          0x7F,          0x6F,
//A_LET(10),   b_LET(11),     C_LET(12),     d_LET(13),     e_LET(14),     F_LET(15),     g_LET(16),     H_LET(17),     i_LET(18),     S_LET(19),
0x77,          0x7C,          0x39,          0x5E,          0x79,          0x71,          0x6F,          0x76,          0x6F,          0x6D,
//t_LET(20),   o_LET(21),     P_LET(22)      n_LET(23)      O_LET(24)      L_LET(25),     u_LET(26)      U_LET(27)      N_LET(28)      BLANK(29),
0x78,          0x5C,          0x73,          0x54,          0x3F,          0x38,          0x1C,          0x3E,          0x37,          0x00,
//E_LET(30),   r_LET(31),     dash_LET(32)   y_LET(33)      HALF_I_LET(34) l_LET(35),     __LET(36),    c_LET(37)       SEG_FONT_Door(38) k_LET(39)
0x79,          0x50,          0x40,          0x6E,          0x04,          0x06,          0x08,          0x58,          0x0F,           0x70,
//SEG_FONT_OvenRight  SEG_FONT_Room         MINUS_LET
0x0E,                 0x4C,                 0x40
};

const unsigned char mood_color_select[] = 
{0, MOOD_COLOR_OPT_BLUE,MOOD_COLOR_OPT_SKY_BLUE,MOOD_COLOR_OPT_GREEN,MOOD_COLOR_OPT_YELLOW,MOOD_COLOR_OPT_VIOLET,MOOD_COLOR_OPT_RED};   //AJH 160811 �������ܰ� ����
//AJH{0, MOOD_COLOR_OPT_BLUE,MOOD_COLOR_OPT_GREEN,MOOD_COLOR_OPT_YELLOW,MOOD_COLOR_OPT_RED};

// *************************************************************
// *************************************************************
void Display_control(void)
{
    if(DSP_INIT_EEPROM) return;

    if(EEPROM_RESET)
    {
        if(!EEPROM_DSP_05S) return;
        EEPROM_DSP_05S = 0;
        Display_clear();

        if(++dsp_run_step > 3) dsp_run_step = 1;

        if(dsp_run_step == 1){}
        if(dsp_run_step == 2){}
        if(dsp_run_step == 3){}
        Display_com();
        return;
    }

    //if(FOSC_DSP_OFF)  //codeless
    //{
    //    if(gFoscDisplayOffDelayCnt == 0)
    //    {
    //        Display_clear();
    //        Display_com();
    //        return;
    //    }
    //}

    if(INIT)
    {
        Display_clear();
#ifndef TEST_DISPLAY_FULL_ON_JIG     // ���� �ΰ��� ��� DISPLAY ON ������� ������ �������
        if(TOGGL_500)
#endif        
        {
            All_Seg_on_display();
        }
        Display_com();
        return;
    }
    
    // 100ms ���� ���� ����
    if(!DSP_TIME) return;
    DSP_TIME = 0;

    Display_clear();

    if(dsp_addr == POWER_OFF_DISP)
    {
        if(gFilterResetDisplayCnt) 
        {
            if(TOGGL_500) Filter_ChangeReset_display();
        }
        else if((f_Timer == SET) || (reserve_display_time) || (REPEAT_ON == SET)) // ���� ���� DISPLAY
        {
            // ���� ����� ���� ��� ����
            if(LIGHT_SENSING)
            {
                Display_clear();
                POWER_SAVE_LED = 1;
            }
            else
            {
                Reservation_Time_display();
            }
        }
        else
        {
            Power_off_display();
        }
        
		CheckBattery();		// CODELESS

		if(ucPacking_mode_flag) LOCK_LED = SET;	// CODELESS

        Display_com();
        return;
    }
    else
	{
		if(LIGHT_SENSING)			// adh 20160720
		{
			Power_off_display();	// adh 20160720
		}

		CheckBattery();		// 2016_0928_adh
	}


    if(dsp_addr == FLASH_ROM_CHK_DSP)
    {
        Flash_Check_display();
        Display_com();
        return;
    }

    if(dsp_addr == DAGI_MODE_DSP)
    {
        //AJH 160609 ������ǥ��
        if(WATER_LACK && CH_MODEL_FLAG)
        {
            if(MenuMode == MENU_AIRCLEAN_HUMI  && HumiWaterLackToggleCnt)
            {
                if(TOGGL_500)
                {
                    WATER_LED = SET;
                }
                else
                {
                    WATER_LED = CLR;
                }
            }
            else
            {
                WATER_LED = SET;
            }
        }
        //AJH 160609 ������ 
        Airclean_mode_display();
        Display_com();
        return;
    }

    if(dsp_addr == HELP_MODE_DSP)
    {
        SCROLL_DSP = 0;
        Help_option_display();
        Display_com();
        return;
    }

    if(dsp_addr == SETTING_MODE_DSP)
    {
        User_svc_mode_display();
        Display_com();
        return;
    }
    
    if(dsp_addr == HUMI_BOJUNG_MODE_DISP)
    {
        Humi_Bojung_mode_display();
        Display_com();
        return;
    }
}

void Humi_Bojung_mode_display(void)
{
    if(HU_Bojung_Cnt == 6)
    {
        ds10m = MINUS_LET;      
        ds1m  = 9;      
    }
    else if(HU_Bojung_Cnt == 5)
    {
        ds10m = MINUS_LET;      
        ds1m  = 6;  
    }
    else if(HU_Bojung_Cnt == 4)
    {
        ds10m = MINUS_LET;      
        ds1m  = 3;  
    }
    else if(HU_Bojung_Cnt == 3)
    {
        ds10m = BLANK;      
        ds1m  = 9;  
    }
    else if(HU_Bojung_Cnt == 2)
    {
        ds10m = BLANK;      
        ds1m  = 6; 
    }
    else if(HU_Bojung_Cnt == 1)
    {
        ds10m = BLANK;      
        ds1m  = 3; 
    }
    else
    {
        ds10m = BLANK;      
        ds1m  = 0; 
    }
    DUST_DENSITY_LED = SET; //% LED
    _humi_bojung_button_led(); // ���׺���̼�: �����������
}

void _humi_bojung_button_led(void)
{
    MODE_KEY_LED  = SET;    // ����
    WCAP_KEY_LED = SET;    // ����
}

void Airclean_mode_display(void)
{
    unsigned int display_cnt;
    
    if(MONITORING_MODE)
    {
        CLEAN_LAMP_KEY_LED = SET;
        return;
    }
    
    if(touch_lock_display_time)
    {
        Button_Lock_display();
        return;
    }
    
    if(reserve_display_time)
    {
        Reservation_Time_display();
        return;
    }

    Led_MenuMode_Svc();

    // û���� ǥ��
    if(fCLEAN_LAMP_ON)  
    {
//#ifdef TEST_CDS_CONFIG
//    gTotalAirLevel = CleanLampKeyInCnt;
//#endif
        if((MenuMode == MENU_AIRCLEAN_BABY) || (MenuMode == MENU_AIRCLEAN_BED_TIME) || (MenuMode == MENU_AIRCLEAN_MANU))
        {   // ����, ����, ��ħ ��忡���� ����� û��ǥ�� �����ÿ��� ǥ���ϰ� �׷��� ���� ���
            // 7�� �� û���� ǥ�� ���� 
            //if(gDisplayOffTimeCnt || fCLEAN_LAMP_ON_MANU_AIRCLEAN)
            if(gBabyCleanLampOffCnt || fCLEAN_LAMP_ON_BABY || fCLEAN_LAMP_ON_MANU_AIRCLEAN)
            {
                MoodDisplay(mood_color_select[gTotalAirLevel]);
                //CLEAN_LAMP_KEY_LED = SET;
            }
        }
        else
        {   // 
            MoodDisplay(mood_color_select[gTotalAirLevel]);
            //CLEAN_LAMP_KEY_LED = SET;
        }
    }
    if(((MenuMode == MENU_AIRCLEAN_BABY) || (MenuMode == MENU_AIRCLEAN_BED_TIME)) && !gDisplayOffTimeCnt) 
    {
        if(POWER_ON) POWER_KEY_LED = SET; // ����, ��ħ ��� ����� ����/���� ��ư LED ����
        BABY_DIMMING = SET;

#ifndef BLDC_RPM_DISPLAY
        return;
#endif        
    }
    else
        BABY_DIMMING = CLR;
    
#if defined(BLDC_RPM_DISPLAY) || defined(TEST_DUST_SENSOR_TUNE)
    if(FAST_MODE_ON) display_cnt = 25;  // ���Ӹ��: 2.5�� ���� ���� ǥ�� (50/25 100ms count)
    else display_cnt = 5;               // �Ϲݸ��: 5�� �������� ����ǥ��(10/5  1s count)
#else
    display_cnt = 0;
#endif   
    
    if(gDustDisplaySecCnt < display_cnt)
    {
#ifdef BLDC_RPM_DISPLAY        
        if(gDisplaySecCnt) 
        {   
            // �ӵ� ���� ���� �� 3�ʰ� ��ǥ RPM ���� ǥ��
            if(TOGGL_500) BldcTargetRpm_Display();
        }
        else
        {
            // 3�� ���� ���� RPM ǥ��
            BldcCurrentRpm_Display();
        }
#else
        DustConcentration2_5_Display();
#endif
    }
    else
    {
#ifdef TEST_DUST_SENSOR_TUNE
            //DustConcentration10_Display();  // P1 display
            DustP1_Display();
#else   
        if(gDustDisplayButtonCnt)   // �̼����� �� ��ư �Է½� 5�ʰ� PM2.5 �� ǥ����
        {
            DustConcentration2_5_Display();
            MoodDisplay(mood_color_select[gTotalAirLevel]); //AJH 160811 ������ �ܰ躯��
        }
        else
        {
            if((MenuMode == MENU_AIRCLEAN_BABY) || (MenuMode == MENU_AIRCLEAN_BED_TIME))
            {
                if(CH_MODEL_FLAG)
                {
                    CurrentHumi_Display(); //����ǥ��
                }
                else
                {
                    Aging_display_3();
                }
            }
            else
            {
                //if(CH_MODEL_FLAG && !WATER_LACK)
                if(CH_MODEL_FLAG)
                {
                    //AJH 160609 ���� ǥ��
                    if(Humidisplay_timer < 5)
                    {
                        BldcStep_Display(); // ���� �ܼ� ǥ��
                    }
                    else
                    {
#ifdef TEST_DISPLAY_RSSI
                        Wifi_Rssi_Display(); // Wifi RSSI ���� display test
#else
                        CurrentHumi_Display(); //����ǥ��
#endif
                    }
                }
                else
                {
                    BldcStep_Display(); // ���� �ܼ� ǥ��
                }
            }
        }
#endif        
    }
    
    //DustErrRatio_Display(); 
    
    // SEG display
    if(TOUCH_LOCK_OPTION) LOCK_LED = SET;
    if(Timer_Data)
    {
        if((MenuMode == MENU_AIRCLEAN_REPEAT) && CH_MODEL_FLAG)    TURN_ON_TIME_LED = SET;
        TURN_OFF_TIME_LED = SET;
        YETAK_LED = SET;
    }
    
    if((fFILTER_SWITCH_ALARM == SET) && 
        (eeprom_addr_r[USR_FILTER_SWITCH_ADDR] == 1) ) FILTER_CHANGE_LED = SET;
    
    if(eeprom_addr_r[USR_VOLUME_ADDR]) 
    {   
        if(CH_MODEL_FLAG)
        {
            SOUND_LED = SET; //�������϶� ����seg
        }
        else
        {
            DUST_DENSITY_LED = SET; //����û�����϶� ����seg
        }
    }
    // Button LED Display
    //Led_MenuMode_Svc();
    
    if(POWER_ON)        POWER_KEY_LED      = SET;
    if(gBtnLedOffCnt)
    {
        if(TOGGL_500)
            MODE_KEY_LED   = SET;
    }
    if(WcapKeyInCnt%2)  WCAP_KEY_LED       = SET;
    if(Timer_Data)      TIMER_KEY_LED      = SET;
    if(fCPI_ON)         ION_GEN_KEY_LED    = SET;
    if(TURBO_ON)        TURBO_KEY_LED      = SET;
    if(gDustDisplayButtonCnt) CLEAN_LAMP_KEY_LED = SET;

}

// ��� SEG OFF 
void Power_off_display(void)
{
    GRID_FLAG1  = GRID_FLAG1H = 0x00;
    GRID_FLAG2  = GRID_FLAG2H = 0x00;
    GRID_FLAG3  = GRID_FLAG3H = 0x00;
    GRID_FLAG4  = GRID_FLAG4H = 0x00;
    GRID_FLAG5  = GRID_FLAG5H = 0x00;
    GRID_FLAG6  = GRID_FLAG6H = 0x00;
    GRID_FLAG7  = GRID_FLAG7H = 0x00;

    MOOD_LED_RED = MOOD_LED_GREEN = MOOD_LED_BLUE = CLR;

}

void Flash_Check_display(void)
{
    unsigned long flash_rom_dsp;
        
    if(check_sum_step == 0) Aging_display_3();
    else if(check_sum_step == 2)
    {   // checksum error

        if(TOGGL_500)
        {
            ds10m = E_LET;
            ds1m  = F_LET;
        }
        else
        {
            ds1h  = ds10m = ds1m = BLANK;
        }
        
        check_sum_cnt++;
        if(check_sum_cnt >= 120)
        {
            check_sum_cnt = 0;
            check_sum_step = 0;
            dsp_addr = POWER_OFF_DISP;
        }
    }
    else//  if(check_sum_step == 1)
    {
        AGING_DSP = 0;
        flash_rom_dsp = flash_rom;
        dsp1 = flash_rom_dsp & 0x0000000F;
        
        flash_rom_dsp = flash_rom_dsp >> 4;
        dsp2 = flash_rom_dsp & 0x0000000F;
        
        flash_rom_dsp = flash_rom_dsp >> 4;
        dsp3 = flash_rom_dsp & 0x0000000F;
        
        flash_rom_dsp = flash_rom_dsp >> 4;
        dsp4 = flash_rom_dsp & 0x0000000F;
        
        flash_rom_dsp = flash_rom_dsp >> 4;
        dsp5 = flash_rom_dsp & 0x0000000F;
        
        flash_rom_dsp = flash_rom_dsp >> 4;
        dsp6 = flash_rom_dsp & 0x0000000F;
        
        flash_rom_dsp = flash_rom_dsp >> 4;
        dsp7 = flash_rom_dsp & 0x0000000F;
        
        flash_rom_dsp = flash_rom_dsp >> 4;
        dsp8 = flash_rom_dsp & 0x0000000F;
           
        check_sum_cnt++;
        
        
        if(check_sum_cnt < 20)
        {
            ds1h  = BLANK;
            ds10m = dsp6;
            ds1m  = dsp5;
        }
        else if(check_sum_cnt >= 20 && check_sum_cnt < 40 )
        {
            ds1h  = BLANK;
            ds10m = dsp4;
            ds1m  = dsp3;
        }
        else if(check_sum_cnt >= 40 && check_sum_cnt < 60 )
        {
            ds1h  = BLANK;
            ds10m = dsp2;
            ds1m  = dsp1;
        }
        else //if(check_sum_cnt >= 60)
        {
            check_sum_cnt = 0;
            check_sum_step = 0;
            dsp_addr = POWER_OFF_DISP;
        }
    }
}

void All_Seg_on_display(void)
{
    ds10h = ds1h = ds10m = ds1m = 0;
    GRID_FLAG1  = GRID_FLAG1H = 0xFF;
    GRID_FLAG2  = GRID_FLAG2H = 0xFF;
    GRID_FLAG3  = GRID_FLAG3H = 0xFF;
    GRID_FLAG4  = GRID_FLAG4H = 0xFF;
    GRID_FLAG5  = GRID_FLAG5H = 0xFF;
    GRID_FLAG6  = GRID_FLAG6H = 0xFF;
    GRID_FLAG7  = GRID_FLAG7H = 0xFF;

#ifdef TEST_DISPLAY_FULL_ON_JIG     // ���� �ΰ��� ����� ON/OFF ���� ����
    MOOD_LED_RED = MOOD_LED_GREEN = MOOD_LED_BLUE = SET;
#endif
    
}


void MoodDisplay(unsigned char fOpt)
{
    // �����߻��� ����� OFF
    if(error_kind || LIGHT_SENSING)
    {
        MOOD_LED_RED = MOOD_LED_GREEN = MOOD_LED_BLUE = CLR;
        return;
    }
    if(fOpt==0x01)
    {
        MOOD_LED_RED = SET;
         MOOD_LED_GREEN = MOOD_LED_BLUE = CLR;
    }
    else if(fOpt==0x02)
    {
        MOOD_LED_GREEN = SET;
        MOOD_LED_RED =  MOOD_LED_BLUE = CLR;
    }
    else if(fOpt==0x03)
    {
        MOOD_LED_RED = MOOD_LED_GREEN = SET;
          MOOD_LED_BLUE = CLR;
    }
    else if(fOpt==0x04)
    {
        MOOD_LED_BLUE = SET;
        MOOD_LED_RED = MOOD_LED_GREEN = CLR;
    }
    else if(fOpt==0x05)
    {
        MOOD_LED_RED = MOOD_LED_BLUE = SET;
        MOOD_LED_GREEN = CLR;
    }
    else if(fOpt==0x06)
    {
         MOOD_LED_GREEN = MOOD_LED_BLUE = SET;
         MOOD_LED_RED= CLR;
    }
    else if(fOpt==0x07)
    {
          MOOD_LED_RED = MOOD_LED_GREEN = MOOD_LED_BLUE = SET;
    }
    else
    {
        MOOD_LED_RED = MOOD_LED_GREEN = MOOD_LED_BLUE = CLR;
    }
}

void DustErrRatio_Display(void)
{
    char tmp100;
    
    if(TOGGL_500) ds10h = E_LET;

    ds1h  = gPM2_5_AvgData/100;
    tmp100 = gPM2_5_AvgData%100;
    ds10m  = tmp100/10;
    ds1m   = tmp100%10;
    
    return;
}    

void DustConcentration2_5_Display(void)
{
    char tmp100;
        
    FINE_DUST_LED    = SET;
    STEP_LED = SET; //AJH 160811 ������ �ܰ�ǥ��
    
    //ds1h   = gPM2_5_Concentration/100;
    //if(ds1h == 0) ds1h = BLANK;
    
    //tmp100 = gPM2_5_Concentration%100;
    //ds10m  = tmp100/10;
    //if(ds1h == BLANK && ds10m == 0) ds10m = BLANK;
    
    //ds1m   = tmp100%10;
    
    ds1h = ds10m = BLANK;
    ds1m = gTotalAirLevel;

    
    return;
} 

void DustConcentration2_5_1hourAvgDisplay(void)
{
    int avg;
    char tmp100;
    
    if(gDust60MinAvg) avg = gDust60MinAvg;
    else 
    {
        if(gDust60SecAvg) avg = gDust60SecAvg;
        else avg = gPM2_5_Concentration;
    }
    
    if(TOGGL_500) ds10h = A_LET;

    ds1h   = avg/100;
    if(ds1h == 0) ds1h = BLANK;
    
    tmp100 = avg%100;
    ds10m  = tmp100/10;
    if(ds1h == BLANK && ds10m == 0) ds10m = BLANK;
    
    ds1m   = tmp100%10;
    
    return;
}  

//void DustConcentration10_Display(void)
//{
//    char tmp100;
//    
//    //if(TOGGL_500) 
//   // ds10h = d_LET;
//   // EXTRA_FINE_LED   = SET;
//    if(TOGGL_500) FINE_DUST_LED    = SET;
//    DUST_DENSITY_LED = SET;
//
//    ds1h   = gPM10_Concentration/100;
//    if(ds1h == 0) ds1h = BLANK;
//    
//    tmp100 = gPM10_Concentration%100;
//    ds10m  = tmp100/10;
//    if(ds1h == BLANK && ds10m == 0) ds10m = BLANK;
//    
//    ds1m   = tmp100%10;
//    
//    return;
//}   

void DustP1_Display(void)
{
    char tmp100;
    
    FINE_DUST_LED = SET;
    
     // 10���� diplay
    ds1h   = gPM10_AvgData/100;
    if(ds1h == 0) ds1h = BLANK;
    tmp100 = gPM10_AvgData%100;
    ds10m  = tmp100/10;
    if(ds1h == BLANK && ds10m == 0) ds10m = BLANK;
    ds1m   = tmp100%10;
}
void DustConcentration10_1hourAvgDisplay(void)
{
    char tmp100;
    
    if(TOGGL_500) ds10h = d_LET;

    ds1h   = gPM10_1hourAvg/100;
    if(ds1h == 0) ds1h = BLANK;
    
    tmp100 = gPM10_1hourAvg%100;
    ds10m  = tmp100/10;
    if(ds1h == BLANK && ds10m == 0) ds10m = BLANK;
    
    ds1m   = tmp100%10;
    
    return;
}  


void BldcCurrentRpm_Display(void)
{
    int tmp1000,tmp100,tmp10;

    //AJH 160809 "88SEG"����
    tmp1000 = gBldcCurrentRpm/10;
    ds1h  = tmp1000/100;
    if(ds1h == 0) ds1h = BLANK;
    
    tmp100 = tmp1000%100;
    
    ds10m = tmp100/10;
    if(ds1h == BLANK && ds10m == 0) ds10m = BLANK;
    
    ds1m   = tmp100%10;
    //AJH 160809 "88SEG"����
    
    STEP_LED = SET;
    return;
}


void BldcTargetRpm_Display(void)
{
    int tmp1000,tmp100;
    
    ds10h   = gBldcHopeRpm/1000;
    if(ds10h == 0) ds1h = BLANK;
    
    tmp1000 = gBldcHopeRpm%1000;
    ds1h  = tmp1000/100;
    if(ds10h == BLANK && ds1h == 0) ds1h = BLANK;
    
    tmp100 = tmp1000%100;
    ds10m  = tmp100/10;
    if(ds10h == BLANK && ds1h == BLANK && ds10m == 0) ds10m = BLANK;
    
    ds1m   = tmp100%10;

    STEP_LED = SET;
    
    return;
}

void BldcStep_Display(void)
{
    unsigned char data;
    
    //if(gLoadMotorStep == 0) return; // 0�� �� ��� ǥ�� ���� 
    if(gSelMotorStep == 0) return; // 0�� �� ��� ǥ�� ���� 
    
    ds1h  = BLANK;
    ds10m = BLANK;
    //ds1m  = gLoadMotorStep;
    ds1m  = gSelMotorStep;
    
    STEP_LED = SET;

    //ds10m = ADEnvSensor_Temp /10;
    //ds1m = ADEnvSensor_Temp %10;

//#ifdef TEST_GAS_INFO_SAVE
//    data = ReadCurrentGasSensorValue();
//    if(data >= 100) 
//    {
//        ds1h = 1;
//        ds10m = ds1m = 0;
//    }
//    else 
//    {
//        ds1h = BLANK;
//        ds10m = data/10;
//        if(!ds10m) ds10m = BLANK;
//        ds1m  = data%10;
//    }
//    AUTO_HUMI_LED = SET;
//#endif
    return;
}
//AJH 160609 ���� ���� ǥ��
void CurrentHumi_Display(void)
{
    unsigned char hi_data;
    unsigned char low_data;
    
    if(HU_Bojung_Cnt == 6)
    {
        Bojung_Value = -9;      
    }
    else if(HU_Bojung_Cnt == 5)
    {
        Bojung_Value  = -6;  
    }
    else if(HU_Bojung_Cnt == 4)
    {
        Bojung_Value  = -3;  
    }
    else if(HU_Bojung_Cnt == 3)
    {
        Bojung_Value  = 9;  
    }
    else if(HU_Bojung_Cnt == 2)
    {
        Bojung_Value  = 6; 
    }
    else if(HU_Bojung_Cnt == 1)
    {
        Bojung_Value  = 3; 
    }
    else
    {
        Bojung_Value  = 0; 
    }
    //HU_Bojung_Val = HU_Val + HU_Bojung_Plus_Val - HU_Bojung_Minus_Val;
    //HU_Bojung_Val = HU_Val;
    HU_Bojung_Val = HU_Val + Bojung_Value;
    /*  //5%���� ǥ�ý� ����
    if(HU_Bojung_Val < 30)             Display_HU_val = 30;
    if(HU_Bojung_Val <= 34 && HU_Bojung_Val >= 30)    Display_HU_val = 30;
    if(HU_Bojung_Val <= 39 && HU_Bojung_Val >= 35)    Display_HU_val = 35;
    if(HU_Bojung_Val <= 44 && HU_Bojung_Val >= 40)    Display_HU_val = 40;
    if(HU_Bojung_Val <= 49 && HU_Bojung_Val >= 45)    Display_HU_val = 45;
    if(HU_Bojung_Val <= 54 && HU_Bojung_Val >= 50)    Display_HU_val = 50;
    if(HU_Bojung_Val <= 59 && HU_Bojung_Val >= 55)    Display_HU_val = 55;
    if(HU_Bojung_Val <= 64 && HU_Bojung_Val >= 60)    Display_HU_val = 60;
    if(HU_Bojung_Val <= 69 && HU_Bojung_Val >= 65)    Display_HU_val = 65;
    if(HU_Bojung_Val <= 74 && HU_Bojung_Val >= 70)    Display_HU_val = 70;
    if(HU_Bojung_Val <= 79 && HU_Bojung_Val >= 75)    Display_HU_val = 75;
    if(HU_Bojung_Val >= 80)            Display_HU_val = 80;
    */  
    /*  
    if(Display_HU_val_Old < Display_HU_val && Display_HU_val_Old < Display_HU_val)
    {
        Display_HU_5Min_Cnt = 300;
        TIME_5MIN_FLAG = CLR;
    }
    Display_HU_val_Old = Display_HU_val;
    
    if(HUMI_DISPLAY_5MIN)
    {
        Display_HU_Plus_val = Display_HU_val + 5;
        hi_data = Display_HU_Plus_val/10; 
        low_data = Display_HU_Plus_val%10;
        ds10m = hi_data;
        ds1m = low_data %10;
    }
    else
    {
        hi_data = Display_HU_val/10; 
        low_data = Display_HU_val%10;
        ds10m = hi_data;
        ds1m = low_data %10;
    }
    */
    
    Display_HU_val = HU_Bojung_Val;
    if(HU_Bojung_Val < 30)             Display_HU_val = 30;
    if(HU_Bojung_Val >= 80)            Display_HU_val = 80;

    hi_data = Display_HU_val/10;  
    low_data = Display_HU_val%10; 
    ds10m = hi_data;
    ds1m = low_data;
    //HOUR_LED = SET;
    DUST_DENSITY_LED = SET; //% LED
    return;
}

void Wifi_Rssi_Display(void)
{
    
    if(gRssiValue >= 100) 
    {
        ds1h = 1;
        ds10m = ds1m = 0;
    }
    else 
    {
        ds1h = BLANK;
        ds10m = gRssiValue/10;
        if(!ds10m) ds10m = BLANK;
        ds1m  = gRssiValue%10;
    }
    //BABY_LED = REPEAT_LED = SET;
}

//AJH 160609
void BldcFreq_Display(void)
{
    int tmp1000,tmp100;
    
    ds10h   = gBldc_Freq_display/1000;
    if(ds10h == 0) ds10h = BLANK;
    
    tmp1000 = gBldc_Freq_display%1000;
    ds1h  = tmp1000/100;
    if(ds10h == BLANK && ds1h == 0) ds1h = BLANK;
    
    tmp100 = tmp1000%100;
    ds10m  = tmp100/10;
    if(ds10h == BLANK && ds1h == BLANK && ds10m == 0) ds10m = BLANK;
    
    ds1m   = tmp100%10;
    
    return;
}

void TurboRunTime_Display(void)
{
    unsigned int min;
    
    if(gTurboRunTimeSecCnt == 6000)
    {
        ds10m = C_LET;
        ds1m  = o_LET;
    }
    else if(gTurboRunTimeSecCnt != 0)
    {
        min = ((gTurboRunTimeSecCnt-1)/60) + 1;
        ds10m = min/10;
        ds1m  = min%10;
    }
    else
    {
        ds1m = 0;
    }
    
    MINUTE_LED = SET;
}

// *************************************************************************
// *************************************************************************
// *************************************************************************
void Aging_display_4()
{
    AGING_DSP = 1;
    
    ds10h = 0x39;
    ds1h = 0x09;
    ds10m = 0x09;
    ds1m = 0x0F;
    
    aging_count++;
    if(aging_count > 12) aging_count = 1;
    
    switch (aging_count)
    {
        case 1:
            ds10h = ds10h & 0xFE;
        break;
        
        case 2:
            ds1h = ds1h & 0xFE;
        break;
        
        case 3:
            ds10m = ds10m & 0xFE;
        break;
        
        case 4:
            ds1m = ds1m & 0xFE;
        break;
        
        case 5:
            ds1m = ds1m & 0xFD;
        break;
        
        case 6:
            ds1m = ds1m & 0xFB;
        break;
        
        case 7:
            ds1m = ds1m & 0xF7;
        break;
        
        case 8:
            ds10m = ds10m & 0xF7;
        break;
        
        case 9:
            ds1h = ds1h & 0xF7;
        break;
        
        case 10:
            ds10h = ds10h & 0xF7;
        break;
        
        case 11:
            ds10h = ds10h & 0xEF;
        break;
        
        case 12:
            ds10h = ds10h & 0xDF;
        break;
        
        default :
        break;
    }
}

void Aging_display_3()
{
    AGING_DSP = 1;
    
//    ds10h = 0;    //AJH 160809 "88SEG"����
    ds1h = 0;  //AJH 160809 "88SEG"����
//    ds10m = 0x09; //AJH 160809 "88SEG"����
    ds10m = 0x39;   //AJH 160809 "88SEG"����
    ds1m = 0x0F;
    
    aging_count++;
    //if(aging_count > 10) aging_count = 1;
     if(aging_count > 8) aging_count = 1;  //AJH 160809 "88SEG"����
    switch (aging_count)
    {
        case 1:
            //ds1h = ds1h & 0xFE;
            ds10m = ds10m & 0xFE;
        break;
        
        case 2:
            //ds10m = ds10m & 0xFE;
            ds1m = ds1m & 0xFE;
        break;
        
        case 3:
            ds1m = ds1m & 0xFD;
        break;
        
        case 4:
            ds1m = ds1m & 0xFB;
        break;
        
        case 5:
            ds1m = ds1m & 0xF7;
        break;
        
        case 6:
            ds10m = ds10m & 0xEF;
        break;
        
        case 7:
            ds10m = ds10m & 0xDF;
        break;
        
        case 8:
            ds1h = ds1h & 0xBF;
        break;
        
//        case 9:
//            ds1h = ds1h & 0xEF;
//        break;
        
//        case 10:
//            ds1h = ds1h & 0xDF;
//        break;
        
        default :
        break;
    }     
}


void Aging_display_2()
{
    AGING_DSP = 1;
    
    ds10h = 0;
    ds1h = 0;
    ds10m = 0x39;
    ds1m = 0x0F;
    
    aging_count++;
    if(aging_count > 10) aging_count = 1;
    
    switch (aging_count)
    {
        case 2:
            ds10m = ds10m & 0xFE;
        break;
        
        case 3:
            ds1m = ds1m & 0xFE;
        break;
        
        case 4:
            ds1m = ds1m & 0xFD;
        break;
        
        case 5:
            ds1m = ds1m & 0xFB;
        break;
        
        case 6:
            ds1m = ds1m & 0xF7;
        break;
        
        case 7:
            ds10m = ds10m & 0xF7;
        break;
        
        case 9:
            ds10m = ds10m & 0xEF;
        break;
        
        case 10:
            ds10m = ds10m & 0xDF;
        break;
        
        default :
        break;
    }
}

void Aging_display_1()
{
    AGING_DSP = 1;

    ds1h = 0;
    ds10m = 0;
    ds1m = 0x3F;

     
    aging_count++;
    if(aging_count > 6) aging_count = 1;
    
    switch (aging_count)
    {
        case 1:
            ds1m = ds1m & 0xFE;
        break;
        
        case 2:
            ds1m = ds1m & 0xFD;
        break;
        
        case 3:
            ds1m = ds1m & 0xFB;
        break;
        
        case 4:
            ds1m = ds1m & 0xF7;
        break;
        
        case 5:
            ds1m = ds1m & 0xEF;
        break;
        
        case 6:
            ds1m = ds1m & 0xDF;
        break;
        
        default :
        break;
    }
}

void Aging_display_small()
{
    AGING_DSP_SMALL = 1;
    
    ds10h = 0x39;
    ds1h = 0x0F;
    
    dsp_run_step++;
    if(dsp_run_step > 8) dsp_run_step = 1;
     
    switch (dsp_run_step)
    {
        case 1:
            ds10h = ds10h & 0xFE;
        break;
        
        case 2:
            ds1h = ds1h & 0xFE;
        break;
        
        case 3:
            ds1h = ds1h & 0xFD;
        break;
        
        case 4:
            ds1h = ds1h & 0xFB;
        break;
        
        case 5:
            ds1h = ds1h & 0xF7;
        break;
        
        case 6:
            ds10h = ds10h & 0xF7;
        break;
        
        case 7:
            ds10h = ds10h & 0xEF;
        break;
        
        case 8:
            ds10h = ds10h & 0xDF;
        break;
        
        default :
        break;
    }     
}


void Error_display(unsigned char error_data)
{
    if(POWER_ON == CLR) return;
    
    switch (error_data)
    {
        case EUF_ERR:
            ds10m = E_LET;
            ds1m  = F_LET;
        break;
        case GAS_SENSOR_ERR:
            ds10m = E_LET;
            ds1m  = g_LET;
        break;
        case DUST_SENSOR_ERR:
            ds10m = E_LET;
            ds1m  = d_LET;
        break;
        case HUMI_SENSOR_ERR:
            ds10m = E_LET;
            ds1m  = H_LET;
        break;
        case CPI_ERR:
            ds10m = E_LET;
            ds1m  = c_LET;
        break;
        case MOTOR_ERR:
            ds10m = E_LET;
            ds1m  = b_LET;
        break;
        case FILTER_DOOR_ERR:
            ds10m = SEG_FONT_Door;
            ds1m  = C_LET;
            if(!FILTER_DOOR_NG && WATER_DOOR_NG)
            {
                ds10m = L_LET;
                ds1m  = SEG_FONT_OvenRight;
            }
        break;
        //AJH 160609
        case WATER_DOOR_ERR:
            ds10m = L_LET;
            ds1m  = SEG_FONT_OvenRight;
            if(FILTER_DOOR_NG && !WATER_DOOR_NG)
            {
                ds10m = SEG_FONT_Door;
                ds1m  = C_LET;
            }
        break;
        //AJH 160609
        default:
        break;
    }
}

void Save_led_on_off()
{
//    if(save_on_cnt)
//    {
//        save_on_cnt--;
//        SAVE_LED_ON = 1;
//        return;
//    }
//    if(save_off_cnt)
//    {
//        save_off_cnt--;
//        SAVE_LED_ON = 0;
//        return;
//    }
//    
//    save_blink_cnt++;
//    if(save_blink_cnt > save_error_cnt)
//    {
//        save_blink_cnt = 0;
//        save_on_cnt = 0;
//        save_off_cnt = 0;
//        SAVE_3S_OFF = 1;
//    }
//    else
//    {
//        save_on_cnt = 3;
//        save_off_cnt = 3;
//        Save_led_on_off();
//    }
//
}

void Display_com(void)
{
    unsigned char msb_data,lsb_data,dsp_data;
     
    if(MONITORING_MODE)
    {
        Monitoring_display(monitoring_step);
    }
    
    if(dsp_addr == DAGI_MODE_DSP)   // �ʱ� ��� �� ����� ���� ��� ��� ���� ���� ���� �ʱ� ����
    {
        if(error_kind)
        {
            Display_clear();
            if(TOGGL_500) Error_display(error_kind);
        }
        else
        {
            //if(LIGHT_SENSING && mood_clear_time >= 1*60*60)
            if(LIGHT_SENSING)
            {
                Display_clear();
                POWER_SAVE_LED = 1;
            }
        }
    }
    
    // ���� ���: �ܰ� SEG ����
    if(FAST_MODE_ON) 
    {
        if(TOGGL_500) YETAK_LED = SET;
        else          YETAK_LED = CLR;
    }
    
    CLOAD_FLAG  = LOAD_FLAG;
    CLOAD_FLAG2 = LOAD_FLAG2;
    CLOAD_FLAG3 = LOAD_FLAG3;
    //CLOAD_FLAG4 = LOAD_FLAG4;
    
    Fnd_display();
    Buffer_transfer();
    
    dsp_update_flag = 0;
}

// =============================================
void Monitoring_display(unsigned char read_data)
{
    unsigned char msb_data,lsb_data;
    unsigned char data,tmp100;
    
    switch(read_data)
    {
        case MONITOR_BLDC_RPM:
            BldcCurrentRpm_Display();
            AUTO_LED = SET;
        break;
        
        case MONITOR_DUST_SENSOR:
            
            ds10m = gPM10_AvgData/16;
            if(!ds10m) ds10m = BLANK;
            ds1m = gPM10_AvgData%16;

            ROOM_LED = SET;
            FINE_DUST_LED = SET;
        break;
        
        case MONITOR_PM_2_5:
            //DustConcentration2_5_Display();   //AJH 160809 "88SEG"����
            ds10m = gPM2_5_Concentration/16;
            if(!ds10m) ds10m = BLANK;
            ds1m = gPM2_5_Concentration%16;
            FINE_DUST_LED = SET;
            YELLOW_DUST_LED = SET;
        break;
        
        case MONITOR_GAS_RATIO:
            //data = ReadCurrentGasSensorValue();
            if(data >= 100) 
            {
                ds1h = 1;
                ds10m = ds1m = 0;
            }
            else 
            {
                ds1h = BLANK;
                ds10m = data/10;
                if(!ds10m) ds10m = BLANK;
                ds1m  = data%10;
            }
            BABY_LED = SET;
        break;
        
        case MONITOR_GAS_SENSOR_VAL:
           //  ds1h = BLANK;
           // ds10m = AD_avg_gas/16;
          //  if(!ds10m) ds10m = BLANK;
          //  ds1m = AD_avg_gas%16;
          //  AUTO_HUMI_LED = SET;
        break;
        
        case MONITOR_CDS_VALUE:
            ds1h = BLANK;
            ds10m = AD_avg_cds/16;
            if(!ds10m) ds10m = BLANK;
            ds1m = AD_avg_cds%16;
            // ���� SEG ON
            POWER_SAVE_LED = SET;
        break;
        
        case MONITOR_FILTER_TIME:
            if(gFilterWorktimeCnt == 1 || gFilterWorktimeCnt == 2)
            {
                //ds1h = L_LET;         //AJH 160809 "88SEG"����
                ds1h = BLANK;
                ds10m = gFilterWorktimeHigh/16;
                if(!ds10m) ds10m = BLANK;
                ds1m = gFilterWorktimeHigh%16;
                
                AUTO_LED = SET;         //AJH 160809 "88SEG"����
                ROOM_LED = SET;  //AJH 160809 "88SEG"����
            }
            else
            {
                //ds1h = H_LET;         //AJH 160809 "88SEG"����
                ds1h = BLANK;
                ds10m = gFilterWorktimeLow/16;
                if(!ds10m) ds10m = BLANK;
                ds1m = gFilterWorktimeLow%16;
                if(gFilterWorktimeCnt == 0) gFilterWorktimeCnt = 4;
                POWER_SAVE_LED = SET;   //AJH 160809 "88SEG"����
                FINE_DUST_LED = SET;    //AJH 160809 "88SEG"����
            }
            
            HOUR_LED = SET;
            FILTER_CHANGE_LED = SET;
        break;

        case MONITOR_HUMI_DEC :
            msb_data = HU_Val_Current/10; 
            lsb_data = HU_Val_Current%10;
            //ds1h = BLANK;
            ds10m = msb_data;
            ds1m = lsb_data;
            DUST_DENSITY_LED  = SET;    //%
            if(HU_Val_Slope == 5 ) MINUTE_LED = SET;
            else if(HU_Val_Slope >= 1 && HU_Val_Slope < 5) STEP_LED = SET;
        break;
        
        case MONITOR_THER_HEX :

            //ds10m = AD_avg_th /16;
            //ds1m = AD_avg_th %16;
            //ADEnvSensor_Temp = Th_Data_TBL[ADEnvSensor_ave];
            ds10m = ADEnvSensor_Temp /10;
            ds1m = ADEnvSensor_Temp %10;

            //BED_TIME_LED = SET;
        break;
        
        default:
        break;
    }
}

// ===================================
void Level_set_display(void)
{
    if(MOOD_ONF_SET)
    {
        ds10h = BLANK;
        ds1h = BLANK;
        ds10m = O_LET;
        if(work_data == 1)
        {
            ds1h = O_LET;
            ds10m = F_LET;
            ds1m = F_LET;
        }
        else ds1m = n_LET;
    }
    else
    {
        ds10h = BLANK;
        ds1h = BLANK;
        ds10m = BLANK;
        ds1m = work_data;
    }
}

// ======================================
void Help_option_display(void)
{
    unsigned char msb_data,lsb_data;
    unsigned int dsp_data;
    char tmp100;
    
    if(HELP_1S)
    {
        HELP_1S = 0;
        help_mode_count++;
        //AJH if(help_mode_count > 4)
        if(help_mode_count > 8) 
        {
            help_mode_count = 1;
            HELP_MODE_LED_FLAG = ~HELP_MODE_LED_FLAG;
        }
    }
    
    switch (help_option_step)
    {
        case VOICE_DSP:                          // ���α׷� �� ǥ��
            //ds1h  = 1;
            
            if(model_option == MODEL_OPTION_CHN)
            {
                ds10m = c_LET;
                ds1m  = n_LET;
            }
            else //if(model_option == MODEL_OPTION_KOR)
            {
                ds10m = k_LET;
                ds1m  = r_LET;
            }
            
            MODE_KEY_LED = SET;
            AUTO_LED  = SET;
        break;

        case VERSION_DSP:                                      // ���α׷� ����ǥ��

            ds10m = EVENT_VERSION;
            ds1m = VERSION;
            
            MODE_KEY_LED = SET;
            ROOM_LED = SET;
        break;
        
        case FILTER_DOOR_DSP: 
            
            if(REED_SWITCH_WDOOR == CLR)
            {
                // CLOSE
                ds10m = C_LET;
                ds1m  = L_LET;
            }
            else 
            {
                // OPEN
                ds10m = O_LET;
                ds1m  = P_LET;
            }
            YELLOW_DUST_LED = SET;
            MODE_KEY_LED = SET;
        break;
        
        case FREEQUENCY_CHECK:
            //ds1h = 4;
            if(freequency_data == 5) ds10m = 5;
            else ds10m = 6;
            ds1m = 0;
            
            BABY_LED = SET;
            MODE_KEY_LED = SET;
        break;
        
        case MODEL_DSP :   //AJH 160906
            if(CH_MODEL_FLAG)
            {
                ds10m = A_LET;  //      
                ds1m  = H_LET;
            }
            else 
            {
                // OPEN
                ds10m = A_LET;
                ds1m  = __LET;
            }
            BED_TIME_LED = SET;
            MODE_KEY_LED = SET;
        break;
        
        case WATER_DOOR_LACK_DSP :   //AJH 160906
            //ds1h = 3;
            
            if(REED_SWITCH_FLOAT == CLR)
            {
                // CLOSE
                ds1m  = F_LET;
                WATER_LED = CLR;
            }
            else 
            {
                // OPEN
                ds1m  = O_LET;
                WATER_LED = SET;
            }
            if(REED_SWITCH_TANK == CLR)
            {
                // CLOSE
                ds10m  = F_LET;
            }
            else 
            {
                // OPEN
                ds10m  = O_LET;
            }
            AUTO_HUMI_LED = SET;
            MODE_KEY_LED = SET;
            
        break;
        
        case HUMI_CHECK_DSP:
            msb_data = HU_Val/10; 
            lsb_data = HU_Val%10;
            ds1h = BLANK;
            ds10m = msb_data;
            ds1m = lsb_data;
            
            POWER_SAVE_LED = SET;
            DUST_DENSITY_LED = SET;
            MODE_KEY_LED = SET;
        break;
        
        case HUMI_THERMAL_CHECK:
            //ds10m = AD_avg_th/16; 
            //ds1m = AD_avg_th%16;
            //ADEnvSensor_Temp = Th_Data_TBL[ADEnvSensor_ave];
            ds10m = ADEnvSensor_Temp /10;
            ds1m = ADEnvSensor_Temp %10;
            
            FINE_DUST_LED = SET;
            MODE_KEY_LED = SET;
        break;
        
        case BLDC_RPM_CHECK:
            if((gBldcCurrentRpm > gBldcHopeRpm+30) || (gBldcCurrentRpm < gBldcHopeRpm-30))
                BldcCurrentRpm_Display();
            else
            {
                if(TOGGL_500) BldcCurrentRpm_Display();
            }
            
            if(help_option_wcap_cnt == 1) AUTO_LED = SET;   // 1�� ����: �ڵ� SEG ON
            else YELLOW_DUST_LED = SET; // 4�� ����: Ȳ�� SEG ON
            
            WCAP_KEY_LED = SET;
        break;

        case CDS_CHECK:
            ds1h = BLANK;
            ds10m = AD_avg_cds/16;
            if(!ds10m) ds10m = BLANK;
            ds1m = AD_avg_cds%16;
            // ���� SEG ON
            POWER_SAVE_LED = SET;
            TIMER_KEY_LED = SET;
        break;
        
        case CPI_AD_CHECK:
            // 1�ʰ��� ǥ��
            if(help_cpi_display_cnt)
            {
                if(fCPI_ON)
                {
                    ds10m = O_LET;
                    ds1m = N_LET;
                }
                else
                {
                    ds10m = O_LET;
                    ds1m  = F_LET;
                }
                
                help_cpi_display_cnt--;
                
            }
        break;
        
        //case GAS_AD_CHECK:
        //    //ds1h = BLANK;
        //    ds10m = AD_avg_gas/16;
        //    if(!ds10m) ds10m = BLANK;
        //    ds1m = AD_avg_gas%16;
            
        //    TURBO_KEY_LED = SET;
        //break;
        
        //case HUMI_BOJUNG_DSP:
        //    HU_Bojung_Val = HU_Val + HU_Bojung_Plus_Val - HU_Bojung_Minus_Val;
        //
        //    ds10m = HU_Bojung_Val/10;
        //    if(!ds10m) ds10m = BLANK;
        //    ds1m = HU_Bojung_Val%10;
        //    
        //    WCAP_KEY_LED = SET;
        //    MODE_KEY_LED = SET;
        //    TURBO_KEY_LED = SET;
        //    DUST_DENSITY_LED = SET;
        //break;

        case DUST_AD_CHECK:

            FINE_DUST_LED    = SET;
            if(help_option_dust_cnt)
            {
                // P1 �̼� ���� �� ���� ǥ��
                ds10m  = gPM10_AvgData/16;
                if(ds10m == 0) ds10m = BLANK;
                ds1m   = gPM10_AvgData%16;
            }
            else
            {
                // P2 �̼� ���� �� ���� ǥ��
                STEP_LED   = SET;
                ds10m  = gPM2_5_Concentration/16;
                if(ds10m == 0) ds10m = BLANK;
                ds1m   = gPM2_5_Concentration%16;
            }

            CLEAN_LAMP_KEY_LED = SET;
        break;
        
        case DSP_CHECK:
            if(help_mode_count == 1)
            {
                ds1h = ds10m = ds1m = 0;    //AJH 160811
                POWER_KEY_LED = SET;   // 1��
                AUTO_LED = ROOM_LED = HOUR_LED = FILTER_CHANGE_LED = BAT_LED_1 = SET;
                MoodDisplay(mood_color_select[1]);
            }
            else if(help_mode_count == 2)
            {
                ds1h = ds10m = ds1m = 1;
                MODE_KEY_LED = SET;    // 2��
                BABY_LED = YELLOW_DUST_LED = MINUTE_LED = TURN_ON_TIME_LED = TURN_OFF_TIME_LED = BAT_LED_2 = SET;
                MoodDisplay(mood_color_select[2]);
            }
            else if(help_mode_count == 3) 
            {
                ds1h = ds10m = ds1m = 2;
                WCAP_KEY_LED  = SET; // 3��
                BED_TIME_LED = AUTO_HUMI_LED = STEP_LED = LOCK_LED = YETAK_LED = BAT_LED_3 = SET;
                MoodDisplay(mood_color_select[3]);
            }
            else if(help_mode_count == 4)
            {
                ds1h = ds10m = ds1m = 4;
                TIMER_KEY_LED = SET;  //4��
                POWER_SAVE_LED = FINE_DUST_LED = DUST_DENSITY_LED = WATER_LED = SOUND_LED = BAT_LED_4 = SET;
                MoodDisplay(mood_color_select[4]);
            }
            else if(help_mode_count == 5)
            {
                ds1h = ds10m = ds1m = 6;
                ION_GEN_KEY_LED = SET;   //5��
                BED_TIME_LED = AUTO_HUMI_LED = STEP_LED = LOCK_LED = YETAK_LED = BAT_LED_3 = SET;
                MoodDisplay(mood_color_select[5]);
            }
            else if(help_mode_count == 6)
            {
                ds1h = ds10m = ds1m = 8;
                TURBO_KEY_LED = SET; //6 ��
                BABY_LED = YELLOW_DUST_LED = MINUTE_LED = TURN_ON_TIME_LED = TURN_OFF_TIME_LED = BAT_LED_2 = SET;
                MoodDisplay(mood_color_select[6]);
            }
            else if(help_mode_count == 7)
            {
                AUTO_LED = ROOM_LED = HOUR_LED = FILTER_CHANGE_LED = BAT_LED_1 = SET;
                DOT_LED2 = DOT_LED3 = SET;
                CLEAN_LAMP_KEY_LED = SET; // 7��
            }
            else
            {
                Display_clear();
            }
        break;
        
        case EEPROM_CHECK:
            //ds1h = E_LET;
            ds10m =  E_LET;
            if(help_option_eeprom_test_result)
            {
                ds1m = 0;
            }
            else
            {
                ds1m = F_LET;
            }
        break;
        
        default: 
            Display_clear();
        break;
    }
}

void User_svc_mode_display(void)
{
    switch(gUserSvcModeADJ)
    {
        case ROOMCARE_ADJ:   //ROOM CARE ����
            RoomCare_display();
        break;
        
        case USRLANG_ADJ:
            UsrVoice_display();
        break;
        
        case USRVOLUME_ADJ:
            UsrVolume_display();
        break;
        
        case USRFILSWITCH_ADJ:
            UsrFilterChgAlert_display();
        break;
        
        case USRSENSIBILITY_ADJ:
            UsrSensibility_display();
        break;
        
        case USRFNDDIMMING_ADJ:
            UsrFndDimming_display();
        break;
        
        case USRCDSOPT_ADJ:
            UsrCdsOption_display();
        break;
        
        case USRTURBO_ADJ:
            UsrTurboRunTime_display();
        break;
    }
}

// ���׺���̼�: ����� ����
// ����: ����, ��������: ����, �ٶ�����: ����, ���༳��: ����
void _user_svc_mode_button_led(void)
{
    if(gUserSvcSelFlag) 
    {
        // ����� ���� ��忡�� �ٶ����� ��ư���� ���� : ����ȳ�
        if(TOGGL_500) POWER_KEY_LED = SET;
        WCAP_KEY_LED  = SET;
    }
    else
    {
        // ����� ���� ������� : ���� �ȳ�
    	POWER_KEY_LED = SET;
    	if(TOGGL_500) WCAP_KEY_LED  = SET;
    }
	
    MODE_KEY_LED  = SET;    // �����ܰ� �ȳ�
    TIMER_KEY_LED = SET;    // ��� �ȳ�
}

//ROOM CARE ����
void RoomCare_display(void)
{
	if(TOGGL_500)
	{

        if(gUsrRoomcareSel == 1)
        {
	        ds10m = BLANK;
            ds1m  = o_LET;
        }
        else if(gUsrRoomcareSel == 2)
        {
	        ds10m = BLANK;
            ds1m  = O_LET;
        }
        else 
        {
            ds10m  = C_LET;
            ds1m = SEG_FONT_Door;
        }
	}
	
	ROOM_LED = SET;    
    _user_svc_mode_button_led(); // ���׺���̼�: ����� ����
}

// 1: ��� ����
void UsrVoice_display(void)
{
    ds1h = 1;
	if(TOGGL_500)
	{
	    if(gUsrLangSel == LANG_SEL_CHINESE)
	    {
	        ds10m = c_LET;
            ds1m  = n_LET;
        }
        else
        {
   	        ds10m = k_LET;
            ds1m  = r_LET;
        }
	}
	
    _user_svc_mode_button_led(); // ���׺���̼�: ����� ����
	return;
}

// 1: ���� ���� ����
void UsrVolume_display(void)
{
    if(CH_MODEL_FLAG)
    {
        SOUND_LED = SET; //�������϶� ����seg
    }
    else
    {
        DUST_DENSITY_LED = SET; //����û�����϶� ����seg
    }

    ds1h = 2;
	if(TOGGL_500)
	{
	    if(voice_adj_volume == VOICE_MUTE)
	    {
	        ds10m = O_LET;
            ds1m  = F_LET;
        }
        else
        {
            ds10m = BLANK;
            ds1m  = VOICE_MUTE-voice_adj_volume;
        }
	}
	
    _user_svc_mode_button_led(); // ���׺���̼�: ����� ����
    
	return;
}

// 2: ���ͱ�ü�˸�
void UsrFilterChgAlert_display(void)
{
    FILTER_CHANGE_LED = SET;

    ds1h = 3;
	if(TOGGL_500)
	{
	    if(gSeg_filter_switch)
	    {
	        ds10m = O_LET;
            ds1m  = n_LET;
        }
        else
        {
            ds10m = __LET;
            ds1m  = __LET;
        }
	}
	
    _user_svc_mode_button_led(); // ���׺���̼�: ����� ����
	return;
}
// 4: ���� �ΰ���
void UsrSensibility_display(void)
{
    ds1h = 4;
    
	if(TOGGL_500)
	{
        ds10m = BLANK;
        ds1m  = gUsrSensibilityIdx+1;
	}
	
    _user_svc_mode_button_led(); // ���׺���̼�: ����� ����
	return;
}

// 5: ȭ�� ���� ����
void UsrFndDimming_display(void)
{
    ds1h = 5;
	if(TOGGL_500)
	{
	    if(gUsrLedDimming)
	    {
	        ds10m = O_LET;
            ds1m  = n_LET;
        }
        else
        {
            ds10m = __LET;
            ds1m  = __LET;
        }
	}
	
    _user_svc_mode_button_led(); // ���׺���̼�: ����� ����
	return;
}

// 6: ������ ����
void UsrCdsOption_display(void)
{
    ds1h = 6;
    POWER_SAVE_LED = SET;
    
	if(TOGGL_500)
	{
	    if(gCdsNightValueIdx)
	    {
            ds10m = BLANK;
            ds1m  = gCdsNightValueIdx;
        }
        else
        {
            ds10m = O_LET;
            ds1m  = F_LET;
        }
	}
	
    _user_svc_mode_button_led(); // ���׺���̼�: ����� ����
	return;
}

// �ͺ�����
void UsrTurboRunTime_display(void)
{
    ds1h = 7;
	if(TOGGL_500)
	{
	    if(gTurboRunTimeIdx > 50)
	    {
            ds10m = C_LET;
            ds1m  = o_LET;
	    }
	    else //if(gTurboRunTimeIdx == 2)
	    {
	        ds10m = gTurboRunTimeIdx/10;
            ds1m  = gTurboRunTimeIdx%10;;
            MINUTE_LED = SET;
	    }
	}
	
    _user_svc_mode_button_led(); // ���׺���̼�: ����� ����
	return;
}

// ===============================================
void Fnd_display(void)
{
    if(!INIT)
    {
        //if(AGING_DSP && !MONITORING_MODE && !delay_heater_onf_time && !delay_comp_onf_time )
        if(AGING_DSP && !MONITORING_MODE)
        {
            GRID_FLAG1 = ds1h;   
            if(GRID_FLAG2&0x80)
                GRID_FLAG2 = ds10m+0x80;
            else 
                GRID_FLAG2 = ds10m;
                
            if(GRID_FLAG3&0x80)
                GRID_FLAG3 = ds1m+0x80;
            else 
                GRID_FLAG3 = ds1m;
        }
        else
        {
            GRID_FLAG1 = seg_tbl[ds1h];   
            if(GRID_FLAG2&0x80)
                GRID_FLAG2 = seg_tbl[ds10m]+0x80;
            else
                GRID_FLAG2 = seg_tbl[ds10m];
                
            if(GRID_FLAG3&0x80)
                GRID_FLAG3 = seg_tbl[ds1m]+0x80;
            else
                GRID_FLAG3 = seg_tbl[ds1m];
        }
    }

    // 0����(grid 1)
    led_display[0] = GRID_FLAG1;

    // 1����(grid 1)
    led_display[1] = GRID_FLAG1H;
    
    // 2����(grid 2)
    led_display[2] = GRID_FLAG2;

    // 3����(grid 2)
    led_display[3] = GRID_FLAG2H;
    
    // 4����(grid 3)
    led_display[4] = GRID_FLAG3;
     
    // 5����(grid 3)
    led_display[5] = GRID_FLAG3H;
    
    // 6����(grid 4)
    led_display[6] = GRID_FLAG4;
     
    // 7����(grid 4)
    led_display[7] = GRID_FLAG4H;

    // 8,9����(grid 5)
    led_display[8] = GRID_FLAG5;
    led_display[9] = GRID_FLAG5H;
    
    // 8,9����(grid 6)
    led_display[10] = GRID_FLAG6;
    led_display[11] = GRID_FLAG6H;
    
    // 10,11����(grid 7)
    led_display[12] = GRID_FLAG7;
    led_display[13] = GRID_FLAG7H;

}

//void Mood_display(void)
//{
//}
// ===============================================
void Buffer_transfer(void)
{
    unsigned char i;
    for(i = 0; i < MAX_FND_BUF_CNT ;i++)
    {
        led_buffer[i] = led_display[i];

        // TO_DO_LIST: TEST
        //mood_led_buffer[i] = 0x00;
    }
}

//void Buffer_transfer_FullTurnOn(void)
//{
//    unsigned char i;
//    for(i = 0; i < MAX_FND_BUF_CNT; i++)
//    {
//        led_buffer[i] = 0xFF;
//        //mood_led_buffer[i] = 0xFF;
//    }
//}
//
//void mood_led_test(unsigned char fOn)
//{
//    unsigned char i, data;
//
//    if(fOn) 
//        data = 0xFF;
//    else 
//        data = 0x00;
//    
//    for(i = 0; i < MAX_FND_BUF_CNT; i++)
//    {
//        mood_led_buffer[i] = data;
//    }
//    
//}
//// ===============================================
//void wait_2301(void)
//{
//    unsigned char i;
//    for(i=0 ; i<20 ; i++)
//    {
//        __asm( " nop " );
//        __asm( " nop " );
//    }
//}
//
//
//// ********************************
//void write_2301()
//{
//    unsigned char i;
//    for(i=0 ; i<8 ; i++)
//    {
//        DISPLAY_MODULE_DATA = ( write_data & 0x01 ) ? 1 : 0;        // data out
//        wait_2301();
//        DISPLAY_MODULE_CLOCK = 0;                                   // clock high
//        wait_2301();
//        DISPLAY_MODULE_CLOCK = 1;
//        wait_2301();
//        write_data >>= 1;
//    }
//}

void DisplayScan_TK18A(void)   //AJH 160629 //100mS
{
    if(!DISPLAY_100mS) return;
    DISPLAY_100mS = 0;
    
    Cwrite_TK18A(0x32,GRID_FLAG3);  //COM0
//    wait_TK18A();

    
    Cwrite_TK18A(0x33,GRID_FLAG2); //COM1
//    wait_TK18A();

    
    Cwrite_TK18A(0x34,GRID_FLAG7);  //COM2
//    wait_TK18A();

    
    Cwrite_TK18A(0x35,GRID_FLAG4);  //COM3
//    wait_TK18A();

    
    Cwrite_TK18A(0x36,GRID_FLAG5);  //COM4
//    wait_TK18A();

    
    Cwrite_TK18A(0x37,GRID_FLAG6);  //COM5
//    wait_TK18A();

    
//   Cwrite_TK18A(0x38,GRID_FLAG7);    //COM6(������)
//    wait_TK18A();
    
    if(gLedDimmingChkCnt || INIT)               //DISPLAY DIMMING
    {
        Cwrite_TK18A(0x11,COMMAND_ON_KANG);
    }
    else
    {
        if(LIGHT_SENSING)   Cwrite_TK18A(0x11,COMMAND_ON_YAK);
        else Cwrite_TK18A(0x11,COMMAND_ON_MID);
    }
}

void wait_TK18A(void)
{
	unsigned char i;

	for(i=0;i<150;i++)
	{
		asm( " nop " );
		asm( " nop " );
		asm( " nop " );
		asm( " nop " );
	}
}
//**TK18A START**//
void TK18A_start(void)
{
	//GPIO_SetMode(PA, BIT10, GPIO_PMD_OUTPUT);  //I2C_EEPROM_SDA
    _changeMode_TK18A_SDA_OUT();

	DISPLAY_MODULE_DATA = 1;
	wait();
	DISPLAY_MODULE_CLOCK = 1;
	wait();
	DISPLAY_MODULE_DATA = 0;
	wait();
	DISPLAY_MODULE_CLOCK = 0;
	wait();
}
//**TK18A END**//
void TK18A_end(void)
{
	//GPIO_SetMode(PA, BIT10, GPIO_PMD_OUTPUT);  //I2C_EEPROM_SDA
    _changeMode_TK18A_SDA_OUT();

	DISPLAY_MODULE_CLOCK=0;
	wait();
	DISPLAY_MODULE_DATA = 0;
	wait();
	DISPLAY_MODULE_CLOCK=1;
	wait();
	DISPLAY_MODULE_DATA = 1;
	wait();
}
//**RECEIVE TK18A**//
unsigned char get_ack_TK18A(void)
{
	int i=0;
	DISPLAY_MODULE_DATA = 0;
	//GPIO_SetMode(PA, BIT10, GPIO_PMD_INPUT);  //I2C_EEPROM_SDA
	_changeMode_TK18A_SDA_IN();
	wait();
	DISPLAY_MODULE_CLOCK = 1;
	wait();
	while(DISPLAY_MODULE_DATA)if(i++ == 100)return(0);	//Kwak_20130708_1
	wait();
	DISPLAY_MODULE_CLOCK = 0;
	return(1);
}
//**TRANSMITT ACK**//
void put_ack_TK18A(void)
{
	//GPIO_SetMode(PA, BIT10, GPIO_PMD_OUTPUT);  //I2C_EEPROM_SDA
    _changeMode_TK18A_SDA_OUT();
    
	DISPLAY_MODULE_DATA = 0;
	wait();
	DISPLAY_MODULE_CLOCK = 1;
	wait();
	DISPLAY_MODULE_CLOCK = 0;
	wait();
    _changeMode_TK18A_SDA_IN();
	//GPIO_SetMode(PA, BIT10, GPIO_PMD_INPUT);  //I2C_EEPROM_SDA
}
//**TRANSMITT NOACK**//
void put_noack_TK18A(void)
{
	//GPIO_SetMode(PA, BIT10, GPIO_PMD_OUTPUT);  //I2C_EEPROM_SDA
	_changeMode_TK18A_SDA_OUT();
	
	DISPLAY_MODULE_DATA = 1;
	wait();
	DISPLAY_MODULE_CLOCK = 1;
	wait();
	DISPLAY_MODULE_CLOCK = 0;
	wait();
	//GPIO_SetMode(PA, BIT10, GPIO_PMD_INPUT);  //I2C_EEPROM_SDA
}

void write_iic_tk18a(unsigned char dat)
{
	int i;
	//GPIO_SetMode(PA, BIT10, GPIO_PMD_OUTPUT);  //I2C_EEPROM_SDA
	_changeMode_TK18A_SDA_OUT();
	
	for(i=0;i<8;i++)
	{
		DISPLAY_MODULE_DATA = ( dat&0x80 ) ? 1 : 0;
		wait();
		DISPLAY_MODULE_CLOCK = 1;
		wait();
		DISPLAY_MODULE_CLOCK = 0;
		wait();
		dat<<=1;
	}
    _changeMode_TK18A_SDA_IN();
	//GPIO_SetMode(PA, BIT10, GPIO_PMD_INPUT);  //I2C_EEPROM_SDA
}

unsigned char read_iic_tk18a(void)
{
	unsigned char ch;
	unsigned char i;
	
	//GPIO_SetMode(PA, BIT10, GPIO_PMD_INPUT);  //I2C_EEPROM_SDA

	for(i=0; i<8; i++)
	{
		DISPLAY_MODULE_CLOCK = 1;
		wait();
		wait();
		_changeMode_TK18A_SDA_IN();
		
		ch <<= 1;
		ch |= DISPLAY_MODULE_DATA;
		DISPLAY_MODULE_CLOCK = 0;
		wait();
		wait();
	}

	return(ch);
}

unsigned char Cwrite_TK18A(unsigned char start_addr, unsigned char dat)
{
	//char i;
	unsigned char ack_flag = 1;
	
	TK18A_start();						//start signal
	
	write_iic_tk18a(0x80);					//device addr + /wr
	
	if( get_ack_TK18A() )					//ack receive
	{
		write_iic_tk18a(start_addr);				//word addr write
		
		if( get_ack_TK18A() )				//ack receive
		{
			write_iic_tk18a( dat);			//data write
			

				
			if( get_ack_TK18A() ) ack_flag=0;	//Kwak_20130708_1
			else 
			{
				ack_flag=1;
				//return;  YYS TEST ONLY
			}
				
			//eeprom_end();				//Kwak_20130708_1
		}
		else ack_flag=1;
	}
	else ack_flag=1;

	TK18A_end();			//moved, Kwak_20130708_1
	
	//
	//wait_5ms
	//
	return(ack_flag);
}

unsigned char Cread_TK18A(unsigned char addr, unsigned char* ch_r)
{
	unsigned char ch = 1;
	
	TK18A_start();					//start signal
	wait();
	write_iic_tk18a(0x80);				//device addr + /wr
	wait();
	if( get_ack_TK18A() )				//ack receive
	{
		wait();
		write_iic_tk18a(addr);			//word addr write
		wait();
		if( get_ack_TK18A() )			//ack receive
		{
			wait();
			TK18A_start();			//start signal
			wait();
			write_iic_tk18a(0x81);		//device addr + rd
			wait();

			if( get_ack_TK18A() )		//ack receive
			{
				//ch = read_iic();	//1byte read
				*ch_r = read_iic_tk18a();	//1byte read
				ch = 0;			//Kwak_20130708_1

				put_noack_TK18A();
				
				TK18A_end();
			}
		}
	}
	
	return(ch);
}

// Change I/O Mode:SDA OUT
void _changeMode_TK18A_SDA_OUT(void)
{
    //del P2CR = P2CR | 0x80;     //1000 0000
	//P5DIR |= 0x20; 		//p55
	P6DIR |= 0x40; 		//p66
}

// Change I/O Mode:SDA IN
void _changeMode_TK18A_SDA_IN(void)
{
   //del P2CR = P2CR & 0x7F;      //0111 1111
   //P5DIR &= ~0x20; 	
   P6DIR &= ~0x40;  //P66 	
}
//AJH 160629

// Dipslay Polling ��� �Լ� ���� ���: �� 2 msec �ҿ��...
/*
void DisplayScan(void)
{
    unsigned char i;

//#ifdef TEST_DISPLAY_RADIATION
//    if(fCPI_ON) return;
//#endif
    DISPLAY_MODULE_CS = CLR;        //DM IF logic ����, rev_id_080320_1     
    asm( " nop " );
    DmWrite(COMMAND_AUTO_ADDRESS);  //CMD2:inc address, write mode (LD1207 ����)
    asm( " nop " );
    DISPLAY_MODULE_CS = SET;        //DM IF logic ����, rev_id_080320_1 

    asm( " nop " );
    asm( " nop " );
    asm( " nop " );

    DISPLAY_MODULE_CS = CLR;     //DM IF logic ����, rev_id_080320_1 
    asm( " nop " );
    
    DmWrite(COMMAND_ADDRESS);    //CMD3:address assign
    asm( " nop " );
    
    for(i = 0; i < MAX_FND_BUF_CNT ;i++)
    {
        DmWrite(led_buffer[i]);
    }

    asm( " nop " );
    DISPLAY_MODULE_CS = SET;     //DM IF logic ����, rev_id_080320_1 

    asm( " nop " );
    asm( " nop " );
    asm( " nop " );
    
    DISPLAY_MODULE_CS = CLR;     //DM IF logic ����, rev_id_080320_1 
    asm( " nop " );

    DmWrite(COMMAND_GRID_SEG);      //CMD1:display-mode, 7Grids, 11segments (LD1207: 0x01 => 5Grids 11 segment)

    asm( " nop " );

    DISPLAY_MODULE_CS = SET;     //DM IF logic ����, rev_id_080320_1 

    asm( " nop " );
    asm( " nop " );
    asm( " nop " );

    DISPLAY_MODULE_CS = CLR;     //DM IF logic ����, rev_id_080320_1 
    asm( " nop " );
    
    if(LIGHT_SENSING)
    {   // ���� ��� ���Խ� Dispaly �� �ּ������� ����.
        DmWrite(COMMAND_ON_YAK);          //8 + 0(MIN) ~ 7 (MAX) => 
    }
    else if(BABY_DIMMING)
    {   // ��ħ or ���� ��û�� ��� ����
        DmWrite(COMMAND_ON_MID_YAK);          //8 + 0(MIN) ~ 7 (MAX) => 
    }
    else
    {
        if(gLedDimmingChkCnt)
            DmWrite(COMMAND_ON_KANG);        //CMD4:pulse-width-14/16, display-on, rev_id_2k121220_2(mod)
        else
            DmWrite(COMMAND_ON_MID); 
    }
    
    asm( " nop " );
    
    DISPLAY_MODULE_CS = SET;     //DM IF logic ����, rev_id_080320_1 
    
    return;
}
*/

// MC2302 Write
/*
void DmWrite(unsigned char data)
{
    unsigned char n;

    n = 8;
    do
    {
        //mov1(p_MC2301_DIN,(*(RB_BTF*)&d).p0);   //set-data
        DISPLAY_MODULE_DATA = ( data & 0x01 ) ? 1 : 0;        // data out
        data >>= 1;

        DISPLAY_MODULE_CLOCK = CLR;         //SCK, shift-data-in, DM IF logic ����, rev_id_080320_1 
        //setup-time
        asm( " nop " );
        asm( " nop " );
        asm( " nop " );
 
        DISPLAY_MODULE_CLOCK = SET;         //SCK, shift-data-in, DM IF logic ����, rev_id_080320_1     

        //hold-time
        asm( " nop " );

        (n)--;
    }while(n > 0);

    return;
}
*/
// ********************************
void Display_clear(void)
{
     unsigned char i;
     for(i=0;i<MAX_FND_BUF_CNT;i++)
     {
          led_display[i] = 0;
     }
     Power_off_display();
     
     LOAD_FLAG3 = 0;

     if(!SCROLL_DSP)
     {
          ds1m = BLANK;
          ds10m = BLANK;
          ds1h = BLANK;   
          ds10h = BLANK;
     }
     
     AGING_DSP = 0;
     AGING_DSP_SMALL = 0;
}

//void Scroll_display()
//{
//    SCROLL_DSP = 1;
//    scroll_delay_time++;
//    if(scroll_delay_time < 2) return;
//    scroll_delay_time = 0;
//    
//    scroll_time++;
//    if(scroll_time > 13)
//    {
//        scroll_time = 1;
//        cup_onf_dsp_flag = 0;
//    }
//     
//    if(scroll_time <= 5)
//    {
//        //if(INIT_AIR_BAESU && air_pump_drive_time)
//        //if((INIT_AIR_BAESU && air_pump_drive_time) || help_airbeasu_flag)	//v11 bku 2015.01.22
//        //{
//        //    ds10h = S_LET;
//        //    ds1h = t_LET;
//        //    ds10m = A_LET;
//        //    ds1m = n_LET;
//        //}
//
//    }
//    else
//    {
//        ds10h = ds1h;
//        ds1h = ds10m;
//        ds10m = ds1m;
//		
//		if(scroll_time < 10 && !cup_onf_dsp_flag && !INIT_AIR_BAESU && !air_pump_drive_time && !help_airbeasu_flag)
//        {
//           ds1m = BLANK;
//        }
//        else
//        {
//            if((cup_onf_dsp_flag && !COCK_SALGYUN_DRIVE && !SALGYUN_DRIVE)
//              || INIT_AIR_BAESU || air_pump_drive_time || help_airbeasu_flag)
//            
//            {
//                //if(INIT_AIR_BAESU || air_pump_drive_time)
//                if(INIT_AIR_BAESU || air_pump_drive_time || help_airbeasu_flag) 
//                {
//                    if(scroll_time == 6) ds1m = d_LET;
//                    if(scroll_time == 7) ds1m = BLANK;
//                    if(scroll_time == 8) ds1m = b_LET;
//                    if(scroll_time == 9) ds1m = y_LET;
//                    if(scroll_time >= 10) ds1m = BLANK;
//                    if(scroll_time >=13) cup_onf_dsp_flag = 0;
//                }
//                else
//                {
//                    if(cup_flag)
//                    {
//                        if(scroll_time == 6) ds1m = O_LET;
//                        if(scroll_time == 7) ds1m = n_LET;
//                        if(scroll_time >= 8) ds1m = BLANK;
//                        if(scroll_time >=13) cup_onf_dsp_flag = 0;
//                    }
//                    else
//                    {
//                        if(scroll_time == 6) ds1m = O_LET;
//                        if(scroll_time == 7) ds1m = F_LET;
//                        if(scroll_time == 8) ds1m = F_LET;
//                        if(scroll_time >= 9) ds1m = BLANK;
//                        if(scroll_time >=13) cup_onf_dsp_flag = 0;
//                    }
//                }
//            }
//            else 
//            {
//
//                    if(water_out_mode == COLD_OUT)
//                    {
//                        if(scroll_time == 10) ds1m = C_LET;
//                        if(scroll_time == 11) ds1m = o_LET;
//                        if(scroll_time == 12) ds1m = l_LET;
//                        if(scroll_time == 13) ds1m = d_LET;
//                    }
//                    else //if(water_out_mode == WATER_OUT)
//                    {
//                        if(scroll_time == 10) ds1m = P_LET;
//                        if(scroll_time == 11) ds1m = u_LET;
//                        if(scroll_time == 12) ds1m = r_LET;
//                        if(scroll_time == 13) ds1m = HALF_I_LET;
//                    }
//
//
//            }
//        }
//    }
//}



//MENU_AIRCLEAN_AUTO,             // ��û �ڵ�(0)
//MENU_AIRCLEAN_YELLOW_DUST,      // ��û Ȳ��(1)
//MENU_AIRCLEAN_BABY,             // ��û ����(2)
//MENU_AIRCLEAN_REPEAT,           // ��û �ݺ�(3)
//MENU_AIRCLEAN_BED_TIME,         // ��û ��ħ(4)
//MENU_AIRCLEAN_TURBO,            // ��û �ͺ�(5)
//MENU_AIRCLEAN_MANU,             // ��û ����(6)
void Led_MenuMode_Svc(void)
{
    switch(MenuMode)
    {
        case MENU_AIRCLEAN_AUTO :		// �ڵ� SEG ON
            AUTO_LED = SET;
            break;	
        
        case MENU_AIRCLEAN_YELLOW_DUST : // Ȳ�� SEG ON
            YELLOW_DUST_LED = SET;
            break;
        
        case MENU_AIRCLEAN_BABY :		// ���� SEG ON
            BABY_LED = SET;
            break;
        
        case MENU_AIRCLEAN_REPEAT :	    // �ݺ� SEG ON
            //if(CH_MODEL_FLAG)   AUTO_LED = SET;       //�ݺ��� LED OFF
            //else    AUTO_HUMI_LED = SET;
            if(!CH_MODEL_FLAG)   AUTO_HUMI_LED = SET;       //�ݺ��� LED OFF
            break;
            
        case MENU_AIRCLEAN_BED_TIME:    // ��ħ SEG ON
            BED_TIME_LED = SET;
            break;
        
        case MENU_AIRCLEAN_TURBO :		// �ͺ� : Button LED ON
            TURBO_KEY_LED = SET;
            break;
            
        case MENU_AIRCLEAN_MANU :	    // ���� : Button LED ON
            WCAP_KEY_LED = SET;
            if(gBtnWCapLedOnOffCnt)
            {   // ��ư �Է½� ����
                if(TOGGL_500) WCAP_KEY_LED = CLR;
            }
            break;
            
        case MENU_AIRCLEAN_ROOM :       //AJH 160813 ROOM CARE
            ROOM_LED = SET;
        break;
        
        case MENU_AIRCLEAN_HUMI:    //�ڵ��������
            AUTO_HUMI_LED = SET;
        break;
    }
}

void Button_Lock_display(void)
{
    if(TOGGL_500)
    {
        if(TOUCH_LOCK_OPTION)
        {
            //ds1h  = L_LET;    //AJH 160809 "88SEG"���� 
            //ds10m = o_LET;
            //ds1m  = c_LET;
            ds1m  = L_LET;      //AJH 160809 "88SEG"���� 
        }
        else
        {
            //ds1h  = U_LET;    //AJH 160809 "88SEG"����
            //ds10m = L_LET;
            //ds1m  = __LET;
            ds10m = U_LET;      //AJH 160809 "88SEG"����
            ds1m  = L_LET;      //AJH 160809 "88SEG"����
            
        }
        LOCK_LED = SET;
    }
}


void Reservation_Time_display(void)
{
    unsigned char	i;
    
    
    if(Timer_Data > 0x9AB0)	{ i = 12;}
    else if(Timer_Data > 0x8CA0)	{ i = 11;}
    else if(Timer_Data > 32400)	{ i = 10;}
    else if(Timer_Data > 28800)	{ i = 9;}
    else if(Timer_Data > 25200)	{ i = 8;}
    else if(Timer_Data > 21600)	{ i = 7;}
    else if(Timer_Data > 18000)	{ i = 6;}
    else if(Timer_Data > 14400)	{ i = 5;}
    else if(Timer_Data > 10800)	{ i = 4;}
    else if(Timer_Data > 7200)	{ i = 3;}
    else if(Timer_Data > 3600)	{ i = 2;}
    else if(Timer_Data > 0)		{ i = 1;}
    else if(Timer_Data == 0)	{ i = 0;}

//AJH    ds1h  = BLANK;
    //  ds1m  = H_LET;              //AJH 160809 "88SEG"����
    if(Timer_Data)
    {
        ds10m = i/10;               //AJH 160809 "88SEG"����
        if(!ds10m) ds10m = BLANK;
        ds1m  = i%10;               //AJH 160809 "88SEG"����
    }
    else
    {
        ds1m = ds10m = dash_LET;    //AJH 160809 "88SEG"����
        
    }

    if(Timer_Data)
    {
        TIMER_KEY_LED = SET;
        YETAK_LED = SET;
    }
    if(reserve_display_time)
    {
        if(TOGGL_500)
        {
            if(Timer_Step)
            {   // ��� ������ ��������, �������� SEG OFF
                if( REPEAT_ON && MenuMode == MENU_AIRCLEAN_REPEAT && CH_MODEL_FLAG)
                {
                    TURN_OFF_TIME_LED = SET;    // ���� ����
                    TURN_ON_TIME_LED = SET;     // ���� ����
                }
                else
                {
                    if(POWER_ON) 
                        TURN_OFF_TIME_LED = SET;    // ���� ����
                    else
                        TURN_ON_TIME_LED = SET;     // ���� ����
                }
                YETAK_LED = SET;
            }
        }
        else
        {
            TIMER_KEY_LED      = CLR;   //���� ������ ���� ���� ��ư ���� ����
        }
       //TIMER_KEY_LED = SET;
    }
    else
    {
        if( REPEAT_ON && MenuMode == MENU_AIRCLEAN_REPEAT && CH_MODEL_FLAG)
        {
            TURN_OFF_TIME_LED = SET;    // ���� ����
            TURN_ON_TIME_LED = SET;     // ���� ����
        }
        else
        {
            if(POWER_ON) 
                TURN_OFF_TIME_LED = SET;    // ���� ����
            else
                TURN_ON_TIME_LED = SET;     // ���� ����
        }
        YETAK_LED = SET;
    }
    
    if(Timer_Step) // ��� ������ Hr, �ݺ� SEG OFF
    {
        HOUR_LED = SET;				//  'Hr'
        YETAK_LED = SET;	
        //if(AUTO_HUMI_LED == SET) AUTO_HUMI_LED = SET;
    }

}

// ���� �ʱ�ȭ ǥ��
void Filter_ChangeReset_display(void)
{
    //ds1h  = BLANK;    //AJH 160809 "88SEG"����
    ds10m = BLANK;
    ds1m  = 0;
    
    HOUR_LED = SET;
    FILTER_CHANGE_LED = SET;
}

void test_mode_display(void)
{
    if(gSelMotorStep)
    {
        if(gDisplaySecCnt)
        {   
            // �ӵ� ���� ���� �� 3�ʰ� ��ǥ RPM ���� ǥ��
            if(TOGGL_500) BldcTargetRpm_Display();
        }
        else
        {
            // 3�� ���� ���� RPM ǥ��
            BldcCurrentRpm_Display();
        }
    }
    else
    {
        if(TimerKeyInCnt == 1)
        {
            DustConcentration10_1hourAvgDisplay();  // TEST
        
        }
        else if(TimerKeyInCnt == 2)
        {
            DustConcentration2_5_1hourAvgDisplay(); // TEST
        }
        else
        {
            if(g1SecCnt <= 3)
            {
                DustConcentration2_5_Display();
                if(!g1SecCnt) g1SecCnt = 6;
            }
            else
            {
                //DustConcentration10_Display();
                DustConcentration2_5_1hourAvgDisplay(); // TEST
            }
        }
    }
    
    //Clock_display();
    //DustErrRatio_Display();
    
    // Button LED display
    ROOM_LED  = SET;
    FINE_DUST_LED    = SET;
    AUTO_LED         = SET; 
    DUST_DENSITY_LED = SET;
    //SOUND_LED        = SET;

    if(PowerKeyInCnt)   POWER_KEY_LED      = SET;
    //if(ModeKeyInCnt)    MODE_KEY_LED       = SET;
    if(WcapKeyInCnt%2)  WCAP_KEY_LED       = SET;
    if(TimerKeyInCnt%2) TIMER_KEY_LED      = SET;
    if(IonKeyInCnt)
    {
        ION_GEN_KEY_LED    = SET;
    }
    if(TURBO_ON)
    {
        TURBO_KEY_LED      = SET;
    }
    MoodDisplay(CleanLampKeyInCnt);
    
    if(CleanLampKeyInCnt)  
    {
        CLEAN_LAMP_KEY_LED = SET;
    }
}

volatile unsigned char led_test_cnt;
void Led_TEST_ONLY(void)
{
    switch(led_test_cnt++)
    {
        case 0:
            SOUND_LED  = SET;
            break;
        case 1:
            AUTO_HUMI_LED = SET;
            break;
        case 2:
            POWER_SAVE_LED = SET;
            break;
        case 3:
            FINE_DUST_LED  = SET;
            break;
        case 4:
            STEP_LED       = SET;
            break;
        case 5:
            DUST_DENSITY_LED = SET;
            break;
        case 6:
            HOUR_LED         = SET;
            break;
        case 7:
            MINUTE_LED       = SET;
            break;
        case 8:
            YELLOW_DUST_LED  = SET;
            break;
        case 9:
            BABY_LED         = SET;
            break;
        case 10:
            BED_TIME_LED     = SET;
            break;
        case 11:
            ROOM_LED   = SET;
            break;
        case 12:
            LOCK_LED         = SET;
            break;
        case 13:
            FILTER_CHANGE_LED = SET;
            break;
        case 14:
            TURN_OFF_TIME_LED = SET;
            break;
        case 15:
            TURN_ON_TIME_LED  = SET;
            break;
        case 16:
            AUTO_LED          = SET;
            break;
        default: 
            led_test_cnt = 0;
            break;
    }
}

