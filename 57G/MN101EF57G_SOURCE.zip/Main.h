/******************************************************************************
**
**  COPYRIGHT (C)
**
**  THIS WORK CONTAINS TRADE SECRET AND PROPRIETARY INFORMATION WHICH IS
**  THE PROPERTY OF CUCKOO
**
**  PROJECT NAME:   
**
**  FILENAME:       .c
**
**  PURPOSE:        
**
**  FUNCTIONS:      
**
**  AUTHOR:
**
**  VERSION:        1.0
**
**  LAST MODIFIED:  
******************************************************************************/
/*****************************************************************************
Note:
*******************************************************************************/

#ifdef  ROOT
#define EXT_SCH
#else
#define EXT_SCH extern
#endif

// **************************************************************
//     0 = E/S
//     1 = PILOT
//     2 = P/P  
//     3 = M/P
#define MODEL            1
#define EVENT_VERSION    P_LET//H_LET  //2�� PILOT
#define VOICE_STOP_CODE  0x2 // ��û�� ����

#define VERSION          1   //1 pilot 161003 

// **********************************************
// *************** OPTION ******************
// **********************************************
#define SKIP_EUF_ERR                // EUF ���� SKIP
//#define SKIP_ENERGY_EYE           // Energy Eye ���� SKIP ��
//#define BLDC_RPM_TEST
//#define BLDC_RPM_DISPLAY            // ��û ������ ���� RPM DISPLAY   + ���༳�� ��ư���� 10 RPM �� �̼�����
//#define TEST_OPT_NO_ERROR           // ���� ó�� ���� ����
//#define TEST_DUST_SENSOR_TUNE       // ���� ��û ���� ���, �������� �������� ǥ��
//#define TEST_HELP_MODE_JIG          // ���� �ΰ��� �ڵ� HELP MODE display ����
//#define TEST_DISPLAY_FULL_ON_JIG    // ���� �ΰ��� ��� DISPLAY ON
//#define TEST_DISPLAY_RADIATION      // ���� ������ DISPLAY ������Ʈ ���� TEST ��
//#define TEST_CDS_CONFIG             // CDS JIG ������ TEST: �̼������󵵹�ư �Է½� ���� û���� ǥ�� ��ư ����
//#define TEST_VOICE_PALY               // ����͸� ��忡�� �������ð� �ٶ����� ��ư���� ���� Ȯ�� ��ɼ���  
//#define TEST_DUST_INFO_SAVE           // ���� ���� ���� (1�ð� �з�)
//#define TEST_GAS_INFO_SAVE           // ���� ���� ���� (1�ð� �з�)
//#define TEST_DISPLAY_RSSI               // ���۽� RSSI �� ǥ��
//#define TEST_CODE_SIZE_OPTIMIZE           // IOT TEST ���� code size ����: ������, ���� ���ذ��� ���� ���� 
//#define TEST_UART_115200                // UART 115200 ���� 38400 ���� ���ߴ� ���� ����
//#define TEST_CH_MODEL_OPT               // ������ �����𵨷� ����
// **********************************************
// *************** PORT DEFINE ******************
// **********************************************

// ****** A/D PORT Define **********
//#define ION_CHECK_AD               0         // AIN0
//#define HUMIDITY_AD                1         // AIN1
//#define HU_THERMAL_AD              3         // AIN3 
//#define IFD_CHECK_AD               4         // AIN4

//#define CDS_AD                    14    //AN14
//#define HUMIDITY_AD               2     // AN2
//#define HU_TH_AD                  0     // AN0
//#define GAS_SENSOR_AD             10    // AN10
//CODELESS
#define CDS_AD                    15    //AN15
#define HUMIDITY_AD               12    //AN12
#define HU_TH_AD                  13    //AN12
#define GAS_SENSOR_AD             14    //AN14
#define BATTERY_GAUGING_AD		  11    //AN11


// ************** PORT DEFINE ***********************
// Eeprom (B1010 Toshiba)
//#define EEPROM_SDA_OUT             ((*(RB_BTF*)&P8OUT).p3)  //P83 OUT   // eeprom data out
//#define EEPROM_SDA_IN              ((*(RB_BTF*)&P8IN).p3)   //P83 IN    // eeprom data in
//#define EEPROM_SCL                 ((*(RB_BTF*)&P8OUT).p2)  //P82       // eeprom clock

//CODELESS
#define EEPROM_SDA_OUT             ((*(RB_BTF*)&P5OUT).p7)  //P57 OUT   // eeprom data out
#define EEPROM_SDA_IN              ((*(RB_BTF*)&P5IN).p7)   //P57 IN    // eeprom data in
#define EEPROM_SCL                 ((*(RB_BTF*)&P5OUT).p6)  //P56       // eeprom clock


// ES3 ���� ����
// Display Module (B1010 Toshiba)
//#define DISPLAY_MODULE_DATA        ((*(RB_BTF*)&P5OUT).p5)	//P55  // display control data
//#define DISPLAY_MODULE_CLOCK       ((*(RB_BTF*)&P5OUT).p4)  //P54  // display control clock
//#define DISPLAY_MODULE_CS          ((*(RB_BTF*)&P5OUT).p3)  //P53  // display control chip select

//CODELESS
#define DISPLAY_MODULE_DATA        ((*(RB_BTF*)&P6OUT).p6)	//P66  // display control data
#define DISPLAY_MODULE_CLOCK       ((*(RB_BTF*)&P6OUT).p5)  //P65  // display control clock
#define DISPLAY_MODULE_CS          ((*(RB_BTF*)&P6OUT).p3)  //P63  // display control chip select


//#define MOOD_LED_RED               ((*(RB_BTF*)&P5OUT).p6)	//P56  // û���� RED
//#define MOOD_LED_GREEN             ((*(RB_BTF*)&P5OUT).p7) 	//P57  // û���� GREEN
//#define MOOD_LED_BLUE              ((*(RB_BTF*)&P4OUT).p7) 	//P47  // û���� BLUE

//#define MOOD_LED_RED                ((*(RB_BTF*)&P4OUT).p7) 	//P47  // û���� RED
//#define MOOD_LED_GREEN              ((*(RB_BTF*)&P5OUT).p6)     //P56   // û���� GREEN
//#define MOOD_LED_BLUE               ((*(RB_BTF*)&P5OUT).p7) 	//P57 // û���� BLUE

//CODELESS
#define MOOD_LED_GREEN                 ((*(RB_BTF*)&P6OUT).p7) 	//P67  // û���� RED//MOOD_LED_RED 
#define MOOD_LED_BLUE             ((*(RB_BTF*)&P7OUT).p0)     //P70   // û���� GREEN//MOOD_LED_GREEN
#define MOOD_LED_RED               ((*(RB_BTF*)&P7OUT).p1) 	//P71 // û���� BLUE//MOOD_LED_BLUE


// Voice (pana 57G)
//#define VOICE_RESET_PORT           ((*(RB_BTF*)&P2OUT).p4) //P24 // voice reset
//#define VOICE_MISO_PORT            ((*(RB_BTF*)&P8IN).p7)  //P87 // voice data in
//#define VOICE_MOSI_PORT            ((*(RB_BTF*)&P8OUT).p6) //P86 // voice data out
//#define VOICE_SCLK_PORT            ((*(RB_BTF*)&P8OUT).p4) //P84 // voice clock
//#define VOICE_SSB_PORT             ((*(RB_BTF*)&P8OUT).p5) //P85 // voice chip select

//CODELESS
#define VOICE_RESET_PORT           ((*(RB_BTF*)&P4OUT).p5) //P45 // voice reset
#define VOICE_MISO_PORT            ((*(RB_BTF*)&P4IN).p4)  //P44 // voice data in
#define VOICE_MOSI_PORT            ((*(RB_BTF*)&P4OUT).p3) //P43 // voice data out
#define VOICE_SCLK_PORT            ((*(RB_BTF*)&P3OUT).p5) //P35 // voice clock
#define VOICE_SSB_PORT             ((*(RB_BTF*)&P3OUT).p4) //P34 // voice chip select


// Option (pana 57G)
//#define OPTION1_PORT               ((*(RB_BTF*)&P7IN).p6) //P76 // option 1
//#define OPTION2_PORT               ((*(RB_BTF*)&P7IN).p7) //P77 // option 2
//#define OPTION3_PORT               ((*(RB_BTF*)&P8IN).p0) //P80 //OPTIION

//CODELESS
#define OPTION1_PORT               ((*(RB_BTF*)&P4IN).p7) //P47 // option 1
#define OPTION2_PORT               ((*(RB_BTF*)&P4IN).p6) //P77 // option 2
//#define OPTION3_PORT               ((*(RB_BTF*)&P8IN).p0) //P80 //OPTIION


// BLDC (pana 57G)
//#define BLDC_PG                    ((*(RB_BTF*)&P2IN).p1)  //P21 // BLDC RPM ����
//#define BLDC_VCC_ENABLE            ((*(RB_BTF*)&P2OUT).p2) //P22 // BLDC ���� IC
//#define BLDC_PWM                   ((*(RB_BTF*)&P0OUT).p3) //P03 // BLDC �ӵ� ����

//CODELESS
#define BLDC_PG                    ((*(RB_BTF*)&P2IN).p1)  //P21 // BLDC RPM ����
//#define BLDC_VCC_ENABLE            ((*(RB_BTF*)&P2OUT).p2) //P22 // BLDC ���� IC
#define BLDC_PWM                   ((*(RB_BTF*)&P0OUT).p3) //P03 // BLDC �ӵ� ����


// KEY (pana 57G)
//#define POWER_KEY_IN               ((*(RB_BTF*)&P4IN).p6) //P46    // ����/����
//#define MODE_KEY_IN                ((*(RB_BTF*)&P4IN).p5) //P45    // ���� ����
//#define WCAP_KEY_IN                ((*(RB_BTF*)&P4IN).p4) //P44    // �ٶ� ����
//#define TIMER_KEY_IN               ((*(RB_BTF*)&P4IN).p3) //P43    // ���༳��
//#define ION_GEN_KEY_IN             ((*(RB_BTF*)&P3IN).p5) //P35    // ��������
//#define TURBO_KEY_IN               ((*(RB_BTF*)&P3IN).p4) //P34    // �ͺ�����
//#define CLEAN_LAMP_KEY_IN          ((*(RB_BTF*)&P3IN).p3) //P33    // û��ǥ��

//CODELESS
#define POWER_KEY_IN               ((*(RB_BTF*)&P7IN).p2) //P72    // ����/����
#define MODE_KEY_IN                ((*(RB_BTF*)&P7IN).p3) //P73    // ���� ����
#define WCAP_KEY_IN                ((*(RB_BTF*)&P7IN).p4) //P74    // �ٶ� ����
#define TIMER_KEY_IN               ((*(RB_BTF*)&P7IN).p5) //P75    // ���༳��
#define ION_GEN_KEY_IN             ((*(RB_BTF*)&P7IN).p6) //P76    // ��������
#define TURBO_KEY_IN               ((*(RB_BTF*)&P7IN).p7) //P77    // �ͺ�����
#define CLEAN_LAMP_KEY_IN          ((*(RB_BTF*)&P8IN).p0) //P80    // û��ǥ��


// DUST SENSOR (B1010 Toshiba) : �ſ��� ����
//#define DUST_SENSOR_PM10_IN        ((*(RB_BTF*)&P0IN).p2) //P02    // �������� PM10 �Է� 
//#define DUST_SENSOR_PM2_5_IN       ((*(RB_BTF*)&P0IN).p4) //P04    // �������� PM2.5 �Է� 
//#define DUST_SENSOR_ENABLE         ((*(RB_BTF*)&P0OUT).p5) //P76      //OK    //P80      // ���� ����

//CODELESS
#define DUST_SENSOR_PM10_IN        ((*(RB_BTF*)&P0IN).p2) //P02    // �������� PM10 �Է� 
#define DUST_SENSOR_PM2_5_IN       ((*(RB_BTF*)&P2IN).p0) //P20    // �������� PM2.5 �Է� 
#define DUST_SENSOR_ENABLE         ((*(RB_BTF*)&P0OUT).p7) //P07      //OK    //P80      // ���� ����


// DUST SENSOR (B1010 Toshiba) : ��������
//#define DUST_SHARP_SENSOR_ENABLE   P72      // ���� ����

// GAS SENSOR (B1010 Toshiba)
//#define GAS_SENSOR_ENABLE           ((*(RB_BTF*)&PBOUT).p3) //P71     //OK      // HIGH: Enable, LOW: Disable
//CODELESS
#define GAS_SENSOR_ENABLE           ((*(RB_BTF*)&P8OUT).p1) //P81     //OK      // HIGH: Enable, LOW: Disable


// CDS (B1010 Toshiba)

// ION GEN (B1010 Toshiba)         
//#define ION_GEN_CTRL                ((*(RB_BTF*)&P6OUT).p3) //P11     //OK    //PB3     // CPI ON/OFF ���ձ�E
//#define ION_GEN_PWR                 PB4     // CPI ON/OFF ���ձ� 
//#define ION_GEN_CHECK               P40PRD  //[P54] ION GENERATOR (new)

//CODELESS
#define ION_GEN_CTRL                ((*(RB_BTF*)&P5OUT).p5) //P55     //OK    //PB3     // CPI ON/OFF ���ձ�E


                                   
// Humidity Sensor                 
//#define HUMIDITY_PWM1_OUT           P42     // �������� PWM ��� PORT 1KHZ PWM
//#define HUMIDITY_PWM2_OUT           P25     // �������� PWM2 ��� PORT 1KHZ PWM
           
// MOOD LED TEST
//#define MOOD_LED_GREEN_OUT          P41       // 


// REED SWITCH (B1010 Toshiba)     
//#define REED_SWITCH_WDOOR           ((*(RB_BTF*)&P0IN).p6) //P80PRD     //
//#define REED_SWITCH_TANK            ((*(RB_BTF*)&P2IN).p0) //P83PRD     //ok
//#define REED_SWITCH_FLOAT           ((*(RB_BTF*)&P0IN).p7) //P82PRD     //ok
//#define REED_SWITCH_TANK_COVER      P90PRD     //ok 

//CODELESS
#define REED_SWITCH_WDOOR           ((*(RB_BTF*)&P0IN).p6) //P06    //P80PRD     //
#define REED_SWITCH_TANK            ((*(RB_BTF*)&P0IN).p4) //P04    //P83PRD     //ok
#define REED_SWITCH_FLOAT           ((*(RB_BTF*)&P0IN).p5) //P05    //P82PRD     //ok

                                   
//  UV LED 
//#define UV_LED_ON                  ((*(RB_BTF*)&P6OUT).p5) //P13  //UV LED ON/OFF
// BUZZER CONTROL

// ��������
//#define HU_PWM1_PORT               ((*(RB_BTF*)&PAOUT).p3) //PA3
//#define HU_PWM2_PORT               ((*(RB_BTF*)&PAOUT).p1) //PA1
//#define HU_PWM1_PORT               ((*(RB_BTF*)&PAOUT).p1) //PA1
//#define HU_PWM2_PORT               ((*(RB_BTF*)&PAOUT).p3) //PA3
//CODELESS
#define HU_PWM1_PORT               ((*(RB_BTF*)&P2OUT).p2) //P22
#define HU_PWM2_PORT               ((*(RB_BTF*)&P2OUT).p3) //P23

// Battery state 
//#define PG							P43PRD 
#define Battery_STAT2				((*(RB_BTF*)&PBIN).p2) //PB2 
#define Battery_STAT1				((*(RB_BTF*)&PBIN).p1) //PB1   
// stat1 : 1, stat2 : 0 => Charge in progress
// stat1 : 0, stat2 : 1 => Charge complete
// stat1 : 0, stat2 : 0 => Charge suspend, timer fault, overvoltage, sleep mode, battery absent
//IDLE mode ADH_2016_0613
#define STAND_BY_POWER              ((*(RB_BTF*)&PBOUT).p0) //PB0
//#define STANDBY_8V					P42
//#define CE_40210						P50


// IFD �������� (B1010 Toshiba)    
                                   
// STEP MOTOR                      

// ************* seg letter display *****************
#define   A_LET     10
#define   b_LET     11
#define   C_LET     12
#define   d_LET     13
#define   e_LET     14
#define   F_LET     15
#define   g_LET     16
#define   H_LET     17
#define   i_LET     18
#define   S_LET     19
#define   t_LET     20
#define   o_LET     21
#define   P_LET     22
#define   n_LET     23
#define   O_LET     24
#define   L_LET     25
#define   u_LET     26
#define   U_LET     27
#define   N_LET     28
#define   BLANK     29
#define   E_LET     30
#define   r_LET     31
#define   dash_LET  32
#define   y_LET     33
#define   HALF_I_LET 34 // M01: ���� Puri ǥ�� ����
#define   l_LET      35 // M01: �ü� COLd -> Cold ���� ����
#define   __LET      36
#define   c_LET      37
#define   SEG_FONT_Door   38
#define   k_LET      39
#define   SEG_FONT_OvenRight  40 //"_|"
#define   SEG_FONT_Room       41 //""
#define   MINUS_LET            42

// Button (B1010 Toshiba)
#define POWER_KEY              1    // ����
#define MODE_KEY               5    // ���
#define WCAP_KEY               4    // ǳ��
#define TIMER_KEY              3    // Ÿ�̸�/����
#define ION_GEN_KEY            2    // ����
#define TURBO_KEY              6
#define CLEAN_LAMP_KEY         7
#define TIMER_TURBO_KEY        9    // Ÿ�̸�+�ͺ� double KEY 
#define ION_CLEAN_KEY          10 
#define ION_TURBO_KEY		   8	// CODELESS ���� + �ͺ� double KEY


// LONG_KEY
#define LOCK_KEY               TIMER_KEY
#define USR_SVC_KEY            MODE_KEY
#define FILTER_RESET_KEY       CLEAN_LAMP_KEY 


// ******************************************************************************************
// ORG
#define COMMAND_GRID_SEG      0x03 //0x01      // 0000 0000
//     bit0,bit1 = 5grid/12seg
//     bit2 ~ bit5 = don't care
//     bit6,bit7 = command 1

// TEST ONLY
#define COMMAND_GRID_SEG_DECO   0x03      // 0000 0011
//     bit0,bit1 = 7grid/11seg
//     bit2 ~ bit5 = don't care
//     bit6,bit7 = command 1


#define COMMAND_AUTO_ADDRESS  0x40      // 0100 0000
//     bit0,bit1 = write data display
//     bit2 = address �ڵ�����
//     bit3 = normal operation mode
//     bit4,bit5 = don't care
//     bit6,bit7 = command 2

#define COMMAND_ADDRESS       0xC0      // 1100 0000
//     bit0~bit4 = display buffer address
//     bit4,bit5 = don't care
//     bit6,bit7 = command 3

//#define COMMAND_ON_KANG       0x8F      // 1000 1111
//#define COMMAND_ON_MID        0x8B      // 1000 1011
//#define COMMAND_ON_MID_YAK    0x8A      // 1000 1010
//#define COMMAND_ON_YAK        0x88      // 1000 1000
// TK18 CHIP ����� LED DIMMING VALUE
#define COMMAND_ON_KANG       10      // 1000 1111
#define COMMAND_ON_MID        7      // 1000 1011
#define COMMAND_ON_YAK        3      // 1000 1000

//     bit0,bit1,bit2 = �ҹ��� ����(duty)
//     bit3 = display on/off
//     bit4,bit5 = don't care
//     bit6,bit7 = command 4

#define COMMAND_OFF        0x87      // 1000 0111

#define MAX_FND_BUF_CNT    14

EXT_SCH unsigned char cds_help_data;
EXT_SCH unsigned char air_pump_drive_time;
EXT_SCH unsigned char model_option;
EXT_SCH unsigned char dsp_addr;

#define POWER_OFF_DISP          0
#define DAGI_MODE_DSP           1
#define SETTING_MODE_DSP        4
#define HELP_MODE_DSP           6
#define FLASH_ROM_CHK_DSP       9
#define TEST_MODE_DISP          10
#define HUMI_BOJUNG_MODE_DISP   11

//-----------------------------------------------
//      ����� �ɼ� EEPROM Address : eeprom_addr_w
//-----------------------------------------------
#define  SET1_DATA_ADDR             0
#define  SET2_DATA_ADDR             1
#define  HELP_MODE_ADDR             2
#define  USR_MENU_ADDR              3
#define  USR_LANG_ADDR              4
#define  USR_FLASH_ADDR             5
#define  USR_ION_GEN_ADDR           6
#define  USR_CDS_OPT_ADDR		    7
#define  USR_VOLUME_ADDR		    8
#define  USR_FILTER_WORKL_ADDR      9
#define  USR_FILTER_WORKH_ADDR      10
#define  USR_FILTER_SWITCH_ADDR     11
#define  USR_CLEAN_DISPLAY_ADDR     12
#define  USR_FNDDIMMING_ADDR        13
#define  USR_VOICE_ADDR             14
#define  USR_SENSIBILITY_ADDR       15
#define  USR_TURBO_ADDR             16
#define  USR_MOOD_ONF_ADDR          17
#define  USR_MOTOR_STEP_ADDR        18
#define  USR_REPEAT_TIME_ADDR       19
#define  USR_POWER_ON_ADDR          20
#define  USR_BLDC_CONFIG_INFO       21
#define  USR_ROOMCARE_ADDR          22
#define  MAX_USR_ADDR               23
// �ʱ�ȭ �ȵǴ� EEPROM ����
#define  USR_HUMI_BOJUNG_ADDR       30
#define  HUMI_PLUS_ADDR             31
#define  HUMI_MINUS_ADDR            32
#define  MAX_USR_ADDR2              33

// �� Code �� �ִ� 128 ������ ���� : code ���� �ʿ�
#define  EEPROM_AP_NAME_ADDR        50
#define  EEPROM_AP_NAME_SIZE        20
#define  EEPROM_AP_PASSWORD_ADDR    (EEPROM_AP_NAME_ADDR+EEPROM_AP_NAME_SIZE) // 70
#define  EEPROM_AP_PASSWORD_SIZE    20  
#define  EEPROM_DEVICE_ID_ADDR      (EEPROM_AP_PASSWORD_ADDR+EEPROM_AP_PASSWORD_SIZE) //90
#define  EEPROM_DEVICE_ID_SIZE      20 
#define  EEPROM_WIFI_INFO_SIZE      (EEPROM_AP_NAME_SIZE+EEPROM_AP_PASSWORD_SIZE+EEPROM_DEVICE_ID_SIZE) //60
#define  AT_COMMAND_SIZE            50

// �� I2C Logic ���� �ִ� 128 ������ ASSCES ����
#define  EEPROM_TEST_ADDR           127  // HELP MODE ���� EEPROM TEST 

#define  EEPROM_TEST_CODE           0x5A // 0101 1010 b => TEST ADDR �� TEST CODE �� ���� �� �� �о EEPROM ���Ἲ Ȯ��

#define  DEFAULT_VOICE_VOLUME        3
#define  MAX_VOICE_VOLUME            5
#define  LANG_SEL_KOREAN             1  // �ѱ���
#define  LANG_SEL_CHINESE            2  // �߱���
#define  LANG_ADDR_CHINESE_OFFSET    0x200

#define  POWER_STATUS_INIT_MODE      0  // �ʱ� ���
#define  POWER_STATUS_NORMAL_MODE    1  // ���� ���
#define  POWER_STATUS_AGING_MODE     2  // AGING ���
#define	 POWER_STATUS_PSTOP_MODE	 3	// ���� ��� CODELESS 

//-----------------------------------------------
//      ����� �ɼ� ���� : gUserSvcModeADJ
//-----------------------------------------------
#define  USRMENU_ADJ		    3
#define  USRWATER_ADJ		    4
#define  USRFLASH_ADJ		    5
#define  USRIONGEN_ADJ		    6
#define  USRCDSOPT_ADJ		    7
#define  USRVOLUME_ADJ		    8
#define  USRFILWORK_L_ADJ	    9
#define  USRFILWORK_H_ADJ	    10
#define  USRFILSWITCH_ADJ	    11
#define  USRCLEANDISPLAY_ADJ	12
#define  USRFNDDIMMING_ADJ	    13
#define  USRLANG_ADJ		    14
#define  USRSENSIBILITY_ADJ	    15
#define  USRTURBO_ADJ		    16
#define  ROOMCARE_ADJ		    17

// BEEP ADDRESS: VOICE OFF �� BEEP ��ü��
#define BEEP_ADDR_BUTTON             0xD3    //(��ư Ŭ���� (��ư ������))
#define BEEP_ADDR_T1                 0xD4    //(�Ѳ������� ������)
#define BEEP_ADDR_T2                 0xD5    //(�Ѳ������� ������)
#define BEEP_ADDR_T3                 0xD6    //(��� , �簡�� �Ϸ���)
#define BEEP_ADDR_INFO               0xD7    //(������ (���� �˾� ��))
#define BEEP_ADDR_WARNING            0xD8    //(����� (��� �˾� ��))
#define BEEP_ADDR_ERROR              0xD9    //(������ (���� �˾� ��))
#define BEEP_ADDR_INIT               0xDA    //(�ʱ� ���� �ΰ��� (���� �ΰ���, Reset �߻���))
#define NONE_BEEP                    0       // VOICE OFF BEEP �ƹ� �Ҹ� �ȳ�   

//EXT_SCH unsigned int  voice_safety_time;
EXT_SCH unsigned char voice_adj_volume;        //�������� ������� �����߰�
EXT_SCH unsigned char ucVoice_volume_max;   //CODELESS

EXT_SCH unsigned char voiceNumber;
EXT_SCH unsigned char voice_drv_timer;
EXT_SCH unsigned char voice_drv_state;
EXT_SCH unsigned char voice_10ms_timer;
EXT_SCH unsigned int  voiceAddr_buf[8];
EXT_SCH unsigned char voicePause_buf[8];
EXT_SCH unsigned int  voicePlayTestAddr;
EXT_SCH unsigned char gVoicePlaySkipCnt;    // �����ΰ��� ��ħ ���Ʒ� ���۽� ù���� �����ȳ� skip flag
EXT_SCH unsigned char gVoicePlayWaterLackSkipCnt;    // �����ΰ��� ��ħ/���Ʒ� ���۽� ������ ���� ���� ù���� �����ȳ� skip flag
EXT_SCH unsigned char gVoicePlayWaterLackSkipCnt2;    // �����ΰ��� �ʱ�����(����Ʈ ~~~~) ����� ������ ù��°���� skip flag
EXT_SCH unsigned char gVoicePlayWaterLackSkipCnt3;    // �����ΰ��� �ʱ�����(����Ʈ ~~~~) ����� ������ ù��°���� skip flag


EXT_SCH unsigned int  voice_check_addr;
EXT_SCH unsigned char continue_time;
EXT_SCH unsigned char delay_2sec;
EXT_SCH unsigned char scroll_time;

EXT_SCH unsigned int  tempf;
EXT_SCH unsigned char key_flag;
EXT_SCH unsigned char key_bfr;
EXT_SCH unsigned int  long_key_cnt;
EXT_SCH unsigned char temp_key;
EXT_SCH unsigned char key_cnt;
EXT_SCH unsigned char key_chr;
EXT_SCH unsigned char gUserSvcSelFlag;   // ����� ���� ��� ���� Flag

EXT_SCH unsigned char PowerKeyInCnt;
EXT_SCH unsigned char WcapKeyInCnt;
EXT_SCH unsigned char TimerKeyInCnt;
EXT_SCH unsigned char IonKeyInCnt;
EXT_SCH unsigned char TurboKeyInCnt;
EXT_SCH unsigned char CleanLampKeyInCnt;


EXT_SCH unsigned char timer_count;
EXT_SCH unsigned char option_check_count;

EXT_SCH unsigned char micom_data;
EXT_SCH unsigned char eeprom_data;
EXT_SCH unsigned char eeprom_write;

EXT_SCH unsigned char cds_time_count;
EXT_SCH unsigned char cds_off_time_count;
EXT_SCH unsigned char cds_on_time;
EXT_SCH unsigned char cds_off_time;
EXT_SCH unsigned char mood_in_data;
EXT_SCH unsigned char mood_out_data;
EXT_SCH unsigned int  mood_clear_time;

EXT_SCH unsigned char eeprom_write_end_step;
EXT_SCH unsigned char eeprom_write_step;
EXT_SCH unsigned char eeprom_read_step;
EXT_SCH unsigned char eeprom_error_cnt;

EXT_SCH unsigned char eeprom_read_cnt;
EXT_SCH unsigned char eeprom_drive_cnt;
EXT_SCH unsigned char eeprom_writing;
EXT_SCH unsigned char eeprom_drive_step;

EXT_SCH unsigned char led_display[MAX_FND_BUF_CNT];
EXT_SCH unsigned char led_buffer[MAX_FND_BUF_CNT];

EXT_SCH unsigned char mood_led_display[MAX_FND_BUF_CNT];
EXT_SCH unsigned char mood_led_buffer[MAX_FND_BUF_CNT];

EXT_SCH unsigned char eeprom_addr_r[MAX_USR_ADDR2+1];
EXT_SCH unsigned char eeprom_addr_w[MAX_USR_ADDR2+1];


/*
CC	������~
CD	��~��~
CE	����¡�� [�����ϼ���~]
CF	���ٱ�Ҹ�(cuck-1) + ���Ҹ����(ce-22-1,2,3)
D0	(���ȿ����)
D1	(���ȿ����)

*/
//EXT_SCH volatile unsigned char delay_comp_onf_time;
//EXT_SCH volatile unsigned char delay_heater_onf_time;
EXT_SCH volatile unsigned char aging_count;
EXT_SCH volatile unsigned char delay_standby;

EXT_SCH volatile unsigned long check_sum;
EXT_SCH volatile unsigned long flash_rom;
EXT_SCH volatile unsigned char check_sum_data;
EXT_SCH volatile unsigned char *check_start_addr;
EXT_SCH volatile unsigned char check_sum_error;
EXT_SCH volatile unsigned char check_sum_step;
EXT_SCH volatile unsigned char check_sum_cnt;

EXT_SCH volatile unsigned char dsp1;
EXT_SCH volatile unsigned char dsp2;
EXT_SCH volatile unsigned char dsp3;
EXT_SCH volatile unsigned char dsp4;
EXT_SCH volatile unsigned char dsp5;
EXT_SCH volatile unsigned char dsp6;
EXT_SCH volatile unsigned char dsp7;
EXT_SCH volatile unsigned char dsp8;

EXT_SCH volatile unsigned char ext_count;
EXT_SCH volatile unsigned char fosc_count;
EXT_SCH volatile unsigned char external_count;
EXT_SCH volatile unsigned int  hz_count;
EXT_SCH volatile unsigned char gFoscOutCnt;
EXT_SCH volatile unsigned char gFoscDisplayOffDelayCnt;
EXT_SCH volatile unsigned char gFoscKeyInOffDelayCnt; // Fosc �Է½� ��ư �Է� ���� ���� (�����Ϸ�)

//EXT_SCH volatile unsigned char help_mode_in_step;
//#define STEP1_COCK_SALGYUN_KEY     1
//#define STEP2_JELJEON_KEY          2
//#define STEP3_SALGYUN_KEY          3
//#define STEP4_COCK_SALGYUN_KEY     4

EXT_SCH volatile unsigned char help_delay_count;
EXT_SCH volatile unsigned char touch_lock_display_time;
EXT_SCH volatile unsigned char reserve_display_time;
EXT_SCH volatile unsigned char ButtonData;
EXT_SCH volatile unsigned char ButtonDataOld;

EXT_SCH volatile unsigned char save_delay_cnt;
EXT_SCH volatile unsigned char save_on_cnt;
EXT_SCH volatile unsigned char save_off_cnt;
EXT_SCH volatile unsigned char save_blink_cnt;
EXT_SCH volatile unsigned char save_error_cnt;
EXT_SCH volatile unsigned char write_data;
EXT_SCH volatile unsigned char mood_write_data;
EXT_SCH volatile unsigned char display_dtep;
EXT_SCH volatile unsigned char display_flag;
EXT_SCH volatile unsigned char data_out_count;
EXT_SCH volatile unsigned char mood_display_step;
EXT_SCH volatile unsigned char mood_display_flag;
EXT_SCH volatile unsigned char mood_data_out_count;
EXT_SCH volatile unsigned char address_count;
EXT_SCH volatile unsigned char clock_flag;
EXT_SCH volatile unsigned char mood_clock_flag;
EXT_SCH volatile unsigned char dsp_update_flag;
EXT_SCH volatile unsigned char help_mode_count;

#define EEPROM_CLEAR    1
#define ERROR_DISPLAY   2
#define HEATER_CHECK    3
#define COMP_CHECK      4

EXT_SCH volatile unsigned char   load_on_step;
EXT_SCH volatile unsigned char   delay_cnt;
EXT_SCH volatile unsigned char   dsp_100mS_cnt;
EXT_SCH volatile unsigned char   dsp_500mS_cnt;
EXT_SCH volatile unsigned int    dsp_1S_cnt;
EXT_SCH volatile unsigned int 	 time_1S_cnt;         //AJH 160604

EXT_SCH volatile unsigned char   tempf8;
EXT_SCH volatile unsigned char   save_tempf8;
EXT_SCH volatile unsigned char   freequency_data;
EXT_SCH volatile unsigned char   load_count;
EXT_SCH volatile unsigned char   dsp_on_flag;
EXT_SCH volatile unsigned char   help_option_step;
EXT_SCH volatile unsigned char   help_option_mode_cnt;  // ���� ���� ���� ȸ��
EXT_SCH volatile unsigned char   help_option_cpi_cnt;   // ���չ�ư ���� Ƚ��
EXT_SCH volatile unsigned char   help_cpi_display_cnt;  // ���չ�ư ǥ�� count
EXT_SCH volatile unsigned char   help_option_wcap_cnt;  // �ٶ����� ���� Ƚ��
EXT_SCH volatile unsigned char   help_option_dust_cnt;  // �̼������� ���� Ƚ��
EXT_SCH volatile unsigned char   help_option_eeprom_test_result;  // �̼������� ���� Ƚ��
EXT_SCH volatile unsigned char   help_delay_time;                 // help mode ���� display delay time
// TO_DO_LIST: update ���
#define VOICE_DSP             1
#define VERSION_DSP           2
#define FILTER_DOOR_DSP       3
#define MODEL_DSP             4 //AJH 160831
#define WATER_DOOR_LACK_DSP   5 //AJH 160831
#define FREEQUENCY_CHECK      6
#define HUMI_CHECK_DSP        7 //AJH 160831
#define HUMI_THERMAL_CHECK    8
#define BLDC_RPM_CHECK        9
#define CDS_CHECK             10
#define CPI_AD_CHECK          11
#define GAS_AD_CHECK          12
#define DUST_AD_CHECK         13
#define DSP_CHECK             14
#define EEPROM_CHECK          15
#define HUMI_BOJUNG_DSP       16


EXT_SCH volatile unsigned char monitoring_step;
EXT_SCH volatile unsigned char gBldc_change_delay_time;           // monitoring mode ����, �������ý� bldc ���� delay time
// TO_DO_LIST: update ���
#define MONITOR_BLDC_RPM        1
#define MONITOR_DUST_SENSOR     2
#define MONITOR_PM_2_5          3
#define MONITOR_GAS_RATIO       4
#define MONITOR_GAS_SENSOR_VAL  5
#define MONITOR_CDS_VALUE       6
#define MONITOR_FILTER_TIME     7
#define MONITOR_HUMI_DEC        8
#define MONITOR_THER_HEX        9


#define COLD_TEMP_DSP            1
#define HOT_TEMP_DSP             2
//#define SALGYUN_KIT_DSP          3
#define CDS_DSP              4
#define SALGYUN_PROCESS_DSP        5
#define COCK_SALGYUN_PROCESS_DSP   6

EXT_SCH volatile unsigned char   set_timer;
EXT_SCH volatile unsigned char   dsp_run_step;
EXT_SCH volatile unsigned char   work_data;
EXT_SCH volatile unsigned char   error_count;
EXT_SCH volatile unsigned char   error_kind;
/*
#define  EUF_NG                    _set_error_flag.bit.b0   // Checksum Error
#define  GAS_SENSOR_NG             _set_error_flag.bit.b1   // Gas sensor error: Aging �ÿ��� ���� �߻�
#define  DUST_SENSOR_NG            _set_error_flag.bit.b2   // Dust sensor error: Aging �ÿ��� ���� �߻�
#define  CPI_NG                    _set_error_flag.bit.b3   // CPI ���� ����
#define  FILTER_DOOR_NG            _set_error_flag.bit.b4   // ���� Door�� 3�� �̻� �и��� ���
#define  MOTOR_NG                  _set_error_flag.bit.b5   // MOTOR ���� ����
*/
// TO_DO_LIST: update ���
#define EUF_ERR                 1
#define GAS_SENSOR_ERR          2
#define DUST_SENSOR_ERR         3
#define CPI_ERR                 4
#define FILTER_DOOR_ERR         5
#define MOTOR_ERR               6
#define WATER_DOOR_ERR          7   //AJH 160528
#define HUMI_SENSOR_ERR          8   //AJH 160528

#define GAS_SHORT_ERR_COUNT     5
#define GAS_ERR_VALUE_OPEN      253
#define GAS_ERR_VALUE_SHORT      19 // 0.38 ���� �ΰ�� ��Ʈ �Ǵ�.. //1

EXT_SCH volatile unsigned char ds1m;
EXT_SCH volatile unsigned char ds10m;
EXT_SCH volatile unsigned char ds1h;
EXT_SCH volatile unsigned char ds10h;

// Ad_control.c
EXT_SCH volatile unsigned char AD_value_cds;
EXT_SCH volatile unsigned char AD_avg_cds;
EXT_SCH volatile unsigned int  AD_sum_cds;
EXT_SCH volatile unsigned char AD_count_cds;

//CODELESS
//2016_0517_adh
EXT_SCH volatile unsigned int  AD_value_bat;
EXT_SCH volatile unsigned int  AD_avg_bat;
EXT_SCH volatile unsigned int  AD_sum_bat;
EXT_SCH volatile unsigned int  AD_Battery_temp;
EXT_SCH volatile unsigned int  AD_sum_Battery_temp;
EXT_SCH volatile unsigned char AD_count_Battery_temp;
EXT_SCH volatile unsigned char AD_count_bat;
EXT_SCH volatile unsigned char battery_state_check_count;	// Battery state Change update : sec 
EXT_SCH volatile unsigned char ucBATTERY_low_off_count;

EXT_SCH volatile unsigned int	AD_Battery_temp_MAX;
EXT_SCH volatile unsigned int	AD_Battery_temp_MAX1;
EXT_SCH volatile unsigned int	AD_Battery_temp_MAX2;
EXT_SCH volatile unsigned int	AD_Battery_temp_MAX3;

EXT_SCH volatile unsigned char ucBATTERY_CDS_state;
EXT_SCH volatile unsigned char ucBATTERY_LOW_Lock;
EXT_SCH volatile unsigned char ucBATTERY_COMPLETE_voice;
EXT_SCH volatile unsigned char ucBATTERY_LOW_voice;

EXT_SCH volatile unsigned char ucBATTERY_CDS_state_new;
EXT_SCH volatile unsigned char ucBATTERY_CDS_state_old;
EXT_SCH volatile unsigned char ucCDS_state_count;

EXT_SCH volatile unsigned char  AD_avg_bat_100;
EXT_SCH volatile unsigned char  AD_avg_bat_10;


EXT_SCH volatile unsigned char ucPacking_mode_flag;
EXT_SCH volatile unsigned int uiPacking_mode_flag_count;
// CODELESS


//EXT_SCH volatile unsigned char AD_avg_gas;
//EXT_SCH volatile unsigned int  AD_sum_gas;
//EXT_SCH volatile unsigned char AD_count_gas;
//EXT_SCH volatile unsigned char ErrGasSenShortCnt;
EXT_SCH volatile unsigned char gFastAdChkCnt;

EXT_SCH volatile unsigned char AD_value_check_cpi;
EXT_SCH volatile unsigned char AD_avg_check_cpi;
EXT_SCH volatile unsigned int  AD_sum_check_cpi;
EXT_SCH volatile unsigned char AD_count_check_cpi;

EXT_SCH volatile unsigned char gSeg_filter_switch;  //f_Seg_filter_switch
EXT_SCH volatile unsigned char gUsrLedDimming;
EXT_SCH volatile unsigned char gLedDimmingChkCnt;
EXT_SCH volatile unsigned char gUsrLangSel;
EXT_SCH volatile unsigned char gUsrSensibilityIdx;
EXT_SCH volatile unsigned char gCdsNightValueIdx;
EXT_SCH volatile unsigned char gTurboRunTimeIdx;
EXT_SCH volatile unsigned char gUsrRoomcareSel;     //ROOM CARE ����

EXT_SCH volatile unsigned char gFilterWorktimeLow;	//Filter_worktime_low ;
EXT_SCH volatile unsigned char gFilterWorktimeHigh; //Filter_worktime_high
EXT_SCH volatile unsigned char gFilterWorktimeCnt;  
EXT_SCH volatile unsigned int  gTurboRunTimeSecCnt;
EXT_SCH volatile unsigned int  gLoadStopErrCnt;     // ���� �߻��� ���� ���� ���� Ƚ�� ����


#define LED_DIMMING_START_TIME      7   //7��
//--------------------------------------------
// Error Flag
//--------------------------------------------
EXT_SCH TYPE_BYTE                  _set_error_flag;
#define  SET_ERROR_FLAG            _set_error_flag.byte
#define  EUF_NG                    _set_error_flag.bit.b0   // Checksum Error
#define  GAS_SENSOR_NG             _set_error_flag.bit.b1   // Gas sensor error:  Aging �ÿ��� ���� �߻�
#define  DUST_SENSOR_NG            _set_error_flag.bit.b2   // Dust sensor error: Aging �ÿ��� ���� �߻�
#define  CPI_NG                    _set_error_flag.bit.b3   // CPI ���� ����
#define  FILTER_DOOR_NG            _set_error_flag.bit.b4   // ���� Door�� 3�� �̻� �и��� ���
#define  MOTOR_NG                  _set_error_flag.bit.b5   // MOTOR ���� ����
#define  WATER_DOOR_NG             _set_error_flag.bit.b6
#define  HUMI_SENSOR_NG            _set_error_flag.bit.b7

EXT_SCH TYPE_BYTE                  _error_mode;
#define  ERROR_MODE                _error_mode.byte
#define  LOAD_STOP_ERROR           _error_mode.bit.b0

//--------------------------------------------------
// TIME FLAG
//--------------------------------------------------
EXT_SCH TYPE_BYTE                 _time_flag;
#define  TIME_FLAG                _time_flag.byte
#define  TIMER_1SEC               _time_flag.bit.b0
#define  POWER_OFF_1S_FLAG        _time_flag.bit.b1       
#define  MAIN_1S                  _time_flag.bit.b2         // �̻��
#define  HELP_1S                  _time_flag.bit.b3
#define  DELAY_1S                 _time_flag.bit.b4
#define  DUST_LVL_CHK_1SEC        _time_flag.bit.b5         // �̻��
#define  f1min                    _time_flag.bit.b6         
#define  LOAD_1S                  _time_flag.bit.b7

EXT_SCH TYPE_BYTE                  _time_1s_flag;
#define  TIME_1S_FLAG              _time_1s_flag.byte

EXT_SCH TYPE_BYTE                  _time_05s_flag;
#define  TIME_05S_FLAG             _time_05s_flag.byte
#define  EEPROM_DSP_05S            _time_05s_flag.bit.b0

EXT_SCH TYPE_BYTE                  _time_01s_flag;
#define  TIME_01S_FLAG             _time_01s_flag.byte
#define  LOAD_TIME                 _time_01s_flag.bit.b0
#define  f100ms                    _time_01s_flag.bit.b1
#define  TIMER_01SEC               _time_01s_flag.bit.b2
#define  ERR_CTR_01SEC             _time_01s_flag.bit.b3

EXT_SCH TYPE_BYTE                 _Flags;
#define  FFlags                   _Flags.byte
#define  KEY_TIME                 _Flags.bit.b0
#define  DSP_TIME                 _Flags.bit.b1
#define  DSP_TGL                  _Flags.bit.b2
#define  TOGGL_1SEC               _Flags.bit.b3

EXT_SCH TYPE_BYTE                  _time_5min_flag;
#define  TIME_5MIN_FLAG            _time_5min_flag.byte
#define  HUMI_DISPLAY_5MIN         _time_5min_flag.bit.b0

//--------------------------------------------
// Option Flag
//--------------------------------------------
EXT_SCH TYPE_BYTE                  _model_option_flag;
#define  MODEL_OPTION_FLAG         _model_option_flag.byte
#define  CH_MODEL_FLAG             _model_option_flag.bit.b0


EXT_SCH TYPE_BYTE                  _option_flag;
#define  OPTION_FLAG               _option_flag.byte
#define  FAST_MODE                 _option_flag.bit.b0
#define  _EEPROM_READ              _option_flag.bit.b1
#define  _EEPROM_WRITE             _option_flag.bit.b2
#define  LIGHT_SENSING             _option_flag.bit.b3
#define  BABY_DIMMING              _option_flag.bit.b4
#define  _EEPROM_TEST              _option_flag.bit.b5
#define  _EEPROM_USE_WIFI          _option_flag.bit.b6

EXT_SCH TYPE_BYTE                  _option_flag2;
#define  OPTION_FLAG2              _option_flag2.byte
#define  VOLUME_ON                 _option_flag2.bit.b0
#define  DELAY_START               _option_flag2.bit.b1
#define  JELJEON_SET               _option_flag2.bit.b2
#define  TOUCH_LOCK_OPTION         _option_flag2.bit.b3
#define  ERROR_SET                 _option_flag2.bit.b4
#define  AUTO_200mS                _option_flag2.bit.b5
#define  INIT                      _option_flag2.bit.b6
#define  WATER_LACK                _option_flag2.bit.b7     //AJH 160609 ������

EXT_SCH TYPE_BYTE                  _option_flag3;
#define  OPTION_FLAG3              _option_flag3.byte
#define  POWER_ON                  _option_flag3.bit.b0
#define  TURBO_ON                  _option_flag3.bit.b1
#define  FAST_MODE_ON              _option_flag3.bit.b2     //T_FAST_P0
#define  fCPI_SEL_MANU_AIRCLEAN    _option_flag3.bit.b3
#define  fCPI_SEL_MANU_BABY        _option_flag3.bit.b4
#define  fCLEAN_LAMP_ON_MANU_AIRCLEAN _option_flag3.bit.b5
#define  fCLEAN_LAMP_ON_BABY          _option_flag3.bit.b6
#define  REPEAT_ON                    _option_flag3.bit.b7

EXT_SCH TYPE_BYTE                  _option_flag4;
#define  OPTION_FLAG4              _option_flag4.byte
#define  f_Timer                   _option_flag4.bit.b0 // ���� ����
#define  fSLOW_HIGH_CHANGE_RPM       _option_flag4.bit.b1 // �ް��� RPM ���� ���� FLAG
#define  fSLOW_LOW_CHANGE_RPM        _option_flag4.bit.b2 // �ް��� RPM ���� ���� FLAG

//#define  fOff_TimerMode            _option_flag4.bit.b1
//#define  f_TimerMode               _option_flag4.bit.b2 // �����ð� ������ (3�� Display)
//#define  f_TimerChange	           _option_flag4.bit.b3 // �����ð� ������ (3�� Display)
//#define  f_TimerWCap               _option_flag4.bit.b4 // �����ð� ������ (3�� Display)

EXT_SCH TYPE_BYTE                  _option_flag5;
#define  OPTION_FLAG5              _option_flag5.byte
#define  AUTO_HUMI_MODE_ON         _option_flag5.bit.b0 // �ڵ��������
#define  HUMI_WATER_LACK           _option_flag5.bit.b1 // �ڵ��������

EXT_SCH TYPE_BYTE                     _load_flag;
#define  LOAD_FLAG                    _load_flag.byte
#define  fCPI_ON                      _load_flag.bit.b0
#define  fCLEAN_LAMP_ON               _load_flag.bit.b1



EXT_SCH TYPE_BYTE                  _cload_flag;
#define  CLOAD_FLAG                _cload_flag.byte
#define  fCCPI_ON                  _cload_flag.bit.b0
#define  fCCLEAN_LAMP_ON           _cload_flag.bit.b1

EXT_SCH TYPE_BYTE                  _load_flag2;
#define  LOAD_FLAG2                _load_flag2.byte
//#define  BAESU_PUMP                _load_flag2.bit.b0
//#define  COMP_ON                   _load_flag2.bit.b1
//#define  HEATER_ON                 _load_flag2.bit.b2
//#define  WATER_OUT_LED             _load_flag2.bit.b3
//#define  COCKSALGYUN_OUT_LED       _load_flag2.bit.b4
//#define  COCKSALGYUN_OUT_LED2      _load_flag2.bit.b5

EXT_SCH TYPE_BYTE                  _cload_flag2;
#define  CLOAD_FLAG2               _cload_flag2.byte
//#define  CBAESU_PUMP               _cload_flag2.bit.b0
//#define  CCOMP_ON                  _cload_flag2.bit.b1
//#define  CHEATER_ON                _cload_flag2.bit.b2
//#define  CWATER_OUT_LED            _cload_flag2.bit.b3
//#define  CCOCKSALGYUN_OUT_LED      _cload_flag2.bit.b4
//#define  CCOCKSALGYUN_OUT_LED2     _cload_flag2.bit.b5

EXT_SCH TYPE_BYTE                  _load_flag3;
#define  LOAD_FLAG3                _load_flag3.byte
#define  RED_DSP                   _load_flag3.bit.b0
#define  GREEN_DSP                 _load_flag3.bit.b1
#define  BLUE_DSP                  _load_flag3.bit.b2
#define  RED_GREEN_DSP             _load_flag3.bit.b3
#define  RED_BLUE_DSP              _load_flag3.bit.b4
#define  BLUE_GREEN_DSP            _load_flag3.bit.b5
#define  RED_GREEN_BLUE_DSP        _load_flag3.bit.b6

EXT_SCH TYPE_BYTE                  _cload_flag3;
#define  CLOAD_FLAG3               _cload_flag3.byte
#define  CRED_DSP                  _cload_flag3.bit.b0
#define  CGREEN_DSP                _cload_flag3.bit.b1
#define  CBLUE_DSP                 _cload_flag3.bit.b2
#define  CRED_GREEN_DSP            _cload_flag3.bit.b3
#define  CRED_BLUE_DSP             _cload_flag3.bit.b4
#define  CBLUE_GREEN_DSP           _cload_flag3.bit.b5
#define  CRED_GREEN_BLUE_DSP       _cload_flag3.bit.b6

//EXT_SCH TYPE_BYTE                  _load_flag4;
//#define  LOAD_FLAG4                _load_flag4.byte
////#define  f_Change_MT               _load_flag4.bit.b0   // Motor ��ȭ�߻�
////#define  f_FirstChange_MT          _load_flag4.bit.b1   // BLDC Motor ���߾��ٰ� �����ϴ� ���� flag
//
//EXT_SCH TYPE_BYTE                  _load_flag4;
//#define  CLOAD_FLAG4                _load_flag4.byte
////#define  CChange_MT               _load_flag4.bit.b0   // Motor ��ȭ�߻�
////#define  CFirstChange_MT          _load_flag4.bit.b1   // BLDC Motor ���߾��ٰ� �����ϴ� ���� flag

EXT_SCH TYPE_BYTE                  _set_flag;
#define  SET_FLAG                  _set_flag.byte
#define  AD_10mS                   _set_flag.bit.b0
#define  TOGGL_500                 _set_flag.bit.b1
#define  TOGGL_100                 _set_flag.bit.b2
#define  SCROLL_DSP                _set_flag.bit.b3
#define  AD_100mS                  _set_flag.bit.b4
#define  DISPLAY_100mS             _set_flag.bit.b5

EXT_SCH TYPE_BYTE                  _set_flag2;
#define  SET_FLAG2                 _set_flag2.byte
#define  VOICE_SET_MODE            _set_flag2.bit.b0
#define  ENERGY_EYE_SET_MODE       _set_flag2.bit.b1
#define  MOOD_ONF_SET              _set_flag2.bit.b2
#define  HELP_MODE_SET             _set_flag2.bit.b3
#define  HELP_MODE_LED_FLAG        _set_flag2.bit.b4


EXT_SCH TYPE_BYTE                  _set_flag3;
#define  SET_FLAG3                 _set_flag3.byte
#define  EEPROM_RESET              _set_flag3.bit.b0
#define  DUTY_100mS                _set_flag3.bit.b1
#define  MICOM_RESET               _set_flag3.bit.b2
#define  DSP_INIT_EEPROM           _set_flag3.bit.b3
#define  WATER_START_SW_ON         _set_flag3.bit.b4
#define  FLASH_CHECK_SET           _set_flag3.bit.b5
#define  FLASH_CHECK_ON            _set_flag3.bit.b6

EXT_SCH TYPE_BYTE                  _set_flag4;
#define  SET_FLAG4                 _set_flag4.byte
#define  fGAS_SENSOR_INIT_3MIN     _set_flag4.bit.b0    //f_GasSensorOn
#define  fGAS_SENSOR_180MIN        _set_flag4.bit.b1    //f_Gas180Min
#define  fPROCESS_TIME_OVER        _set_flag4.bit.b2    //PrtimOvr
#define  fUSER_SVC_MODE_SET        _set_flag4.bit.b3
#define  fFILTER_SWITCH_ALARM      _set_flag4.bit.b4   //f_FilterSwitch
#define  fAIR_LEVEL_VOICE_ALARM    _set_flag4.bit.b5   //���� 3�� �� ���� ���� �ȳ� Ȯ�� flag
#define  fHUMI_BOJUNG_SET          _set_flag4.bit.b6   //���� 3�� �� ���� ���� �ȳ� Ȯ�� flag

EXT_SCH TYPE_BYTE                  _set_flag5;
#define  SET_FLAG5                 _set_flag5.byte

EXT_SCH TYPE_BYTE                  _set_flag6;
#define  SET_FLAG6                 _set_flag6.byte
#define  EEPROM_WRITE_TIME         _set_flag6.bit.b0
#define  CHKSUM_FDATA              _set_flag6.bit.b1

EXT_SCH TYPE_BYTE                  _set_flag7;
#define  SET_FLAG7                 _set_flag7.byte

EXT_SCH TYPE_BYTE                  _set_flag8;
#define  SET_FLAG8                 _set_flag8.byte
#define  AUTO_ROM_CHK              _set_flag8.bit.b0
#define  VOICE_CHECK               _set_flag8.bit.b1

EXT_SCH TYPE_BYTE                  _set_flag9;
#define  SET_FLAG9                 _set_flag9.byte
#define  AGING_MODE                _set_flag9.bit.b1        //agingFlg

EXT_SCH TYPE_BYTE                  _set_flag10;
#define  SET_FLAG10                _set_flag10.byte
#define  MONITORING_MODE           _set_flag10.bit.b0
#define  COMMON_ERROR              _set_flag10.bit.b1
#define  AGING_DSP                 _set_flag10.bit.b2
#define  AGING_DSP_SMALL           _set_flag10.bit.b3

EXT_SCH TYPE_BYTE                  _set_flag11;
#define  SET_FLAG11                _set_flag11.byte

EXT_SCH TYPE_BYTE                  _set_flag12;
#define  SET_FLAG12                _set_flag12.byte
#define  ICE_OUT                   _set_flag12.bit.b0
#define  OUT_LOCK                  _set_flag12.bit.b1

EXT_SCH TYPE_BYTE                  _set_flag13;
#define  SET_FLAG13                _set_flag13.byte
#define  FOSC_OUT                  _set_flag13.bit.b0
#define  DSP_200mS                 _set_flag13.bit.b1
#define  TOGGLE_100mS              _set_flag13.bit.b2
//#define  BLDC_FOSC_POWER_OFF       _set_flag13.bit.b3

EXT_SCH TYPE_BYTE                  _set_flag14;
#define  SET_FLAG14                _set_flag14.byte
#define  FOSC_DSP_OFF              _set_flag14.bit.b0

EXT_SCH TYPE_BYTE                  _set_flag15;
#define  SET_FLAG15                _set_flag15.byte
#define  FAULT_KEY                 _set_flag15.bit.b0

EXT_SCH TYPE_BYTE                  _set_flag16;
#define  SET_FLAG16                _set_flag16.byte

EXT_SCH TYPE_BYTE                  _set_flag17;
#define  SET_FLAG17                _set_flag17.byte

EXT_SCH TYPE_BYTE                  _set_flag18;
#define  SET_FLAG18                _set_flag18.byte

EXT_SCH TYPE_BYTE                  _set_flag19;
#define  SET_FLAG19                _set_flag19.byte

//--------------------------------------------------------
// DISPLAY SEG
//--------------------------------------------------------
//-------------------------------------------------------
// ES3 �������� �÷� ���� ����
EXT_SCH TYPE_BYTE                  _grid_flag1;
#define  GRID_FLAG1                _grid_flag1.byte
#define  DOT_LED1                 _grid_flag1.bit.b7

EXT_SCH TYPE_BYTE                  _grid_flag1h;
#define  GRID_FLAG1H               _grid_flag1h.byte

EXT_SCH TYPE_BYTE                  _grid_flag2;
#define  GRID_FLAG2                _grid_flag2.byte
#define  DOT_LED2                  _grid_flag2.bit.b7

EXT_SCH TYPE_BYTE                  _grid_flag2h;
#define  GRID_FLAG2H               _grid_flag2h.byte

EXT_SCH TYPE_BYTE                  _grid_flag3;
#define  GRID_FLAG3                _grid_flag3.byte
#define  GRID_FLAG3_b0            _grid_flag3.bit.b0
#define  GRID_FLAG3_b1            _grid_flag3.bit.b1
#define  GRID_FLAG3_b2            _grid_flag3.bit.b2
#define  GRID_FLAG3_b3            _grid_flag3.bit.b3
#define  GRID_FLAG3_b4            _grid_flag3.bit.b4
#define  GRID_FLAG3_b5            _grid_flag3.bit.b5
#define  GRID_FLAG3_b6            _grid_flag3.bit.b6
#define  DOT_LED3                 _grid_flag3.bit.b7
//AJH #define  SOUND_LED                _grid_flag3.bit.b7

EXT_SCH TYPE_BYTE                  _grid_flag3h;
#define  GRID_FLAG3H               _grid_flag3h.byte

//AJH 160704 CAC-CH0810FW i2c
EXT_SCH TYPE_BYTE                  _grid_flag4;
#define  GRID_FLAG4                _grid_flag4.byte
#define  GRID_FLAG4_b0             _grid_flag4.bit.b0    // 
#define  GRID_FLAG4_b1             _grid_flag4.bit.b1    // 
#define  AUTO_HUMI_LED              _grid_flag4.bit.b2   // �ڵ�����
#define  BED_TIME_LED              _grid_flag4.bit.b3    // ��ħ
#define  BABY_LED                  _grid_flag4.bit.b4    // ����
#define  YELLOW_DUST_LED           _grid_flag4.bit.b5    // Ȳ�� 
#define  ROOM_LED                  _grid_flag4.bit.b6    // ���ɾ�
#define  AUTO_LED                  _grid_flag4.bit.b7    // �ڵ�


// New Button LED
EXT_SCH TYPE_BYTE                  _grid_flag4h;
#define  GRID_FLAG4H               _grid_flag4h.byte

//AJH 160704 CAC-CH0810FW i2c
EXT_SCH TYPE_BYTE                  _grid_flag5;
#define  GRID_FLAG5                _grid_flag5.byte
#define  DUST_DENSITY_LED          _grid_flag5.bit.b0   //  %
#define  YETAK_LED                 _grid_flag5.bit.b1   // ����
#define  LOCK_LED                  _grid_flag5.bit.b2   // ���
#define  STEP_LED                  _grid_flag5.bit.b3   // �ܰ�
#define  TURN_OFF_TIME_LED         _grid_flag5.bit.b4   // ���� 
#define  TURN_ON_TIME_LED          _grid_flag5.bit.b5   // ����
#define  MINUTE_LED                _grid_flag5.bit.b6   // min
#define  HOUR_LED                  _grid_flag5.bit.b7   // hour

// New Button LED
EXT_SCH TYPE_BYTE                  _grid_flag5h;
#define  GRID_FLAG5H               _grid_flag5h.byte


EXT_SCH TYPE_BYTE                  _grid_flag6;
#define  GRID_FLAG6                _grid_flag6.byte
#define  POWER_SAVE_LED            _grid_flag6.bit.b0   //����
#define  FINE_DUST_LED             _grid_flag6.bit.b1   //�̼�����
#define  WATER_LED                 _grid_flag6.bit.b2   //������
#define  SOUND_LED                 _grid_flag6.bit.b3   //����
#define  BAT_LED_1                 _grid_flag6.bit.b4   //BATTERY�ܷ� ǥ�� 1
#define  BATTERY_LED1              _grid_flag6.bit.b4   //BATTERY�ܷ� ǥ�� 1

#define  BAT_LED_2                 _grid_flag6.bit.b5   //BATTERY�ܷ� ǥ�� 2
#define  BAT_LED_3                 _grid_flag6.bit.b6   //BATTERY�ܷ� ǥ�� 3
#define  BATTERY_LED2                 _grid_flag6.bit.b5   //BATTERY�ܷ� ǥ�� 2
#define  BATTERY_LED3                 _grid_flag6.bit.b6   //BATTERY�ܷ� ǥ�� 3

#define  FILTER_CHANGE_LED         _grid_flag6.bit.b7   //���ͱ�ȯ

// New Button LED
EXT_SCH TYPE_BYTE                  _grid_flag6h;
#define  GRID_FLAG6H               _grid_flag6h.byte

//AJH 160704 CAC-CH0810FW i2c
EXT_SCH TYPE_BYTE                  _grid_flag7;
#define  GRID_FLAG7                _grid_flag7.byte
#define  POWER_KEY_LED             _grid_flag7.bit.b0   //����/���� 
#define  MODE_KEY_LED              _grid_flag7.bit.b1   //��������
#define  WCAP_KEY_LED              _grid_flag7.bit.b2   //�ٶ�����
#define  TIMER_KEY_LED             _grid_flag7.bit.b3   //�����ư
#define  ION_GEN_KEY_LED           _grid_flag7.bit.b4   //����
#define  TURBO_KEY_LED             _grid_flag7.bit.b5   //�ͺ�����
#define  CLEAN_LAMP_KEY_LED        _grid_flag7.bit.b6   //û����
#define  BAT_LED_4                 _grid_flag7.bit.b7   //BATTERY�ܷ� ǥ�� 4
#define  BATTERY_LED4                 _grid_flag7.bit.b7   //BATTERY�ܷ� ǥ�� 4

// New Button LED
EXT_SCH TYPE_BYTE                  _grid_flag7h;
#define  GRID_FLAG7H               _grid_flag7h.byte

//-------------------------------------------------------

//---------------------------------------------------------------
// Mood & Button LED
//---------------------------------------------------------------


//---------------------------------------------------------------
// KEY
//---------------------------------------------------------------
EXT_SCH TYPE_BYTE                  _key_in_flag;
#define  KEY_IN_FLAG               _key_in_flag.byte
#define  KISF                      _key_in_flag.bit.b0
#define  KINF                      _key_in_flag.bit.b1
#define  LKEY                      _key_in_flag.bit.b2
#define  HKEY                      _key_in_flag.bit.b3
#define  CKEY                      _key_in_flag.bit.b4
#define  MKEY                      _key_in_flag.bit.b5
#define  AUTO_UP                   _key_in_flag.bit.b6
#define  AUTO_DOWN                 _key_in_flag.bit.b7

//---------------------------------------------------------------
// VOICE
//---------------------------------------------------------------
EXT_SCH TYPE_BYTE                  _voice_flag1;
#define  VOICE_FLAG1               _voice_flag1.byte
#define  VOICE_NO_SVC              _voice_flag1.bit.b0
#define  VoiceBusy_F               _voice_flag1.bit.b1
#define  VOICE_START               _voice_flag1.bit.b2
#define  VOICE_ERR                 _voice_flag1.bit.b3
#define  VoiceCommand_busy         _voice_flag1.bit.b4
#define  VoiceCommand_wait         _voice_flag1.bit.b5
#define  VOICE_RESETED             _voice_flag1.bit.b6
#define  VOICE_BUSY_ERR            _voice_flag1.bit.b7

EXT_SCH TYPE_BYTE                  _IsdStatReg;
#define  IsdStatReg                _IsdStatReg.byte
#define  STAT_CMD_BSY              _IsdStatReg.bit.b0
#define  STAT_CBUF_FULL            _IsdStatReg.bit.b1
#define  STAT_VM_BSY               _IsdStatReg.bit.b2
#define  STAT_BIT3                 _IsdStatReg.bit.b3
#define  STAT_RM_FULL              _IsdStatReg.bit.b4
#define  STAT_INT                  _IsdStatReg.bit.b5
#define  STAT_DBUF_RDY             _IsdStatReg.bit.b6
#define  STAT_PD                   _IsdStatReg.bit.b7

//-----------------------------------------------------------------------
#define PROC_STAND_BY   0       //PStandBy        0
#define DUST_LEVEL_FAST_UP_DELAY_COUNT          120 // 2��

EXT_SCH volatile unsigned char   Gas_Fan_Value;
EXT_SCH volatile unsigned char   Gas_Fan_Value_S;
//EXT_SCH volatile unsigned char   Gas_Fan_Value_old; // new Gas_Fan_Value �ʱ� �� 0 �� ������ ���� 
EXT_SCH volatile unsigned char   Dust_Fan_Value;
EXT_SCH volatile unsigned char   Dust_Fan_Value_S;

EXT_SCH volatile unsigned char   Humi_Fan_Value;        //�ڵ�������� ����
EXT_SCH volatile unsigned char   Humi_Fan_Value_S;
EXT_SCH volatile unsigned char   Humi_Fan_Value_Old;
EXT_SCH volatile unsigned char   HumiMaintain_Timer;
EXT_SCH volatile unsigned char   HumiMaintain_Init_Timer;   //�ڵ�������� ���� Ȥ�� ���� ���ΰ��� Ÿ�̸�����, �����ݿ� 30�� DELAY
EXT_SCH volatile unsigned int    Humi300Min_Cnt;            //�ڵ���������� �������� 5�а���� �ڵ� ���� ��ȯ��
EXT_SCH volatile unsigned char    Humi10Sec_Cnt;            //�ڵ���������� �������� 10�� ��� ��  �ڵ� ���� ��ȯ��

EXT_SCH volatile unsigned char   Dust_Fan_Value_Old;       // ���� ���� ���� �ܼ�
EXT_SCH volatile unsigned char   Dust_level_fast_up_flag;  // �������� P1 5�� ��� �Ǵ� Flag 
EXT_SCH volatile unsigned char   Dust_level_fast_up_cnt;   // max 255sec 4�� 15��
EXT_SCH volatile unsigned char   Dust_level_fast_up_ChangeCnt;  // 30�� ������� ó���ϴ� 5�� ������� ������ ���� ���� count

EXT_SCH volatile unsigned char   gTotalAirLevel;   // ���� ���� ������
//EXT_SCH volatile unsigned char   Dust_Fan_Value_old; 

EXT_SCH volatile unsigned char   DustCleanMaintain_Timer;
EXT_SCH volatile unsigned char   CleanMaintain_Timer;
EXT_SCH volatile unsigned char   Gas180Min_Cnt;
EXT_SCH volatile unsigned char   gAirCleanInit3Min_Cnt;

EXT_SCH volatile unsigned char   Water_Cnt;          //FAN ���� ���� Counter // TO_DO_LIST: ������
EXT_SCH volatile unsigned char   Water_Cnt_s;        //FAN ���� ���� Counter // TO_DO_LIST: ������

//AJH 160812 ROOM CARE
EXT_SCH volatile unsigned int   CleanMaintain_RoomTimer;   //AJH 160812 ROOM CARE
EXT_SCH volatile unsigned int   CleanMaintain_LowLevel_Cnt;             //AJH 160812 ROOM CARE ������ 1~3�ܽ� ī��Ʈ��.
EXT_SCH volatile unsigned char   RoomMaintain_Init_Timer;   // ���� ���ΰ��� ���ɾ� ���Խ� Ÿ�̸�����
EXT_SCH volatile unsigned int   RoomTimer_Value;   //AJH 160920 ROOM CARE
EXT_SCH volatile unsigned int   RoomTimer_Value2;   //AJH 160920 ROOM CARE
EXT_SCH volatile unsigned int   RoomTimer_Value3;   //AJH 160920 ROOM CARE

#define LOW_LEVEL_VALUE         1800 // 30��
#define MIDDLE_LEVEL_VALUE      3600 // 60��
#define HIGH_LEVEL_VALUE        5400 // 90��
//ROOM CARE 6->5 �����ð� ����
#define ROOM_BIG_VALUE          300 // 5��
#define ROOM_MIDLE_VALUE        240 // 4��
#define ROOM_SMALL_VALUE        180 // 3��
//ROOM CARE 5->4, 4->3 �����ð� ����
#define ROOM_3MIN               180 // 3��
#define ROOM_2MIN               120 // 3��
#define ROOM_1MIN               60 // 3��

//EXT_SCH volatile unsigned char   BLDC_START_CNT;
//EXT_SCH volatile unsigned int    BLDC_STOP_CNT;

EXT_SCH volatile unsigned char   gSelMotorStep;
EXT_SCH volatile unsigned char   gSelMotorStepOld;
EXT_SCH volatile unsigned char   gLoadMotorStep;
EXT_SCH volatile unsigned char   gLoadMotorTuneStep;   // 10���� ���� STEP
EXT_SCH volatile unsigned char   gBldcSoftStartCnt;
EXT_SCH volatile unsigned char   gBldcSoftStartStep;
EXT_SCH volatile unsigned char   gBldc200msCnt;
EXT_SCH volatile unsigned char   gBldcHaltCheckTime;         //  gBldcHaltCnt;

EXT_SCH volatile unsigned int    gBldcCurrentRpm;    //glBldcCurrentRpm
EXT_SCH volatile unsigned int    gBldcHopeRpm;       //glBldcHopeRpm
EXT_SCH volatile unsigned int    gBldc_Freq_display;   //glBldc_Freq_display
// 
EXT_SCH volatile unsigned int  gPM2_5_AvgData; //glPM2_5_AvgData
EXT_SCH volatile unsigned int  gPM2_5_Concentration;  // ���� ��  glPM2_5_Concentration
EXT_SCH volatile unsigned long gPM2_5_SumData;        // 30�� �ջ� count glPM2_5_SumData
EXT_SCH volatile unsigned char gPM2_5_1hourAvgCnt;  //glPM2_5_1hourAvgCnt
EXT_SCH volatile unsigned char gPM2_5_1hourAvg;    //glPM2_5_1hourAvg

EXT_SCH volatile unsigned int  gPM10_AvgData;         //glPM10_AvgData
//EXT_SCH volatile unsigned int  gPM10_Concentration;   // ���� �� glPM10_Concentration
EXT_SCH volatile unsigned int  gPM10_SumData;         // 30�� �ջ� count  glPM10_SumData
EXT_SCH volatile unsigned int  gPM10_UnitData;        // ����(3��) count  gPM10_UnitData
EXT_SCH volatile unsigned int  gPM10_UnitDataOld;        // ����(3��) count  gPM10_UnitData
EXT_SCH volatile unsigned char gPM10_1hourAvgCnt;     //glPM10_1hourAvgCnt
EXT_SCH volatile unsigned char gPM10_1hourAvg;        //glPM10_1hourAvg

EXT_SCH volatile unsigned int  gDust60MinAvg;
EXT_SCH volatile unsigned int  gDust60SecAvg;
EXT_SCH volatile unsigned int  gDustLevelGood;
EXT_SCH volatile unsigned int  gDustLevelGoodNormal;
EXT_SCH volatile unsigned int  gDustLevelNormal;
EXT_SCH volatile unsigned int  gDustLevelNormalPoor;
EXT_SCH volatile unsigned int  gDustLevelPoor;

EXT_SCH volatile unsigned int  gDustPM2_5Good;
EXT_SCH volatile unsigned int  gDustPM2_5GoodNormal;
EXT_SCH volatile unsigned int  gDustPM2_5Normal;
EXT_SCH volatile unsigned int  gDustPM2_5NormalPoor;
EXT_SCH volatile unsigned int  gDustPM2_5Poor;


//EXT_SCH volatile unsigned char gFullDisplayOn;
EXT_SCH volatile unsigned char gMoodDisplayOn;

EXT_SCH volatile unsigned char gPowerOnSec;     // �ʱ�ȭ ��� �ð� 
//-------------------------------------------------------------------------------------------
/*
#define	FANPERIODDUTY		2048			//2048(125ns * 2048 = 256us) :PWM Perioid
#define BLDC_MOTOR_RPM_HOPE_SLEEP	300
#define BLDC_MOTOR_RPM_HOPE_1DAN	400
#define BLDC_MOTOR_RPM_HOPE_2DAN	650
#define BLDC_MOTOR_RPM_HOPE_3DAN	870
#define BLDC_MOTOR_RPM_HOPE_TURBO	1000
*/


#define MAX_BLDC_MOTOR_RPM       	1500    // ���� �Ǵ� ����
#define MIN_BLDC_MOTOR_RPM       	  10    // ���� �Ǵ� ���� (100->10) PP V4 -> A tool �� ���� ���� : 10�ʰ� 10 rpm ���Ͻ� ���� �Ǵ���
#define BLDC_OVER_SPPED_ERR_TIME_01S  100    //10��: 100ms timer �̿뿡 ���� ���� //5  // BLDC �� ȸ�� �Ǵ� ����
#define BLDC_STOP_ERR_TIME_01S        50    //5��: 100ms timer �̿뿡 ���� ���� //5     // BLDC ���� ���� �Ǵ� ����
#define BLDC_OVER_SPPED_ERR_TIME      5  // BLDC �� ȸ�� �Ǵ� ����
#define BLDC_STOP_ERR_TIME            5     // BLDC ���� ���� �Ǵ� ����

// PP : ���� RPM ���� �ش��ϴ� PWM ������ (pana 57g �ݿ�)
// PC817 Rank B ���� (����Ŀ�÷�)
#define	BLDC_DUTY_SOFTSTART     300//1900 // ���� ���Ҹ� ���� RPM
#define	BLDC_DUTY_300RPM		340  //<=  ������ 1800    1800-1744 = 56  => 28       -> 34  
#define	BLDC_DUTY_400RPM		426  // ������ 
#define	BLDC_DUTY_500RPM		500  //<=  ������ 1691    1691-1612 = 79 => 40
#define	BLDC_DUTY_590RPM		607  // ������
#define	BLDC_DUTY_620RPM		620  //<=  ������ 1612    1612-1435 = 177
#define	BLDC_DUTY_700RPM        700  
#define	BLDC_DUTY_790RPM		790  
#define	BLDC_DUTY_800RPM		800  
#define	BLDC_DUTY_820RPM		820  
#define	BLDC_DUTY_830RPM		830  //<=  ������ 1435
#define	BLDC_DUTY_860RPM		860  //
#define	BLDC_DUTY_870RPM		870  //
#define	BLDC_DUTY_900RPM		900  //
#define	BLDC_DUTY_950RPM		950  //
#define	BLDC_DUTY_1000RPM		1143  // ������
#define	BLDC_DUTY_1010RPM		1161  // ������ 
#define	BLDC_DUTY_1020RPM		1020  //
#define	BLDC_DUTY_1030RPM		1200  //
#define	BLDC_DUTY_1050RPM		1050   //
#define	BLDC_DUTY_1130RPM		1130   //
// ����û���� ���밪
#define	BLDC_DUTY_300RPM_A		1828 //
#define	BLDC_DUTY_400RPM_A		1770 //
#define	BLDC_DUTY_500RPM_A		1731 //
#define	BLDC_DUTY_620RPM_A		1652 //
#define	BLDC_DUTY_1000RPM_A		1310 //
#define	BLDC_DUTY_1130RPM_A		1260 //
//const unsigned char glPwmDutyOffsetArray[] = {34,29,29,50,97,112};

// 2th PILOT: ���� RPM ���� ���� PWM ������
//// PC817 Rank B ���� (����Ŀ�÷�)
//#define	BLDC_DUTY_300RPM		1650  //<=  
//#define	BLDC_DUTY_400RPM		1590  //<=  
//#define	BLDC_DUTY_500RPM		1576  //<=  
//#define	BLDC_DUTY_590RPM		1530 
//#define	BLDC_DUTY_700RPM        1480  //<=  
//#define	BLDC_DUTY_800RPM		1360
//#define	BLDC_DUTY_830RPM		1345  //<=  
//#define	BLDC_DUTY_900RPM		1220
//#define	BLDC_DUTY_1000RPM		1160
//#define	BLDC_DUTY_1050RPM		1112  //<=  

#define BLDC_DUTY_SLOW_HIGH_CHANGE_RPM    BLDC_DUTY_700RPM       // 3�ܰ� �̻� ���� ���� ����� ������ RPM ������ ���� ��������
#define BLDC_DUTY_SLOW_LOW_CHANGE_RPM     BLDC_DUTY_900RPM        // 3�ܰ� �̻� ���� ���� ����� ������ RPM ���Ҹ� ���� ��������

#define	BLDC_DUTY_MAX   		1500 //1250//300                    //1350 RPM
#define	BLDC_DUTY_POWER_OFF 	BLDC_DUTY_500RPM 


EXT_SCH TYPE_BYTE                  _BldcCtrlReg;
#define BldcCtrlReg                _BldcCtrlReg.byte
#define f_FirstChange_MT           _BldcCtrlReg.bit.b4      // BLDC Motor ���߾��ٰ� �����ϴ� ���� flag
#define f_Change_MT		           _BldcCtrlReg.bit.b3		// Motor ��ȭ�߻�
#define f_Stop_MT		           _BldcCtrlReg.bit.b2		// MOTOR STOP Flag
#define f_Working_MT	           _BldcCtrlReg.bit.b1		// MOTOR WORKING Flag
#define f_Start_MT		           _BldcCtrlReg.bit.b0		// MOTOR START Flag
// �������� �߰����� AJH 160320
EXT_SCH TYPE_BYTE               _ToggleCtrlReg;             //
#define ToggleCtrlReg           _ToggleCtrlReg.byte
#define t_3bit		            _ToggleCtrlReg.bit.b3		// 
#define t_2bit		            _ToggleCtrlReg.bit.b2		// 
#define t_1bit	                _ToggleCtrlReg.bit.b1		// 
#define t_0bit		            _ToggleCtrlReg.bit.b0		// 

EXT_SCH TYPE_BYTE               _HumidityReg;             //
#define HumidityReg             _HumidityReg.byte
#define f_AD_REQ                _HumidityReg.bit.b0
#define f_Hu_AD_8th             _HumidityReg.bit.b1 
#define f_Hu_50                 _HumidityReg.bit.b2
#define Humi_check              _HumidityReg.bit.b3
#define Humi_check_int          _HumidityReg.bit.b4

EXT_SCH TYPE_BYTE               _HumiTimeFlag; 
#define HumiTimeFlag            _HumiTimeFlag.byte
#define Humi_05ms               _HumiTimeFlag.bit.b0
 
// 16bit Timer ����
#define	FANPERIODDUTY		2048			//2048(125ns * 2048 = 256us) :PWM Perioid

//4��(Turbo ǳ�� DATA ���� = 3.66V, 13.4W)
#define	FAN4DANDUTY		1100			//1280(125ns *  1280 = 160us) :PWM High Perioid(4���� ���)

//3��(�� ǳ�� DATA ���� = 3.44V, 10.2W)
#define	FAN3DANDUTY		1200			//1540(125ns *  1540 = 192.5us) :PWM High Perioid(3���� ���)

//2��(�� ǳ�� DATA ���� = 3.10V, 6.4W)
#define	FAN2DANDUTY		1300			//1640(125ns * 1640 = 200.5us) :PWM High Perioid(2���� ���)

//1��(�� ǳ�� DATA ���� = 2.83V, 4.1W)
#define	FAN1DANDUTY		1400			//1740(125ns * 1740 = 217.5us) :PWM High Perioid(1���� ���)

// 8bit Timer
//// BLDC : CAC-H1010 �ܼ��� ����
//#define	FANPERIODDUTY		128		//(2us * 128 = 256us) :PWM Perioid
//
////4��(Turbo ǳ�� DATA ���� 
//#define	FAN4DANDUTY		69			//(2us * 80 = 138us) :PWM High Perioid(4���� ���)
//
////3��(�� ǳ�� DATA ���� 
//#define	FAN3DANDUTY		75			//(2us * 75= 150us) :PWM High Perioid(3���� ���)
//
////2��(�� ǳ�� DATA ���� 
//#define	FAN2DANDUTY		81			//(2us * 81 = 162us) :PWM High Perioid(2���� ���)
//
////1��(�� ǳ�� DATA ���� 
//#define	FAN1DANDUTY		88			//(2us * 88 = 176us) :PWM High Perioid(1���� ���)
//
////0��(�� ǳ�� DATA ���� 
//#define	FAN0DANDUTY		94			//(2us * 94 = 188us) :PWM High Perioid(1���� ���)

#define MIN_BLDC_HALT_RPM   50          // 50 RPM ���Ϸ� 3�ʰ� ȸ���ϴ� ��� ���� ������ ������
#define BLDC_SOFT_START_MAX_CNT     1 // TO_DO_LIST: ���� SOFT START �� ���� define �̿���

// MOOD Color define
#define MOOD_COLOR_OPT_RED         1
#define MOOD_COLOR_OPT_BLUE        2
#define MOOD_COLOR_OPT_VIOLET      3
#define MOOD_COLOR_OPT_GREEN       4
#define MOOD_COLOR_OPT_YELLOW      5
#define MOOD_COLOR_OPT_SKY_BLUE    6
#define MOOD_COLOR_OPT_WHITE       7

//-------------------------------------------------------------------------
EXT_SCH volatile unsigned char  gDisplay_Change_Cnt;

EXT_SCH volatile unsigned char   MenuMode;
EXT_SCH volatile unsigned char   MenuMode_S;
enum
{
    MENU_AIRCLEAN_AUTO,             // ��û �ڵ�(0)
    MENU_AIRCLEAN_YELLOW_DUST,      // ��û Ȳ��(1)
    MENU_AIRCLEAN_BABY,             // ��û ����(2)
    MENU_AIRCLEAN_REPEAT,           // ��û �ݺ�(3)
    MENU_AIRCLEAN_BED_TIME,         // ��û ��ħ(4)
    MENU_AIRCLEAN_TURBO,            // ��û ��ħ(5)
    MENU_AIRCLEAN_MANU,             // ��û ����(6)
    MENU_AIRCLEAN_ROOM,             // ��û ROOM(7) //AJH 160813 ROOM CARE
    MENU_AIRCLEAN_HUMI,             // �ڵ����� (8) //AJH 161013 HUMI CARE
    MENU_MODE_MAX_NUM               // ���� ��ȣ ������ ���� (7)
};

EXT_SCH volatile unsigned char   ProcMode;

EXT_SCH volatile unsigned char   time_cnt_10mS;
EXT_SCH volatile unsigned char   time_cnt_1mS;     //AJH 160320
//EXT_SCH volatile unsigned char   BT10mS;
//EXT_SCH volatile unsigned char   BT100mS;
EXT_SCH volatile unsigned char   GasCmpCNT;
EXT_SCH volatile unsigned char   DustCmpCNT;
EXT_SCH volatile unsigned char   HumiCmpCNT;    //�ڵ��������
EXT_SCH volatile unsigned char   PrTm60M;
EXT_SCH volatile unsigned char   PrTm60S;
EXT_SCH volatile unsigned char   T10mS;
EXT_SCH volatile unsigned char   T100mS;
EXT_SCH volatile unsigned char   T60Sec;
EXT_SCH volatile unsigned char   T60Min;
EXT_SCH volatile unsigned int    T24Hour;
EXT_SCH volatile unsigned char	 TDivide;

EXT_SCH volatile unsigned char gMoodBrightnessCnt;
EXT_SCH volatile unsigned char gMoodBrightnessRatio; //0(OFF)~10(MAX)

EXT_SCH volatile unsigned char g1SecCnt;
EXT_SCH volatile unsigned char gDisplaySecCnt;
EXT_SCH volatile unsigned char gDisplayOffTimeCnt;
EXT_SCH volatile unsigned char gDustDisplaySecCnt;
EXT_SCH volatile unsigned char gBtnLedOffCnt;
EXT_SCH volatile unsigned char gBtnWCapLedOnOffCnt;
EXT_SCH volatile unsigned char gDustDisplayButtonCnt;
EXT_SCH volatile unsigned char gBabyCleanLampOffCnt;

EXT_SCH volatile unsigned char gUserSvcModeADJ;
EXT_SCH volatile unsigned char	FilterDoorErrCnt;
EXT_SCH volatile unsigned char	FilterDoorCloseCnt; // Filter Door ä�͸� ���� count
EXT_SCH volatile unsigned char	WaterDoorErrCnt;    //AJH 160528
EXT_SCH volatile unsigned char	WaterDoorCloseCnt;  // AJH 160528 ������� ä�͸� ���� count
EXT_SCH volatile unsigned char	WaterLevelErrCnt;    //AJH 160609
EXT_SCH volatile unsigned char	WaterLevelCloseCnt;  // AJH 160609 ������ ä�͸� ���� count
// ���� ����
EXT_SCH volatile unsigned char 	Timer_Step;		    
EXT_SCH volatile unsigned int	Timer_Data;
EXT_SCH volatile unsigned char 	Timer_Step_Tmp;
EXT_SCH volatile unsigned int	Timer_Data_Tmp;   // �ݺ����� ����� ���� ���� �ð� ������ �ӽ� ���� 
EXT_SCH volatile unsigned char	TurnOn_Timer;
EXT_SCH volatile unsigned char	TurnOff_Timer;
//EXT_SCH volatile unsigned char	Off_Timer_Step;

// HELP Mode , Monitoring mode
EXT_SCH volatile unsigned char  gHelpModeEnterStep;
EXT_SCH volatile unsigned char  gHelpModeEnterCnt;
EXT_SCH volatile unsigned char  gHelpModeTimeOutCnt;
EXT_SCH volatile unsigned char  gMonitorModeEnterStep;
EXT_SCH volatile unsigned char  gMonitorModeEnterCnt;
EXT_SCH volatile unsigned int   gMonitorModeTimeOutCnt;
EXT_SCH volatile unsigned char  gSelfCheckEnterStep;
EXT_SCH volatile unsigned char  gSelfCheckEnterCnt;
EXT_SCH volatile unsigned int   gAutoRomCheckCnt;
EXT_SCH volatile unsigned char  gFilterResetDisplayCnt;
 
#define	FILTERDOOR_ERR_COUNT	27  // 30 //3�� �� ���� ǥ��
#define FILTERDOOR_CLOSE_COUNT   3  // 0.3�� �� ���� ������ �������� �Ǵ�
#define	WATERDOOR_ERR_COUNT	    27  // AJH 160528 2.7���� ������ ǥ��
#define WATERDOOR_CLOSE_COUNT    3  // AJH 160528 0.3���� ������ ����
#define	WATERLEVEL_ERR_COUNT	    30  // AJH 160609 2.7���� ������ ǥ��
#define WATERLEVEL_CLOSE_COUNT    3  // AJH 160609 0.3���� ������ ����
#define BLDC_STOP_REPEAT_COUNT   3  // ���� ���� ���� �ݺ� Ƚ�� (�����Ǵ� ���� �־� �ݺ� ������)
#define BUTTON_LED_OFF_TIME     28
#define BUTTON_LED_OFF_TIME_FAST 100
#define BUTTON_CANCEL_TIME      20  // 20��

#define ENERGY_EYE_DISPLAY_TIME 7  // 7�� -> 5�� -> 7��
#define DUST_INFO_DISPLAY_TIME  5   // 7�� -> 5��
#define VOICE_MUTE              5
#define MONITOR_MODE_TIME_OUT   180 //3��

#define MODEL_OPTION_KOR    1   // OPTION 1 ���� (LOW)
#define MODEL_OPTION_CHN    2   // OPTION 2 ���� (LOW)
#define MODEL_OPTION_MALAY  3
#define MODEL_OPTION_RSV4   4

extern const unsigned int	Timer_Data_TBL[];

// BATTERY //CODELESS
EXT_SCH volatile unsigned char   Battery_State;
EXT_SCH volatile unsigned char   Battery_State_Old;
EXT_SCH volatile unsigned char	 Key_First_check;

EXT_SCH volatile unsigned  int ad_temp; //test
EXT_SCH volatile unsigned  int ad_imsi_L;
EXT_SCH volatile unsigned  int ad_imsi_H;

EXT_SCH volatile unsigned char   Bat_State1;
EXT_SCH volatile unsigned char   Bat_State2;
EXT_SCH volatile unsigned char   Bat_Discharge_Mode;    //AJH �ƴ��� ���� ����

#define BAT_STATE_CHARGING      1
#define BAT_STATE_COMPLETE      2
#define BAT_STATE_SUSPEND		3


#define BAT_CHANGING_LEVEL_L    			//530 //[Q6] 8.4V x 2^6  // 66.0%   BATTERY_LED1( 8.4V �̻�)
#define BAT_CHANGING_LEVEL1     656			//9.67V		5%
#define BAT_CHANGING_LEVEL2     720			//10.73V	40%
#define BAT_CHANGING_LEVEL3     768			//11.62V	70%
#define BAT_CHANGING_LEVEL4     797			//12.24V	90%
#define BAT_CHANGING_LEVEL_F	806			//12.46		200%

#define BAT_LEVEL_L    646			// 9.5V		5%
#define BAT_LEVEL1     708			//10.51V	35%
#define BAT_LEVEL2     733			//10.95V	50%
#define BAT_LEVEL3     762			//11.51V	70%
#define BAT_LEVEL4     806			//12.46V	100%

//#define BAT_CDS_LEVEL0	0
#define BAT_CDS_LEVEL1	0
#define BAT_CDS_LEVEL2	1
#define BAT_CDS_LEVEL3	2
#define BAT_CDS_LEVEL4	3

//--------------------------------------------------
//--------------- Power Stop mode-------------------------
EXT_SCH volatile unsigned char   ucPStop_start_count;
EXT_SCH volatile unsigned char   PStop_1sec_check;
EXT_SCH volatile unsigned char   ucSleep_mode_flag;
EXT_SCH volatile unsigned char   ucSleep_mode_flag_test;
EXT_SCH volatile unsigned char	ucSleep_mode_off_flag;

//---------------------------------------------------------


//======================================================
//  �������� �߰�����
//======================================================
EXT_SCH volatile unsigned char AD_value_humi;
EXT_SCH volatile unsigned char AD_avg_humi;
EXT_SCH volatile unsigned int  AD_sum_humi;
EXT_SCH volatile unsigned char AD_count_humi;
EXT_SCH volatile unsigned char Humi_Count;
EXT_SCH volatile unsigned char Avg_humi;
EXT_SCH volatile unsigned int  Sum_avg_humi;

EXT_SCH volatile unsigned char HU_AD_COMP_VAL_MAX;
EXT_SCH volatile unsigned char HU_AD_COMP_VAL_MIN;

EXT_SCH volatile unsigned char    HU_250Reg[250];         //���� Data �ֱ� 8�� �����
EXT_SCH volatile unsigned char    HU_8Reg[8];         //���� Data �ֱ� 8�� �����
EXT_SCH volatile unsigned char    HU_16Reg[16];         //���� Data �ֱ� 16�� �����
EXT_SCH volatile unsigned char    HU_Val;             //���� A/D 10�� ��ȯ�� ����� Register
EXT_SCH volatile unsigned char    HU_Val_Test;             //test��
EXT_SCH volatile unsigned char    HU_Bojung_Cnt;
EXT_SCH volatile unsigned char    HU_Bojung_Val;        //���������� ǥ��
EXT_SCH volatile unsigned char    HU_Bojung_Plus_Val;   //�������� +
EXT_SCH volatile unsigned char    HU_Bojung_Minus_Val;  //�������� -
EXT_SCH volatile unsigned char    HU_Point;           //������ 8���� ���簪 ����� ��ġ
EXT_SCH volatile unsigned char    HU_Scan_Val;        //���� 50ȸ ���� ��հ�
EXT_SCH volatile unsigned char    TH_VALUE;
EXT_SCH volatile unsigned char    Display_HU_val;   //AJH 160609 
EXT_SCH volatile unsigned char    Display_HU_Plus_val;   //������� + 5%
EXT_SCH volatile unsigned char    Display_HU_val_Old;   //AJH 160609 
EXT_SCH volatile unsigned int    Display_HU_5Min_Cnt;
EXT_SCH volatile unsigned char  HumiWaterLackToggleCnt;

// ��������
EXT_SCH TYPE_BYTE                  _humi_flag;
#define  HUMI_FLAG                 _humi_flag.byte
#define  HUMI_5MIN                 _humi_flag.bit.b0
#define  HUMI_1HOUR                _humi_flag.bit.b1
#define  HUMI_POWER_ON             _humi_flag.bit.b2
#define  HUMI_SLOPE_PLUS           _humi_flag.bit.b3
#define  HUMI_SLOPE_MINUS          _humi_flag.bit.b4
#define  FIRST_HUMI_SLOPE_MINUS    _humi_flag.bit.b5

EXT_SCH volatile unsigned char    HU_Val_Old;         //��������
EXT_SCH volatile unsigned char    HU_Val_Current;     //�������
EXT_SCH volatile unsigned char    HU_Val_Slope;  //���� +����
EXT_SCH volatile unsigned char    HU_Val_Old_Current;  //���� +����
EXT_SCH volatile unsigned char    Bojung_Value;  //���� +����

EXT_SCH volatile unsigned int  Humi5MinCnt;
EXT_SCH volatile unsigned int  Humi1HourCnt;


EXT_SCH volatile unsigned int   ADEnvSensor_sum;
EXT_SCH volatile unsigned char   ADEnvSensor_cnt;
EXT_SCH volatile unsigned char   ADEnvSensor_ave;
EXT_SCH volatile unsigned char   ADEnvSensor_Temp;
EXT_SCH volatile unsigned char   WarmEnv_state;
EXT_SCH volatile unsigned char   WarmEnv_cnt;
EXT_SCH volatile unsigned char   WarmEnvTemp;

EXT_SCH volatile unsigned char   Humidisplay_timer;   //AJH 160609
//======================================================
//  ȯ��µ����� �߰�����
//======================================================
EXT_SCH volatile unsigned char AD_value_th;
EXT_SCH volatile unsigned char AD_avg_th;
EXT_SCH volatile unsigned int  AD_sum_th;
EXT_SCH volatile unsigned char AD_count_th;


#define CMD1_FLAG0_OFFSET   3
#define CMD2_FLAG0_OFFSET   8
#define CMD3_FLAG0_OFFSET   13
#define CMD3_FLAG1_OFFSET   12
#define CMD4_FLAG0_OFFSET   18

#define CMDx_FLAG0_OFFSET           CMD1_FLAG0_OFFSET
#define CMDx_FLAG1_OFFSET           2

#define AT_CMD_CR           0x0D
#define AT_CMD_LF           0x0A
#define AT_CMD_SPC          0x20
#define AT_CMD_NULL_FLAG    0x80
#define AT_NULL_FLAG_MASK   0x7F

//#define CMD4_FLAG0_OFFSET   17

//======================================================
//  IOT ���� bit ����Ȯ��
//======================================================
// RCMD1 0byte Bit0 
EXT_SCH TYPE_BYTE                  _iot_rcmd1_flag0;
#define  IOT_RCMD1_FLAG0           _iot_rcmd1_flag0.byte
#define  fRxIotPowerOn             _iot_rcmd1_flag0.bit.b0 // ����

// SCMD1 0byte Bit0 
EXT_SCH TYPE_BYTE                  _iot_scmd1_flag0;
#define  IOT_SCMD1_FLAG0           _iot_scmd1_flag0.byte
#define  fTxIotPowerOn             _iot_scmd1_flag0.bit.b0 // ����

// Change state CMD1 0byte Bit0 
EXT_SCH TYPE_BYTE                  _iot_chg_cmd1_flag0;
#define  IOT_CHG_CMD1_FLAG0        _iot_chg_cmd1_flag0.byte
#define  fChgIotPowerOn            _iot_chg_cmd1_flag0.bit.b0 // ����

// RCMD2 0byte Bit0 
EXT_SCH TYPE_BYTE                  _iot_rcmd2_flag0;
#define  IOT_RCMD2_FLAG0           _iot_rcmd2_flag0.byte
#define  fRxIotMenuMode            _iot_rcmd2_flag0.bit.b0 // �������

// SCMD2 0byte Bit0 
EXT_SCH TYPE_BYTE                  _iot_scmd2_flag0;
#define  IOT_SCMD2_FLAG0           _iot_scmd2_flag0.byte
#define  fTxIotMenuMode            _iot_scmd2_flag0.bit.b0 // �������

// Change state CMD2 0byte Bit0 
EXT_SCH TYPE_BYTE                  _iot_chg_cmd2_flag0;
#define  IOT_CHG_CMD2_FLAG0        _iot_chg_cmd2_flag0.byte
#define  fChgIotMenuMode           _iot_chg_cmd2_flag0.bit.b0 // �������

// RCMD3 0byte 
EXT_SCH TYPE_BYTE                  _iot_rcmd3_flag0;
#define  IOT_RCMD3_FLAG0           _iot_rcmd3_flag0.byte
#define  fRxIotMotorStep           _iot_rcmd3_flag0.bit.b0 // FAN LEVEL
#define  fRxIotCpiOn               _iot_rcmd3_flag0.bit.b1 // ���յ���
#define  fRxIotTouchLock           _iot_rcmd3_flag0.bit.b2 // ��ư���
#define  fRxIotLangSel             _iot_rcmd3_flag0.bit.b3 // ����
#define  fRxIotUsrVolume           _iot_rcmd3_flag0.bit.b4 // ��������
#define  fRxIotfilterSwitch        _iot_rcmd3_flag0.bit.b5 // ���ͱ�ü�˸�
#define  fRxIotSensibility         _iot_rcmd3_flag0.bit.b6 // �����ΰ���

// SCMD3 0byte 
EXT_SCH TYPE_BYTE                  _iot_scmd3_flag0;
#define  IOT_SCMD3_FLAG0           _iot_scmd3_flag0.byte
#define  fTxIotMotorStep           _iot_scmd3_flag0.bit.b0 // �������
#define  fTxIotCpiOn               _iot_scmd3_flag0.bit.b1 // ���յ���
#define  fTxIotTouchLock           _iot_scmd3_flag0.bit.b2 // ��ư���
#define  fTxIotLangSel             _iot_scmd3_flag0.bit.b3 // ����
#define  fTxIotUsrVolume           _iot_scmd3_flag0.bit.b4 // ��������
#define  fTxIotfilterSwitch        _iot_scmd3_flag0.bit.b5 // ���ͱ�ü�˸�
#define  fTxIotSensibility         _iot_scmd3_flag0.bit.b6 // �����ΰ���

// Change state CMD3 0byte 
EXT_SCH TYPE_BYTE                  _iot_chg_cmd3_flag0;
#define  IOT_CHG_CMD3_FLAG0        _iot_chg_cmd3_flag0.byte
#define  fChgIotMotorStep          _iot_chg_cmd3_flag0.bit.b0 // �������
#define  fChgIotCpiOn              _iot_chg_cmd3_flag0.bit.b1 // ���յ���
#define  fChgIotTouchLock          _iot_chg_cmd3_flag0.bit.b2 // ��ư���
#define  fChgIotLangSel            _iot_chg_cmd3_flag0.bit.b3 // ����
#define  fChgIotUsrVolume          _iot_chg_cmd3_flag0.bit.b4 // ��������
#define  fChgIotfilterSwitch       _iot_chg_cmd3_flag0.bit.b5 // ���ͱ�ü�˸�
#define  fChgIotSensibility        _iot_chg_cmd3_flag0.bit.b6 // �����ΰ���

// RCMD3 1byte 
EXT_SCH TYPE_BYTE                  _iot_rcmd3_flag1;
#define  IOT_RCMD3_FLAG1           _iot_rcmd3_flag1.byte
#define  fRxIotCdsOption           _iot_rcmd3_flag1.bit.b0 // ���������� �ΰ���
#define  fRxIotTurboOption         _iot_rcmd3_flag1.bit.b1 // ���յ���
#define  fRxIotRoomcareSel         _iot_rcmd3_flag1.bit.b2 // ��ư���

// SCMD3 1byte 
EXT_SCH TYPE_BYTE                  _iot_scmd3_flag1;
#define  IOT_SCMD3_FLAG1           _iot_scmd3_flag1.byte
#define  fTxIotCdsOption           _iot_scmd3_flag1.bit.b0 // ���������� �ΰ���
#define  fTxIotTurboOption         _iot_scmd3_flag1.bit.b1 // ���յ���
#define  fTxIotRoomcareSel         _iot_scmd3_flag1.bit.b2 // ��ư���

// Change state CMD3 1byte 
EXT_SCH TYPE_BYTE                  _iot_chg_cmd3_flag1;
#define  IOT_CHG_CMD3_FLAG1        _iot_chg_cmd3_flag1.byte
#define  fChgIotCdsOption          _iot_chg_cmd3_flag1.bit.b0 // ���������� �ΰ���
#define  fChgIotTurboOption        _iot_chg_cmd3_flag1.bit.b1 // ���յ���
#define  fChgIotRoomcareSel        _iot_chg_cmd3_flag1.bit.b2 // ��ư���

// RCMD4 0byte 
EXT_SCH TYPE_BYTE                  _iot_rcmd4_flag0;
#define  IOT_RCMD4_FLAG0           _iot_rcmd4_flag0.byte
#define  fRxIotDustFanLevel        _iot_rcmd4_flag0.bit.b0 // �̼�����
#define  fRxIotExtrDustLevel       _iot_rcmd4_flag0.bit.b1 // �ʹ̼�����
#define  fRxIotUltraDustLevel      _iot_rcmd4_flag0.bit.b2 // ���ʹ̼�����
#define  fRxIotTotalAirLevel       _iot_rcmd4_flag0.bit.b3 // ����û����
#define  fRxIotGasFanLevel         _iot_rcmd4_flag0.bit.b4 // ������������
#define  fRxIotHumiData            _iot_rcmd4_flag0.bit.b5 // �������
#define  fRxIotFilterWork          _iot_rcmd4_flag0.bit.b6 // ���ͻ�뷮

// SCMD4 0byte 
EXT_SCH TYPE_BYTE                  _iot_scmd4_flag0;
#define  IOT_SCMD4_FLAG0           _iot_scmd4_flag0.byte
#define  fTxIotDustFanLevel        _iot_scmd4_flag0.bit.b0 // �̼�����
#define  fTxIotExtrDustLevel       _iot_scmd4_flag0.bit.b1 // �ʹ̼�����
#define  fTxIotUltraDustLevel      _iot_scmd4_flag0.bit.b2 // ���ʹ̼�����
#define  fTxIotTotalAirLevel       _iot_scmd4_flag0.bit.b3 // ����û����
#define  fTxIotGasFanLevel         _iot_scmd4_flag0.bit.b4 // ������������
#define  fTxIotHumiData            _iot_scmd4_flag0.bit.b5 // �������
#define  fTxIotFilterWork          _iot_scmd4_flag0.bit.b6 // ���ͻ�뷮

// Change state CMD4 0byte 
EXT_SCH TYPE_BYTE                  _iot_chg_cmd4_flag0;
#define  IOT_CHG_CMD4_FLAG0        _iot_chg_cmd4_flag0.byte
#define  fChgIotDustFanLevel       _iot_chg_cmd4_flag0.bit.b0 // �̼�����
#define  fChgIotExtrDustLevel      _iot_chg_cmd4_flag0.bit.b1 // �ʹ̼�����
#define  fChgIotUltraDustLevel     _iot_chg_cmd4_flag0.bit.b2 // ���ʹ̼�����
#define  fChgIotTotalAirLevel      _iot_chg_cmd4_flag0.bit.b3 // ����û����
#define  fChgIotGasFanLevel        _iot_chg_cmd4_flag0.bit.b4 // ������������
#define  fChgIotHumiData           _iot_chg_cmd4_flag0.bit.b5 // �������
#define  fChgIotFilterWork         _iot_chg_cmd4_flag0.bit.b6 // ���ͻ�뷮

#define  JSEND_TYPE_DEVICE_CTRL   0
#define  JSEND_TYPE_STAT_ACK      1
#define  JSEND_TYPE_DEVICE_CHG    2
#define  JSEND_TYPE_MAX           JSEND_TYPE_DEVICE_CHG

#define  MAX_IOT_COMM_RETRY_CNT   2 // ORG
//,#define  MAX_IOT_COMM_RETRY_CNT   0 // TEST ONLY

//if(glOneM2MConnectOK) fChgIotPowerOn = 1;
//if(glOneM2MConnectOK) fChgIotMenuMode = 1;
//if(glOneM2MConnectOK) fChgIotMotorStep = 1;
//if(glOneM2MConnectOK) fChgIotCpiOn = 1;
//if(glOneM2MConnectOK) fChgIotTouchLock = 1;
//if(glOneM2MConnectOK) fChgIotLangSel = 1;
//if(glOneM2MConnectOK) fChgIotUsrVolume = 1;
//if(glOneM2MConnectOK) fChgIotfilterSwitch = 1;
//if(glOneM2MConnectOK) fChgIotSensibility = 1;
//if(glOneM2MConnectOK) fChgIotCdsOption = 1;
//if(glOneM2MConnectOK) fChgIotTurboOption = 1;
//if(glOneM2MConnectOK) fChgIotRoomcareSel = 1;
//if(glOneM2MConnectOK) fChgIotDustFanLevel = 1;
//if(glOneM2MConnectOK) fChgIotExtrDustLevel = 1;
//if(glOneM2MConnectOK) fChgIotUltraDustLevel = 1;
//if(glOneM2MConnectOK) fChgIotTotalAirLevel = 1;
//if(glOneM2MConnectOK) fChgIotGasFanLevel = 1;
//if(glOneM2MConnectOK) fChgIotHumiData = 1;
//if(glOneM2MConnectOK) fChgIotFilterWork = 1;

//====================================================================================
// �̻�� ����
//====================================================================================
// **** buzzer control ******
//#define   BZ_F118        106//   (106*8uS = 848uS --> 1/848uS = 1.18KHZ)
//#define   BZ_F149        84 //   (84*8uS = 672uS --> 1/672uS = 1.48KHZ)
//#define   BZ_F156        80 //   (80*8uS = 640uS --> 1/640uS = 1.56KHZ)
//#define   BZ_F167        75 //   (75*8uS = 600uS --> 1/600uS = 1.67KHZ)
//#define   BZ_F176        70 //   (70*8uS = 560uS --> 1/560uS = 1.76KHZ)
//#define   BZ_F192        65 //   (65*8uS = 520uS --> 1/520uS = 1.92KHZ)
//#define   BZ_F208        60 //   (60*8uS = 480uS --> 1/480uS = 2.08KHZ)
//#define   BZ_F227        55 //   (55*8uS = 440uS --> 1/440uS = 2.27KHZ)
//#define   BZ_F250        50 //   (50*8uS = 400uS --> 1/400uS = 2.50KHZ)
//
//#define   BZ05_05        1
//#define   BZ10_10        2
//#define   BZ50_50        3
//#define   BZ100_100      4
//#define   ALAM_BZ        5
//#define   POWER_ON_BZ    6
//#define   POWER_OFF_BZ   7
//#define   ERROR_BZ       8
//#define   YEYEL_ALAM_BZ  9
//
//
//#define   BZR_50_ON      2
//#define   BZR_100_ON     3
//#define   BZR_500_ON     6
//#define   BZR_1000_ON    24
//
//#define   BZR_50_OFF     3
//#define   BZR_100_OFF    25
//#define   BZR_500_OFF    54
//#define   BZR_1000_OFF   102


//#define POWER_7     1
//#define POWER_8     2
//#define POWER_9     3

//----- Defines -----//
// Base Timer for setting 25msec
// Internal Clock = OSC/4 = 16MHz/4 = 4Mhz = 0.25usec
//  _OPTION = 0b10001000;   // TMR0 runs on internal clock(0.25usec)
                // 0.25usec * 256 = 64usec
//  _OPTION = 0b10000000;   // 0.25usec*2 = 0.5usec (Timer0 Prescaler = 1:1)

//-------------------------------------------------------------------------------------------
//#define KOnTim          9       // Key On  delayTime (8.3mS *  9 = 75mS / 90mS )
//#define KOfTim          9       // Key Off delaytime (8.3mS *  9 = 75mS / 90mS )
//#define RptTim          17      // Repeat Time, (8.3mS * 17 = 141.1mS)
//#define RptTim_423ms    51      // Repeat Time, (8.3mS * 51 = 423.3mS)
//#define RpStTim         96      // Repeat Start Time (8.3mS * 96 = 800mS)

//====================================================================================
