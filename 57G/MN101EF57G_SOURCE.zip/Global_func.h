/******************************************************************************
**
**  COPYRIGHT (C) 
**
**  THIS WORK CONTAINS TRADE SECRET AND PROPRIETARY INFORMATION WHICH IS
**  THE PROPERTY OF CUCKOO
**
**  PROJECT NAME:   
**
**  FILENAME:       
**
**  PURPOSE:        
**
**  FUNCTIONS:      
**
**  AUTHOR:
**
**  VERSION:        1.0
**
**  LAST MODIFIED:  
******************************************************************************/
//----------------------------------------------------------

//----------------------------------------------------------
void main(void);	
void Key_control(void);
void Error_control(void);
void Eeprom_control(void);
void Ad_control(void);
void Timer_control(void);
void Load_control(void);
void Display_control(void);
void VoiceDrive(void);
void WifiApp(void);
void DisplayScan_TK18A(void); 

void Battery_voltage_ad(void);  //codeless

void help_clear(void);
//void voice_volume_out(void);

//Voice.c
void VoiceOutOne(unsigned int addr,unsigned char pause);
void VoiceOutTwo(unsigned int addr0,unsigned char pause0,unsigned int addr1,unsigned char pause1);
void VoiceOutThree(unsigned int addr0,unsigned char pause0,unsigned int addr1,unsigned char pause1,unsigned int addr2,unsigned char pause2);
void VoiceOutFour(unsigned int addr0,unsigned char pause0,unsigned int addr1,unsigned char pause1,unsigned int addr2,unsigned char pause2,unsigned int addr3,unsigned char pause3);
void VoiceOutFive(unsigned int addr0,unsigned char pause0,unsigned int addr1,unsigned char pause1,unsigned int addr2,unsigned char pause2,unsigned int addr3,unsigned char pause3,unsigned int addr4,unsigned char pause4);

void VoiceOutOneSvc(unsigned int addr, unsigned char pause, unsigned char beepAddr);
void VoiceOutTwoSvc(unsigned int addr0, unsigned char pause0, unsigned int addr1, unsigned char pause1, unsigned char beepAddr);
void VoiceOutThreeSvc(unsigned int addr0, unsigned char pause0, unsigned int addr1, unsigned char pause1, unsigned int addr2,unsigned char pause2, unsigned char beepAddr);
void VoiceOutFourSvc(unsigned int addr0,unsigned char pause0,unsigned int addr1,unsigned char pause1,unsigned int addr2,unsigned char pause2,unsigned int addr3,unsigned char pause3, unsigned char beepAddr);
void VoicePlayTest(unsigned char incOpt);

// Ad_control.c
unsigned int GetADCValue(unsigned char Channel);
void Delay_Routine(unsigned int Delay);
void Cds_ad(void);
void FilterDoorCheck(void);
void WaterDoorCheck(void);      //AJH 160528 ������   ����
void WaterLevelCheck(void);     //AJH 160609 �������� ����
//void GasSensorErrCheck(void);

void Hu_ADC_Svc(void);  //��������
void HU_Data_Svc(void);
void WarmEnvAdjust(void);
void WarmEnvClear(void);

void Th_ADC_Svc(void);  //ȯ��µ����� 

// Timer.c
void TimeBaseCLR10mS(void);
void TimeBaseCLR24H(void);

// key_control.c
void Power_On_Exe(void);
void Power_Off_Exe(void);
void Key_Mode_exe(void);

void UsrVolumeKey(void);
void UserSvcModeEnd(void);
void UserSvcModeCancel(unsigned char timeOver);
void UsrfilworkKey(void);           // ���;˸��ð� �ʱ�ȭ
void UsrFilterChgAlertKey(void);    // ���ͱ�ü �˸����
void UsrcleandisplayKey(void);
void UsrFndDimmingKey(void);
void UsrLangKey(void);
void UsrSensibilityKey(void);
void UsrCdsOptionKey(void);
void UsrTurboRunTimeKey(void);
void UsrRoomCareKey(void);      //ROOM CARE ����

void HelpModeKeySvc(void);
void HelpModeEnterCheck(unsigned char keyInData);    // HELP ����
void MonitorModeEnterCheck(unsigned char keyInData); // MOMITORING MODE ����
void SelfCheckEnterCheck(unsigned char keyInData);                      // �ڱ����ܱ�� ����


void MoodBrightnessControl(void);   // MOOD DISPLAY

// Load_control.c
void Clear_BldcConfig(void);
void Delay_Clear_BldcConfig(void);
void Bldc_RpmRevision(void);

// EEPROM
void init_eeprom_set(void);
void set_default_eeprom(void);
unsigned char Eeprom_integrity_test(void);
void wait(void);

unsigned char EEPROM_Init_WIFI_Info(void);
unsigned char EEPROM_Write_AP_Name(char* src, unsigned char size);
unsigned char EEPROM_Read_AP_Name(char* dst);
unsigned char EEPROM_Write_AP_Password(char* src, unsigned char size);
unsigned char EEPROM_Read_AP_Password(char* dst);

