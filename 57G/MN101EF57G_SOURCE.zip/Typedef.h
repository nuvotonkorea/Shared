/******************************************************************************
**
**  COPYRIGHT (C) 
**
**  THIS WORK CONTAINS TRADE SECRET AND PROPRIETARY INFORMATION WHICH IS
**  THE PROPERTY OF CUCKOO
**
**  PROJECT NAME:   
**
**  FILENAME:       .c
**
**  PURPOSE:        
**
**  FUNCTIONS:      
**
**  AUTHOR:
**
**  VERSION:        1.0
**
**  LAST MODIFIED:  
******************************************************************************/
/*****************************************************************************
Note:
2015-04-10 : 
*******************************************************************************/

typedef unsigned char	BYTE;

typedef	volatile struct {	// optimize control bit-field definition
	BYTE	p7		: 1;
	BYTE	p6		: 1;
	BYTE	p5		: 1;
	BYTE	p4		: 1;
	BYTE	p3		: 1;
	BYTE	p2		: 1;
	BYTE	p1		: 1;
	BYTE	p0		: 1;
} RB_BTF;

typedef struct {
	BYTE b7		:1;
	BYTE b6		:1;
	BYTE b5		:1;
	BYTE b4		:1;
	BYTE b3		:1;
	BYTE b2		:1;
	BYTE b1		:1;
	BYTE b0		:1;
} BYTE_FIELD;

typedef struct {
	unsigned char b7:1;
	unsigned char b6:1;
	unsigned char b5:1;
	unsigned char b4:1;
	unsigned char b3:1;
	unsigned char b2:1;
	unsigned char b1:1;
	unsigned char b0:1;
	unsigned char b15:1;
	unsigned char b14:1;
	unsigned char b13:1;
	unsigned char b12:1;
	unsigned char b11:1;
	unsigned char b10:1;
	unsigned char b9:1;
	unsigned char b8:1;
} WORD_FIELD;

/*=======  BYTE IO ========*/
typedef union {
	unsigned char 	byte;
	BYTE_FIELD 	bit;
} TYPE_BYTE;

/*======= WORD IO ========*/
typedef union {
	unsigned int	word;
	unsigned char	byte[2];
	WORD_FIELD 	bit;
} TYPE_WORD;

/*====== DOUBLE IO =======*/
typedef union {
	unsigned long 	wword;
	unsigned int	word[2];
	unsigned char	byte[4];
} TYPE_DWORD;

#define TURN_ON	    1
#define TURN_OFF	0

#define HIGH        1
#define LOW         0

#define ON          1
#define OFF         0

#define SET         1
#define CLEAR       0
#define CLR         0
#define ZERO        0

#define TRUE        1
#define FALSE       0

